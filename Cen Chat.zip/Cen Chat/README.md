# Cen-Chat — versão estável

Cen-Chat é o sistema de comunicação interna da clínica, com chat em tempo real, Web Push, temas, envio em massa por setores, auditoria e o assistente Erasminho.

## Banco de dados

O backend usa **somente MariaDB/MySQL**, através do PyMySQL.

No `.env`:

```env
DATABASE_URL=mysql+pymysql://cenchat_user:SENHA_DO_BANCO@localhost:3306/cenchat?charset=utf8mb4
```

O arquivo `sql/BANCO_MARIADB_MYSQL.sql` cria o banco e o usuário básico.

## Instalação

1. Instale Python 3.12 ou 3.13 no Windows. O instalador seleciona uma dessas versões para evitar incompatibilidades de dependências.
2. Confira o `DATABASE_URL` no `.env` usando MariaDB/MySQL.
3. Execute `instalar.bat`.
4. Execute `inicia.bat` para iniciar o servidor.

O acesso padrão da rede é `http://10.10.10.192:5050/chat`.

## Checkup e diagnóstico

O `inicia.bat` valida o ambiente e inicia o servidor HTTP + WebSocket. O `instalar.bat` recria o ambiente, instala dependências e configura o Firewall das portas 5050 e 5051.

## Permissões e setores visíveis

O menu lateral agora respeita a matriz de permissões do Painel ADM. Usuários comuns só recebem na tela os setores que têm pelo menos um contato permitido. Assim, por exemplo, se TI estiver liberado somente para TI, o usuário de TI não verá os demais setores. Administradores (perfil `adm`, atualmente Val e Valdirene) continuam vendo todos os setores e não ficam limitados pela matriz. A proteção também é aplicada no backend para abertura de conversa, envio em massa e notificações.

As 15 pastas de trabalho são: Adm Nacen, Almoxarifado, Apoio, Conferência, Faturamento, Financeiro, Jurídico, Marcação, Profissionais, Recepção, Recepção Nacen, Recepção Nacen+, RH, Secretarias e TI. `Sem setor` é apenas um estado de usuário e não aparece como pasta.

## Tempo real

O HTTP usa a porta `5050`. O WebSocket usa a porta `5051` e a rota `/ws`.

O fluxo de mensagens não depende de polling para cada mensagem: o servidor envia o evento completo pelo WebSocket e o navegador atualiza somente o que mudou. O banco continua sendo a fonte de verdade. Depois de uma reconexão, as conversas abertas podem ser sincronizadas novamente para recuperar mensagens que chegaram durante a queda.

O WebSocket também trata:
- mensagens novas;
- entregue/lido;
- edição;
- exclusão;
- digitando;
- presença.

A porta `5051` é o canal de tempo real e é liberada automaticamente pelo `instalar.bat`.

## Envio em massa

A tela de envio em massa usa o fluxo:

`Setor → abrir pasta → escolher colaboradores → voltar → enviar`

É possível selecionar pessoas específicas dentro de cada setor. As mensagens são persistidas nas conversas individuais dos destinatários e, quando conectados, eles recebem o evento pelo WebSocket.

## Erasminho

O Erasminho é a IA online do Cen-Chat. Ele conversa de forma dinâmica e responde em streaming usando o serviço online carregado no navegador. Não é necessário cadastrar uma chave de API própria no servidor.

Ele foi limitado ao contexto corporativo: pode explicar o Cen-Chat e usar a base autorizada em `knowledge/erasminho_base.md`. Para assuntos fora do trabalho, responde de forma leve e redireciona para assuntos corporativos.

## Web Push

As notificações em segundo plano usam Web Push. Para uso em rede interna, o navegador pode exigir HTTPS conforme o cenário e a política do navegador. As chaves VAPID ficam no `.env`.

## Anexos

O limite atual é de `10 MB` por arquivo, configurável com `ANEXO_MAX_MB`. Extensões executáveis e scripts são bloqueados.

## Temas e tour

As preferências de tema e notificações são individuais. O tour de primeiros passos pode ser refeito pelas configurações e acompanha as cores do tema selecionado.

## Estrutura importante

```text
app.py
requirements.txt
instalar.bat
inicia.bat
sql/BANCO_MARIADB_MYSQL.sql
knowledge/erasminho_base.md
static/js/chat.js
templates/chat.html
```


## LDAP e setores

O LDAP importa e autentica usuários. Os setores são 100% locais do Cen-Chat.
A sincronização nunca altera `setor_id` de usuários existentes, nunca cria setores
e não altera `ativo` de contas já cadastradas. Usuários novos entram sem setor
e são organizados pelo administrador no Cen-Chat ou diretamente no banco.

## Regra de organização LDAP x setores do Cen-Chat

A sincronização LDAP **não controla os setores internos do Cen-Chat**.

- O LDAP serve para localizar/importar e autenticar usuários dos grupos configurados.
- `usuarios.setor_id` é propriedade local do Cen-Chat.
- O próximo sync LDAP não altera `setor_id`.
- `usuarios.ativo` é propriedade local do Cen-Chat para usuários já existentes.
- O sync LDAP não ativa nem desativa usuários existentes.
- A ausência temporária de um usuário em uma sincronização não desativa sua conta no Cen-Chat.
- Para mover alguém de setor, altere `setor_id` pelo Painel ADM ou diretamente no MariaDB/MySQL.
- Para ativar/desativar alguém, use o controle local do Painel ADM; o LDAP não desfaz essa decisão.

Assim, é possível manter o usuário em um setor interno diferente do grupo/OU do AD.
