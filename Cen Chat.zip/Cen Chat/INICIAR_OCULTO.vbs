Option Explicit
Dim sh, fso, base, py, script, logFile, cmd
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
py = base & "\venv\Scripts\python.exe"
script = base & "\app.py"
logFile = base & "\logs\servidor_inicio.log"
If Not fso.FolderExists(base & "\logs") Then fso.CreateFolder(base & "\logs")
If Not fso.FileExists(py) Then
  sh.Popup "Python do ambiente virtual nao encontrado. Execute instalar.bat primeiro.",0,"Cen-Chat",16
  WScript.Quit 1
End If
' A redirecao precisa ser executada pelo cmd.exe; chamar wscript diretamente com >>> nao e valido.
cmd = "cmd.exe /c " & Chr(34) & Chr(34) & py & Chr(34) & " " & Chr(34) & script & Chr(34) & " >> " & Chr(34) & logFile & Chr(34) & " 2>&1" & Chr(34)
sh.Run cmd,0,False
WScript.Quit 0
