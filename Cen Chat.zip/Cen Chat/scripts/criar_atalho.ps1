$WshShell = New-Object -comObject WScript.Shell
$Desktop = [Environment]::GetFolderPath("Desktop")
$Shortcut = $WshShell.CreateShortcut("$Desktop\Cen-Chat.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\..\inicia.bat"
$Shortcut.WorkingDirectory = "$PSScriptRoot\.."
$Shortcut.IconLocation = "$PSScriptRoot\..\static\img\favicon.png"
$Shortcut.Save()
Write-Host "Atalho Cen-Chat criado na area de trabalho."
