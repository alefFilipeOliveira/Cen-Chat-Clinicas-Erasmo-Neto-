import base64
import os
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

BASE = Path(__file__).resolve().parents[1]
ENV = BASE / ".env"

def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")

text = ENV.read_text(encoding="utf-8") if ENV.exists() else ""

def get_env(name):
    for line in text.splitlines():
        if line.startswith(name + "="):
            return line.split("=", 1)[1].strip()
    return ""

public = get_env("VAPID_PUBLIC_KEY")
private = get_env("VAPID_PRIVATE_KEY")

if public and private:
    print("VAPID já configurado. Nada a fazer.")
    raise SystemExit(0)

key = ec.generate_private_key(ec.SECP256R1())
private_bytes = key.private_numbers().private_value.to_bytes(32, "big")
public_bytes = key.public_key().public_bytes(
    serialization.Encoding.X962,
    serialization.PublicFormat.UncompressedPoint,
)

values = {
    "VAPID_PUBLIC_KEY": b64url(public_bytes),
    "VAPID_PRIVATE_KEY": b64url(private_bytes),
    "VAPID_CLAIMS_EMAIL": "mailto:ti@cen.local",
}

lines = text.splitlines()
for name, value in values.items():
    replaced = False
    for i, line in enumerate(lines):
        if line.startswith(name + "="):
            lines[i] = f"{name}={value}"
            replaced = True
            break
    if not replaced:
        lines.append(f"{name}={value}")

ENV.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("Chaves VAPID geradas e salvas no .env.")
print("IMPORTANTE: não compartilhe VAPID_PRIVATE_KEY.")
