from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file, abort, Response, has_request_context
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text, inspect
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
from pathlib import Path
from dotenv import load_dotenv
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from ldap3 import Server, Connection, ALL, SUBTREE
try:
    from pywebpush import webpush, WebPushException
except Exception:
    webpush = None
    WebPushException = Exception
import os
import hashlib
import time
import uuid
import mimetypes
import shutil
import re, io, zipfile, logging, secrets, ssl, threading, base64, json, urllib.parse, asyncio, socket

load_dotenv()

# ==========================================================
# CEN-CHAT - BANCO DEFINITIVO MARIADB / MYSQL
# ==========================================================
BASE_DIR = Path(__file__).resolve().parent
LOGS_DIR = BASE_DIR / "logs"
BACKUPS_DIR = BASE_DIR / "backups"
UPLOADS_DIR = BASE_DIR / "uploads"

for pasta in (LOGS_DIR, BACKUPS_DIR, UPLOADS_DIR):
    pasta.mkdir(exist_ok=True)

DEFAULT_DATABASE_URL = "mysql+pymysql://cenchat_user:SenhaForteCenChat2026@localhost:3306/cenchat?charset=utf8mb4"


APP_DIR = Path(__file__).resolve().parent
LOG_DIR = APP_DIR / "logs"
BACKUP_DIR = APP_DIR / "backups"
LOG_DIR.mkdir(exist_ok=True)
BACKUP_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY") or secrets.token_hex(32)

DATABASE_URL = os.getenv("DATABASE_URL", DEFAULT_DATABASE_URL).strip() or DEFAULT_DATABASE_URL
# O Cen-Chat usa exclusivamente MariaDB/MySQL. Qualquer URL diferente do
# driver MySQL oficial é ignorada para impedir uma configuração incompatível
# de derrubar a inicialização.
if not DATABASE_URL.lower().startswith(("mysql://", "mysql+mysqlconnector://", "mysql+pymysql://")):
    DATABASE_URL = DEFAULT_DATABASE_URL
app.config["SQLALCHEMY_DATABASE_URI"] = DATABASE_URL

app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_pre_ping": True,
    "pool_recycle": int(os.getenv("DB_POOL_RECYCLE", "1800")),
    "pool_size": int(os.getenv("DB_POOL_SIZE", "40")),
    "max_overflow": int(os.getenv("DB_MAX_OVERFLOW", "80")),
    "pool_timeout": int(os.getenv("DB_POOL_TIMEOUT", "30")),
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=int(os.getenv("SESSION_TIMEOUT_MINUTES", "480")))
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
# Anexos de chat: tamanho máximo por arquivo (padrão 20MB).
app.config["MAX_CONTENT_LENGTH"] = int(os.getenv("ANEXO_MAX_MB", "10")) * 1024 * 1024
ANEXO_EXTENSOES_BLOQUEADAS = {".exe", ".bat", ".cmd", ".sh", ".msi", ".com", ".scr", ".ps1", ".vbs", ".js", ".jar"}
# Reserva mínima de espaço livre em disco pra aceitar novo anexo — protege
# o servidor de encher o disco com uso intenso (centenas de pessoas
# mandando arquivo o dia todo). Configurável via .env se precisar ajustar.
ANEXO_ESPACO_MINIMO_MB = int(os.getenv("ANEXO_ESPACO_MINIMO_MB", "1024"))

def espaco_livre_suficiente(tamanho_arquivo_bytes):
    """Confere se sobra espaço em disco além da reserva mínima configurada."""
    try:
        livre = shutil.disk_usage(str(UPLOADS_DIR)).free
        reserva = ANEXO_ESPACO_MINIMO_MB * 1024 * 1024
        return livre - tamanho_arquivo_bytes > reserva
    except Exception:
        # Se não conseguir checar por algum motivo, não bloqueia o envio.
        return True

# Em rede interna usando HTTP, precisa ser false.
# Quando publicar em HTTPS, coloque COOKIE_SECURE=true no .env.
app.config["SESSION_COOKIE_SECURE"] = os.getenv("COOKIE_SECURE", "false").lower() == "true"

# SQLAlchemy precisa existir antes das classes dos modelos.
db = SQLAlchemy(app)

# WebSocket de tempo real — servidor asyncio dedicado em thread própria.
WS_HOST = os.getenv("WS_HOST", "0.0.0.0")
WS_PORT = int(os.getenv("WS_PORT", "5051"))
WS_TOKEN_MAX_AGE = int(os.getenv("WS_TOKEN_MAX_AGE", "7200"))
WS_PATH = os.getenv("WS_PATH", "/ws").strip() or "/ws"
if not WS_PATH.startswith("/"):
    WS_PATH = "/" + WS_PATH
WS_PATH = "/" + WS_PATH.strip("/") if WS_PATH != "/" else "/"

# Conexões WebSocket ativas: {usuario_id: {connections}}
_WS_CLIENTS = {}
_WS_LOCK = threading.RLock()
_WS_SERVER = None
_WS_THREAD = None
_WS_LOOP = None
_WS_READY = threading.Event()
_WS_START_ERROR = None
_WS_SERIALIZER_SALT = "cen-chat-websocket-v2"

# ==========================================================
# WEBSOCKET DE TEMPO REAL
# ==========================================================

def _ws_serializer():
    return URLSafeTimedSerializer(app.secret_key, salt=_WS_SERIALIZER_SALT)

def criar_ws_token(usuario_id):
    return _ws_serializer().dumps({"uid": int(usuario_id), "v": 2})

def validar_ws_token(token):
    if not token:
        return None
    try:
        payload = _ws_serializer().loads(token, max_age=WS_TOKEN_MAX_AGE)
        if int(payload.get("v", 0)) != 2:
            return None
        uid = int(payload.get("uid"))
        return uid if uid > 0 else None
    except (BadSignature, SignatureExpired, ValueError, TypeError):
        return None
    except Exception:
        logging.exception("Falha ao validar token WebSocket")
        return None

def _ws_add_client(user_id, conn):
    with _WS_LOCK:
        _WS_CLIENTS.setdefault(int(user_id), set()).add(conn)

def _ws_remove_client(user_id, conn):
    with _WS_LOCK:
        grupo = _WS_CLIENTS.get(int(user_id))
        if not grupo:
            return
        grupo.discard(conn)
        if not grupo:
            _WS_CLIENTS.pop(int(user_id), None)

def ws_client_count():
    with _WS_LOCK:
        return sum(len(conns) for conns in _WS_CLIENTS.values())

async def _ws_send_async(conn, payload):
    try:
        await conn.send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
        return True
    except Exception:
        return False

def _schedule_ws_send(user_id, conn, payload):
    loop = _WS_LOOP
    if loop is None or not loop.is_running():
        return False
    try:
        fut = asyncio.run_coroutine_threadsafe(_ws_send_async(conn, payload), loop)
        def _done(f):
            try:
                ok = bool(f.result())
            except Exception:
                ok = False
            if not ok:
                _ws_remove_client(user_id, conn)
        fut.add_done_callback(_done)
        return True
    except Exception:
        return False

def ws_send_to_users(user_ids, payload):
    """Entrega um evento aos WebSockets sem bloquear a requisição HTTP."""
    alvo = {int(uid) for uid in (user_ids or []) if uid is not None}
    if not alvo:
        return

    destinos = []
    with _WS_LOCK:
        for uid in alvo:
            destinos.extend((uid, conn) for conn in list(_WS_CLIENTS.get(uid, ())))

    for uid, conn in destinos:
        if not _schedule_ws_send(uid, conn, payload):
            _ws_remove_client(uid, conn)

async def _ws_handler(conn):
    """Handler asyncio do servidor WebSocket."""
    user_id = None
    try:
        request = getattr(conn, "request", None)
        if request is None:
            await conn.close(code=1011, reason="Handshake não disponível")
            return
        parsed = urllib.parse.urlparse(getattr(request, "path", "") or "")
        if parsed.path != WS_PATH:
            await conn.close(code=1008, reason="Rota WebSocket inválida")
            return

        token = urllib.parse.parse_qs(parsed.query).get("token", [None])[0]
        user_id = validar_ws_token(token)
        if not user_id:
            await conn.close(code=1008, reason="Token inválido ou expirado")
            return

        _ws_add_client(user_id, conn)
        await _ws_send_async(conn, {
            "type": "connected",
            "user_id": user_id,
            "server_time": now(),
            "ws_port": WS_PORT,
        })
        logging.info("WebSocket conectado: usuário %s", user_id)

        async for raw in conn:
            try:
                if not raw:
                    continue
                data = json.loads(raw)
                tipo = data.get("type")
                if tipo == "ping":
                    await _ws_send_async(conn, {"type": "pong", "server_time": now()})
            except Exception:
                continue
    except Exception:
        logging.exception("Erro no handler WebSocket")
    finally:
        if user_id is not None:
            _ws_remove_client(user_id, conn)
            logging.info("WebSocket desconectado: usuário %s", user_id)


def iniciar_websocket():
    """Inicia o WebSocket em uma thread asyncio e confirma o bind antes de subir o HTTP."""
    global _WS_SERVER, _WS_THREAD, _WS_LOOP, _WS_START_ERROR

    if _WS_THREAD and _WS_THREAD.is_alive() and _WS_SERVER is not None:
        return True

    _WS_READY.clear()
    _WS_START_ERROR = None

    try:
        from websockets.asyncio.server import serve
    except Exception as exc:
        _WS_START_ERROR = f"biblioteca/versão do websockets indisponível: {exc}"
        logging.exception(_WS_START_ERROR)
        print(f"ERRO WebSocket: {_WS_START_ERROR}", flush=True)
        return False

    def worker():
        global _WS_SERVER, _WS_LOOP, _WS_START_ERROR
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        _WS_LOOP = loop
        server = None
        try:
            async def bind_server():
                return await serve(
                    _ws_handler,
                    WS_HOST,
                    WS_PORT,
                    ping_interval=20,
                    ping_timeout=20,
                    close_timeout=10,
                    max_size=2 * 1024 * 1024,
                    max_queue=1024,
                    server_header="Cen-Chat-WebSocket",
                )

            print(f"WebSocket: tentando abrir ws://{WS_HOST}:{WS_PORT}{WS_PATH}...", flush=True)
            server = loop.run_until_complete(bind_server())
            _WS_SERVER = server
            _WS_READY.set()
            logging.info("WebSocket ativo em ws://%s:%s%s", WS_HOST, WS_PORT, WS_PATH)
            print(f"OK: WebSocket ativo em ws://{WS_HOST}:{WS_PORT}{WS_PATH}", flush=True)
            loop.run_forever()
        except Exception as exc:
            _WS_START_ERROR = f"{type(exc).__name__}: {exc}"
            logging.exception("Servidor WebSocket encerrou com erro")
            print(f"ERRO WebSocket: {_WS_START_ERROR}", flush=True)
            _WS_READY.set()
        finally:
            try:
                if server is not None:
                    server.close()
                    loop.run_until_complete(server.wait_closed())
            except Exception:
                logging.exception("Falha ao encerrar o servidor WebSocket")
            _WS_SERVER = None
            _WS_LOOP = None
            try:
                loop.close()
            except Exception:
                pass

    _WS_THREAD = threading.Thread(target=worker, name="cen-chat-websocket", daemon=True)
    _WS_THREAD.start()

    # O bind precisa ser confirmado antes do HTTP. Se houver porta ocupada,
    # firewall/bind incompatível ou erro de biblioteca, o terminal mostra o
    # erro real em vez de deixar a aplicação em um falso "conectando".
    if not _WS_READY.wait(timeout=8):
        _WS_START_ERROR = _WS_START_ERROR or "timeout aguardando o bind do WebSocket (8s)"
        print(f"ERRO WebSocket: {_WS_START_ERROR}", flush=True)
        return False

    if _WS_SERVER is not None and _WS_THREAD.is_alive():
        return True

    print(f"ERRO WebSocket: {_WS_START_ERROR or 'o servidor não confirmou o bind'}", flush=True)
    return False

def mensagem_para_evento(msg):
    """Payload enxuto e completo para atualização incremental do chat."""
    anexo = None
    if getattr(msg, "anexo_caminho", None) and not getattr(msg, "apagado_em", None):
        # Dentro de uma requisição HTTP url_for gera a URL absoluta/relativa correta.
        anexo = {
            "nome": msg.anexo_nome,
            "tipo": msg.anexo_tipo,
            "tamanho": msg.anexo_tamanho,
            "url": url_for("api_anexo", msg_id=msg.id),
            "imagem": bool(msg.anexo_tipo and msg.anexo_tipo.startswith("image/")),
        }
    resposta = None
    if getattr(msg, "resposta_a_id", None):
        original = db.session.get(Mensagem, msg.resposta_a_id)
        if original:
            resposta = {
                "id": int(original.id),
                "remetente_id": int(original.remetente_id),
                "remetente_nome": original.remetente.nome if original.remetente else "",
                "texto": "Mensagem apagada" if getattr(original, "apagado_em", None) else (original.texto or "")[:140],
            }
    encaminhada = None
    if getattr(msg, "encaminhada_de_id", None):
        u = db.session.get(Usuario, msg.encaminhada_de_id)
        encaminhada = u.nome if u else None
    return {
        "id": int(msg.id),
        "conversa_id": int(msg.conversa_id),
        "remetente_id": int(msg.remetente_id),
        "remetente_nome": msg.remetente.nome if getattr(msg, "remetente", None) else "",
        "texto": "Mensagem apagada" if getattr(msg, "apagado_em", None) else (msg.texto or ""),
        "enviado_em": msg.enviado_em,
        "lido": bool(getattr(msg, "lido_em", None)),
        "apagado": bool(getattr(msg, "apagado_em", None)),
        "editado": bool(getattr(msg, "editado", False)),
        "fixado": bool(getattr(msg, "fixado", False)),
        "resposta_a": resposta,
        "anexo": anexo,
        "encaminhada_de": encaminhada,
        "reacoes": [],
    }

# ==========================================================
# CONFIGURAÇÕES GERAIS
# ==========================================================

DEFAULT_VAL_PASSWORD = os.getenv("VAL_DEFAULT_PASSWORD", "Cen1850*")
MAX_LOGIN_ATTEMPTS = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))
LOCKOUT_MINUTES = int(os.getenv("LOCKOUT_MINUTES", "10"))

CHAT_MESSAGES_DEFAULT_LIMIT = int(os.getenv("CHAT_MESSAGES_DEFAULT_LIMIT", "100"))
CHAT_MESSAGES_MAX_LIMIT = int(os.getenv("CHAT_MESSAGES_MAX_LIMIT", "500"))
UNREAD_MAX_CONVERSAS = int(os.getenv("UNREAD_MAX_CONVERSAS", "80"))
PING_DB_INTERVAL_SECONDS = int(os.getenv("PING_DB_INTERVAL_SECONDS", "45"))
DIGITANDO_EXPIRA_SECONDS = int(os.getenv("DIGITANDO_EXPIRA_SECONDS", "8"))

# ==========================================================
# WEB PUSH (notificações mesmo com o navegador fechado)
# ==========================================================
VAPID_PUBLIC_KEY = os.getenv("VAPID_PUBLIC_KEY", "").strip()
VAPID_PRIVATE_KEY = os.getenv("VAPID_PRIVATE_KEY", "").strip()
VAPID_CLAIMS_EMAIL = os.getenv("VAPID_CLAIMS_EMAIL", "mailto:ti@cen.local").strip()
WEB_PUSH_ENABLED = bool(VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY and webpush)

# Detecta uma troca de chaves VAPID entre versões e invalida as inscrições
# antigas. Isso evita 403 repetidos no terminal quando o navegador ainda
# possui uma inscrição criada com outro par de chaves.
VAPID_FINGERPRINT_FILE = BASE_DIR / ".vapid_fingerprint"

def _prepare_vapid_subscription_state():
    if not WEB_PUSH_ENABLED:
        return
    try:
        fp = hashlib.sha256(VAPID_PUBLIC_KEY.encode("utf-8")).hexdigest()[:24]
        previous = VAPID_FINGERPRINT_FILE.read_text(encoding="utf-8").strip() if VAPID_FINGERPRINT_FILE.exists() else ""
        if previous != fp:
            cleared = False
            try:
                with app.app_context():
                    PushSubscription.query.delete(synchronize_session=False)
                    db.session.commit()
                    cleared = True
            except Exception:
                db.session.rollback()
                logging.exception("Não foi possível limpar inscrições Web Push antigas.")
            if cleared:
                VAPID_FINGERPRINT_FILE.write_text(fp, encoding="utf-8")
    except Exception:
        logging.exception("Falha ao preparar estado do Web Push.")

THEMES = {
    "verde-clinica": "Verde",
    "oceano": "Azul Oceano",
    "aurora": "Aurora",
    "preto-noite": "Preto",
    "grafite-pro": "Grafite",
    "vinho-premium": "Vinho",
    "ciano-neon": "Ciano",
    "lima-tech": "Lima",
    "laranja-spark": "Laranja",
    "rosa-pink": "Rosa",
    "amarelo": "Amarelo",
    "menta": "Menta",
    "turquesa-suave": "Turquesa",
    "coral-quente": "Coral",
    "indigo-executivo": "Índigo",
    "verde-salvia": "Sálvia",
    # Temas extras escolhidos: o antigo "Areia" foi renomeado para "Laranja Claro".
    "laranja-claro": "Laranja Claro",
    "vermelho-normal": "Vermelho",
}

STATUS_LABELS = {
    "online": "🟢 Online",
    "ausente": "🟡 Ausente",
    "ocupado": "🔴 Ocupado",
    "invisivel": "⚫ Invisível",
    "offline": "⚪ Offline",
}

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

STALE_PING_SECONDS = 150  # ~2.5x o intervalo do heartbeat do front-end (60s)

def status_efetivo(u):
    """Status 'de verdade' pra mostrar pros outros usuários.

    Se o campo status diz 'online' mas o heartbeat (ultimo_ping) já passou
    muito do esperado, tratamos como offline mesmo assim. Isso cobre o caso
    de alguém fechar a aba/navegador ou o processo travar sem passar pelo
    /logout — sem essa checagem a pessoa fica "online" pra sempre pros outros
    até logar de novo.
    """
    status = u.status or "offline"
    if status == "online":
        ping = u.ultimo_ping
        if not ping:
            return "offline"
        try:
            ping_dt = datetime.strptime(ping, "%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError):
            return "offline"
        if (datetime.now() - ping_dt).total_seconds() > STALE_PING_SECONDS:
            return "offline"
    return status

def dt_parse(value):
    if not value:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
    except Exception:
        return None

def slugify(txt):
    txt = (txt or "").strip().lower()
    repl = {"á":"a","à":"a","ã":"a","â":"a","é":"e","ê":"e","í":"i","ó":"o","õ":"o","ô":"o","ú":"u","ç":"c"}
    for a,b in repl.items():
        txt = txt.replace(a,b)
    return re.sub(r"[^a-z0-9]+", "-", txt).strip("-") or "setor"

def slugify_unico(txt, excluir_id=None):
    """Gera um slug único sem fundir setores ou impedir nomes semelhantes."""
    base = slugify(txt)
    candidato = base
    n = 2
    while True:
        q = Setor.query.filter_by(slug=candidato)
        if excluir_id is not None:
            q = q.filter(Setor.id != excluir_id)
        if not q.first():
            return candidato
        candidato = f"{base}-{n}"
        n += 1

# ==========================================================
# MODELOS DO BANCO
# ==========================================================
# Os modelos usam MariaDB/MySQL através do SQLAlchemy + PyMySQL.

class Setor(db.Model):
    __tablename__ = "setores"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(120), nullable=False)
    slug = db.Column(db.String(120), unique=True, nullable=False)
    descricao = db.Column(db.Text, default="")
    ativo = db.Column(db.Boolean, default=True)
    criado_em = db.Column(db.String(19), default=now)

class Usuario(db.Model):
    __tablename__ = "usuarios"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(160), nullable=False)
    usuario = db.Column(db.String(120), unique=True, nullable=False)
    senha_hash = db.Column(db.String(255))
    perfil = db.Column(db.String(40), default="usuario")
    setor_id = db.Column(db.Integer, db.ForeignKey("setores.id"))
    # Quando True, a associação de setor foi definida manualmente no Cen-Chat
    # e o LDAP não pode substituí-la. Usuários novos importados do AD começam
    # com False e seguem o setor do grupo LDAP até um administrador fixá-los.
    setor_manual = db.Column(db.Boolean, default=False, nullable=False)
    ativo = db.Column(db.Boolean, default=True)
    aguardando_setor = db.Column(db.Boolean, default=True)
    local_emergencia = db.Column(db.Boolean, default=False)
    origem_login = db.Column(db.String(30), default="local")  # local ou ldap
    tema = db.Column(db.String(80), default="verde-clinica")
    status = db.Column(db.String(40), default="online")
    mensagem_ausencia = db.Column(db.String(250), default="")
    som_notificacao = db.Column(db.Boolean, default=True)
    bloqueio_inatividade = db.Column(db.Boolean, default=True)
    # Preferência individual: o usuário escolhe nas Configurações se quer
    # a animação de tremida quando chegar mensagem nova.
    tremer_tela = db.Column(db.Boolean, default=True)
    tentativas_login = db.Column(db.Integer, default=0)
    bloqueado_ate = db.Column(db.String(19))
    criado_em = db.Column(db.String(19), default=now)
    ultimo_login = db.Column(db.String(19))
    ultimo_ping = db.Column(db.String(19))
    # Preferências novas: tutorial de primeiro acesso e "visto por último".
    tour_concluido = db.Column(db.Boolean, default=False)
    mostrar_ultimo_visto = db.Column(db.Boolean, default=True)

    setor = db.relationship("Setor")

class PushSubscription(db.Model):
    __tablename__ = "push_subscriptions"
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    endpoint = db.Column(db.String(2048), nullable=False, unique=True)
    p256dh = db.Column(db.String(255), nullable=False)
    auth = db.Column(db.String(255), nullable=False)
    criado_em = db.Column(db.String(19), default=now)
    atualizado_em = db.Column(db.String(19), default=now)
    usuario = db.relationship("Usuario")

class PermissaoSetor(db.Model):
    __tablename__ = "permissoes_setores"
    id = db.Column(db.Integer, primary_key=True)
    origem_id = db.Column(db.Integer, db.ForeignKey("setores.id"), nullable=False)
    destino_id = db.Column(db.Integer, db.ForeignKey("setores.id"), nullable=False)
    permitido = db.Column(db.Boolean, default=True)
    __table_args__ = (db.UniqueConstraint("origem_id", "destino_id", name="uq_perm_origem_destino"),)

class Conversa(db.Model):
    __tablename__ = "conversas"
    id = db.Column(db.Integer, primary_key=True)
    usuario_a_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    usuario_b_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    criado_em = db.Column(db.String(19), default=now)
    atualizado_em = db.Column(db.String(19), default=now)
    __table_args__ = (db.UniqueConstraint("usuario_a_id", "usuario_b_id", name="uq_conversa_par"),)

class Mensagem(db.Model):
    __tablename__ = "mensagens"
    id = db.Column(db.Integer, primary_key=True)
    conversa_id = db.Column(db.Integer, db.ForeignKey("conversas.id"), nullable=False)
    remetente_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    texto = db.Column(db.Text, nullable=False)
    enviado_em = db.Column(db.String(19), default=now)
    lido_em = db.Column(db.String(19))
    apagado_por_remetente = db.Column(db.Boolean, default=False)
    apagado_por_destinatario = db.Column(db.Boolean, default=False)
    apagado_em = db.Column(db.String(19))
    resposta_a_id = db.Column(db.Integer, db.ForeignKey("mensagens.id"))
    fixado = db.Column(db.Boolean, default=False)
    fixado_em = db.Column(db.String(19))
    editado = db.Column(db.Boolean, default=False)
    editado_em = db.Column(db.String(19))
    anexo_nome = db.Column(db.String(255))
    anexo_caminho = db.Column(db.String(500))
    anexo_tipo = db.Column(db.String(120))
    anexo_tamanho = db.Column(db.Integer)
    encaminhada_de_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"))

    # Relacionamento explícito para que as consultas de mensagens possam
    # acessar m.remetente.nome com segurança ao carregar o histórico.
    remetente = db.relationship("Usuario", foreign_keys=[remetente_id], lazy="joined")
    encaminhada_de = db.relationship("Usuario", foreign_keys=[encaminhada_de_id], lazy="joined")

class Reacao(db.Model):
    __tablename__ = "reacoes"
    id = db.Column(db.Integer, primary_key=True)
    mensagem_id = db.Column(db.Integer, db.ForeignKey("mensagens.id"), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    emoji = db.Column(db.String(16), nullable=False)
    criado_em = db.Column(db.String(19), default=now)
    remetente = db.relationship("Usuario")

class Favorito(db.Model):
    __tablename__ = "favoritos"
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    favorito_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    criado_em = db.Column(db.String(19), default=now)
    __table_args__ = (db.UniqueConstraint("usuario_id", "favorito_id", name="uq_favorito"),)

class Digitando(db.Model):
    __tablename__ = "digitando"
    id = db.Column(db.Integer, primary_key=True)
    conversa_id = db.Column(db.Integer, db.ForeignKey("conversas.id"), nullable=False)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False)
    atualizado_em = db.Column(db.String(19), default=now)
    __table_args__ = (db.UniqueConstraint("conversa_id", "usuario_id", name="uq_digitando"),)

class AvisoGeral(db.Model):
    __tablename__ = "avisos_gerais"
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(160), nullable=False)
    texto = db.Column(db.Text, nullable=False)
    ativo = db.Column(db.Boolean, default=True)
    criado_por = db.Column(db.Integer, db.ForeignKey("usuarios.id"))
    criado_em = db.Column(db.String(19), default=now)

class Log(db.Model):
    __tablename__ = "logs"
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"))
    acao = db.Column(db.Text, nullable=False)
    criado_em = db.Column(db.String(19), default=now)
    categoria = db.Column(db.String(60), default="geral")
    usuario = db.relationship("Usuario")

# ==========================================================
# LDAP / AD - CONFIGURAÇÃO PRINCIPAL
# ==========================================================
# Cen-Chat antigo preservado + LDAP funcional.
# Login aceito: alef.menezes
# O sistema busca no AD por sAMAccountName e valida a senha pelo DN encontrado.
# Não usa NTLM, não usa MD4 e não altera nada no AD.

def env_bool(nome, padrao="false"):
    return os.getenv(nome, padrao).lower() in ["1", "true", "yes", "sim", "on"]

def ldap_enabled():
    return env_bool("LDAP_ENABLED", "true")

def ldap_normalizar_login(usuario):
    usuario = (usuario or "").strip()
    if "\\" in usuario:
        usuario = usuario.split("\\", 1)[1]
    if "@" in usuario:
        usuario = usuario.split("@", 1)[0]
    return usuario.lower()

def ldap_config():
    return {
        "server": os.getenv("LDAP_SERVER", "192.168.52.250"),
        "domain": os.getenv("LDAP_DOMAIN", "cen.local"),
        "netbios": os.getenv("LDAP_NETBIOS_DOMAIN", "CEN"),
        "base_dn": os.getenv("LDAP_BASE_DN", "DC=cen,DC=local"),
        "bind_user": os.getenv("LDAP_BIND_USER", "intranet@cen.local"),
        "bind_password": os.getenv("LDAP_BIND_PASSWORD", ""),
        "port": int(os.getenv("LDAP_PORT", "389")),
        "use_ssl": env_bool("LDAP_USE_SSL", "false"),
        "user_attr": os.getenv("LDAP_USER_ATTRIBUTE", os.getenv("LDAP_LOGIN_ATTRIBUTE", "sAMAccountName")),
        "name_attr": os.getenv("LDAP_NAME_ATTRIBUTE", "displayName"),
        "mail_attr": os.getenv("LDAP_MAIL_ATTRIBUTE", "mail"),
        "admin_group": os.getenv("LDAP_GROUP_ADMIN", "Admins. do domínio"),
    }

def ldap_setor_group_map():
    """Somente os grupos que representam setores do Cen-Chat.

    O LDAP importa usuários a partir destes grupos e usa o setor mapeado
    como valor inicial/localizável. Depois que um administrador fixa um
    usuário em outro setor, o campo setor_manual impede novas substituições.
    """
    return {
        os.getenv("LDAP_GROUP_TI", "TI"): {"perfil": "usuario", "setor_slug": "ti"},
        os.getenv("LDAP_GROUP_MARCACAO", "Marcacao"): {"perfil": "usuario", "setor_slug": "marcacao"},
        "Marcação": {"perfil": "usuario", "setor_slug": "marcacao"},
        os.getenv("LDAP_GROUP_FATURAMENTO", "Faturamento"): {"perfil": "usuario", "setor_slug": "faturamento"},
        os.getenv("LDAP_GROUP_FINANCEIRO", "Financeiro"): {"perfil": "usuario", "setor_slug": "financeiro"},
        os.getenv("LDAP_GROUP_APOIO", "Apoio"): {"perfil": "usuario", "setor_slug": "apoio"},
        os.getenv("LDAP_GROUP_RECEPCAO", "Recepcao"): {"perfil": "usuario", "setor_slug": "recepcao"},
        "Recepção": {"perfil": "usuario", "setor_slug": "recepcao"},
        os.getenv("LDAP_GROUP_CONFERENCIA", "Conferencia"): {"perfil": "usuario", "setor_slug": "conferencia"},
        "Conferência": {"perfil": "usuario", "setor_slug": "conferencia"},
        os.getenv("LDAP_GROUP_NACEN", "Nacen"): {"perfil": "usuario", "setor_slug": "nacen"},
        os.getenv("LDAP_GROUP_PROFISSIONAIS", "Profissionais"): {"perfil": "usuario", "setor_slug": "profissionais"},
        os.getenv("LDAP_GROUP_ALMOXARIFADO", "Almoxarifado"): {"perfil": "usuario", "setor_slug": "almoxarifado"},
        os.getenv("LDAP_GROUP_SECRETARIAS", "Secretarias"): {"perfil": "usuario", "setor_slug": "secretarias"},
    }

def ldap_group_map():
    """Mapa completo para compatibilidade; a sincronização usa somente os grupos de setor."""
    groups = dict(ldap_setor_group_map())
    groups[os.getenv("LDAP_GROUP_ADMIN", "Admins. do domínio")] = {"perfil": "adm", "setor_slug": "ti"}
    if env_bool("LDAP_IMPORTAR_GRUPOS_EXTRAS", "false"):
        groups.update({
            "Glpi-Atendente-TI": {"perfil": "usuario", "setor_slug": "ti"},
            "Suporte_AD": {"perfil": "usuario", "setor_slug": "ti"},
            "NTFS_EN_TI_WR": {"perfil": "usuario", "setor_slug": "ti"},
            "NTFS_ALL_BACKUP": {"perfil": "usuario", "setor_slug": "ti"},
        })
    return groups

def ldap_server():
    from ldap3 import Server, ALL
    cfg = ldap_config()
    return Server(cfg["server"], port=cfg["port"], use_ssl=cfg["use_ssl"], get_info=ALL)

def ldap_bind_candidates(usuario):
    cfg = ldap_config()
    usuario = (usuario or "").strip()

    if "\\" in usuario or "@" in usuario:
        return [usuario]

    candidatos = []
    if cfg["domain"]:
        candidatos.append(f"{usuario}@{cfg['domain']}")
    if cfg["netbios"]:
        candidatos.append(f"{cfg['netbios']}\\{usuario}")
    candidatos.append(usuario)
    return candidatos

def ldap_conectar_servico():
    from ldap3 import Connection
    cfg = ldap_config()
    server = ldap_server()
    ultimo_erro = None

    for bind_user in ldap_bind_candidates(cfg["bind_user"]):
        try:
            return Connection(server, user=bind_user, password=cfg["bind_password"], auto_bind=True)
        except Exception as e:
            ultimo_erro = e

    raise ultimo_erro

def ldap_cn_from_dn(dn):
    m = re.search(r"CN=([^,]+)", str(dn), re.I)
    return m.group(1) if m else str(dn)

def ldap_grupos_do_entry(entry):
    grupos = []
    try:
        for dn in entry.memberOf.values:
            grupos.append(ldap_cn_from_dn(str(dn)))
    except Exception:
        pass
    return grupos

def ldap_buscar_usuario(conn, usuario_login):
    from ldap3 import SUBTREE
    cfg = ldap_config()
    usuario_limpo = ldap_normalizar_login(usuario_login)

    filtro = f"(&(objectClass=user)({cfg['user_attr']}={usuario_limpo}))"
    atributos = [
        cfg["name_attr"],
        cfg["user_attr"],
        cfg["mail_attr"],
        "memberOf",
        "distinguishedName",
        "userPrincipalName",
        "userAccountControl",
    ]

    conn.search(
        search_base=cfg["base_dn"],
        search_filter=filtro,
        search_scope=SUBTREE,
        attributes=atributos
    )

    if not conn.entries:
        return None

    return conn.entries[0]

def ldap_validar_senha_usuario(usuario_login, senha, user_dn=None, upn=None):
    from ldap3 import Connection

    if not senha:
        raise RuntimeError("Senha vazia.")

    server = ldap_server()
    cfg = ldap_config()
    usuario_limpo = ldap_normalizar_login(usuario_login)

    # O teste da clínica validou pelo DN; por isso o DN vem primeiro.
    tentativas = []
    if user_dn:
        tentativas.append(user_dn)
    if upn:
        tentativas.append(upn)
    if cfg["domain"]:
        tentativas.append(f"{usuario_limpo}@{cfg['domain']}")
    if cfg["netbios"]:
        tentativas.append(f"{cfg['netbios']}\\{usuario_limpo}")

    ultimo_erro = None
    for user_bind in tentativas:
        try:
            c = Connection(server, user=user_bind, password=senha, auto_bind=True)
            c.unbind()
            return True
        except Exception as e:
            ultimo_erro = e

    raise ultimo_erro

def ldap_mapear_perfil_setor(grupos_nomes):
    grupos_lower = [str(g).strip().lower() for g in (grupos_nomes or [])]
    perfil = "usuario"
    setor_slug = None

    mapa = dict(ldap_setor_group_map())
    mapa[os.getenv("LDAP_GROUP_ADMIN", "Admins. do domínio")] = {"perfil": "adm", "setor_slug": "ti"}
    if env_bool("LDAP_IMPORTAR_GRUPOS_EXTRAS", "false"):
        mapa.update({
            "Glpi-Atendente-TI": {"perfil": "usuario", "setor_slug": "ti"},
            "Suporte_AD": {"perfil": "usuario", "setor_slug": "ti"},
            "NTFS_EN_TI_WR": {"perfil": "usuario", "setor_slug": "ti"},
            "NTFS_ALL_BACKUP": {"perfil": "usuario", "setor_slug": "ti"},
        })

    for grupo_ad, destino in mapa.items():
        grupo_lower = str(grupo_ad).strip().lower()
        if grupo_lower in grupos_lower:
            if destino.get("perfil") == "adm":
                perfil = "adm"
            if not setor_slug and destino.get("setor_slug"):
                setor_slug = destino["setor_slug"]

    return perfil, setor_slug

def ldap_entry_to_info(entry, usuario_fallback=None):
    cfg = ldap_config()

    usuario = usuario_fallback or ""
    try:
        usuario = str(getattr(entry, cfg["user_attr"]))
    except Exception:
        pass
    usuario = ldap_normalizar_login(usuario)

    nome = usuario
    try:
        nome = str(getattr(entry, cfg["name_attr"])) or usuario
    except Exception:
        pass

    email = ""
    try:
        email = str(getattr(entry, cfg["mail_attr"])) or ""
    except Exception:
        pass

    upn = ""
    try:
        upn = str(entry.userPrincipalName) or ""
    except Exception:
        pass

    grupos = ldap_grupos_do_entry(entry)
    perfil, _setor_slug_ad = ldap_mapear_perfil_setor(grupos)
    setor_slug_ad = _setor_slug_ad

    ativo_ad = True
    try:
        uac = int(str(entry.userAccountControl))
        # Bit 2 ligado no AD significa conta desativada.
        ativo_ad = not bool(uac & 2)
    except Exception:
        ativo_ad = True

    return {
        "usuario": usuario,
        "nome": nome or usuario,
        "email": email,
        "upn": upn,
        "dn": entry.entry_dn,
        "grupos": grupos,
        "perfil": perfil,
        # O LDAP informa o setor de origem do AD. Se o administrador fixar
        # o usuário em outro setor no Cen-Chat, setor_manual passa a prevalecer.
        "setor_slug": setor_slug_ad,
        "ativo_ad": ativo_ad,
    }

def autenticar_ldap(usuario_login, senha):
    """Autentica no AD sem NTLM/MD4."""
    if not ldap_enabled():
        return None

    conn = ldap_conectar_servico()
    try:
        entry = ldap_buscar_usuario(conn, usuario_login)
        if not entry:
            return None

        info = ldap_entry_to_info(entry, usuario_login)
        ldap_validar_senha_usuario(usuario_login, senha, user_dn=info.get("dn"), upn=info.get("upn"))
        return info
    finally:
        try:
            conn.unbind()
        except Exception:
            pass

def get_or_create_setor_by_slug(setor_slug):
    """Mantém compatibilidade, mas o LDAP nunca cria nem escolhe setores.

    A sincronização LDAP pode continuar enviando um slug de grupo para fins
    de filtro/compatibilidade, porém o setor do Cen-Chat é exclusivamente
    local e esta função apenas consulta um setor já existente.
    """
    if not setor_slug:
        return None
    try:
        return Setor.query.filter_by(slug=str(setor_slug).strip().lower(), ativo=True).first()
    except Exception:
        db.session.rollback()
        return None

# ==========================================================
# REGRAS LOCAIS DE ORGANIZAÇÃO LDAP
# O LDAP continua sendo usado para autenticação e descoberta dos usuários,
# mas estas regras têm prioridade absoluta sobre os setores no Cen-Chat.
# ==========================================================
def _ldap_norm_text(value):
    import unicodedata
    txt = str(value or "").strip().lower()
    txt = unicodedata.normalize("NFKD", txt)
    txt = "".join(ch for ch in txt if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", txt).strip()

LDAP_REGRAS_SETORES = {
    "almoxarifado": {"gabrielly sena", "egla oliveira"},
    "marcacao": {"amanda andrade"},
    "secretarias": {"adriele faleiro", "maichele amorim"},
}
LDAP_EXCLUIR = {"leonardo onclin", "suporte onfire", "onfire onfrie"}
LDAP_TI_PRESERVAR = {"miguel silva", "alef menezes", "valdirene"}

def usuario_ldap_bloqueado_por_regra(u=None, nome=None, login=None):
    nome_n = _ldap_norm_text(nome if nome is not None else getattr(u, "nome", ""))
    login_n = _ldap_norm_text(login if login is not None else getattr(u, "usuario", ""))
    if nome_n in LDAP_EXCLUIR or login_n in LDAP_EXCLUIR:
        return True
    if "leonardo onclin" in {nome_n, login_n}:
        return True
    if any(v in nome_n for v in ("onfire", "onfrie")) or any(v in login_n for v in ("onfire", "onfrie")):
        return True
    return False

def ldap_regra_setor_para_info(info):
    """Compatibilidade: LDAP não define mais setor local."""
    if usuario_ldap_bloqueado_por_regra(nome=info.get("nome"), login=info.get("usuario")):
        return "__EXCLUIR__"
    return None

def ldap_regra_setor_para_usuario(u):
    return None

def garantir_setores_regras_ldap():
    """Mantido por compatibilidade; não cria nem altera setores via LDAP."""
    return None

def aplicar_regras_ldap_fixas(usuarios_info=None):
    """No-op intencional: a organização de setores é 100% manual/local."""
    return None


def upsert_usuario_ldap(info, status_inicial="offline"):
    """Importa/atualiza usuário LDAP sem deixar o AD controlar setor ou ativo.

    - novo usuário: ativo e sem setor;
    - usuário existente: preserva setor_id e ativo do Cen-Chat;
    - LDAP nunca cria setores;
    - LDAP nunca altera setor_id;
    - LDAP nunca altera ativo;
    - ausência/remoção no AD não desativa a conta local.
    """
    usuario_login = ldap_normalizar_login(info.get("usuario"))
    if not usuario_login:
        return None, "ignorado"

    u = Usuario.query.filter_by(usuario=usuario_login).first()
    criado = False

    if not u:
        u = Usuario(
            nome=info.get("nome") or usuario_login,
            usuario=usuario_login,
            senha_hash=None,
            perfil=info.get("perfil") or "usuario",
            setor_id=None,
            setor_manual=False,
            ativo=True,
            aguardando_setor=True,
            local_emergencia=False,
            origem_login="ldap",
            status=status_inicial,
            criado_em=now(),
        )
        db.session.add(u)
        criado = True
    else:
        if not u.local_emergencia:
            u.nome = info.get("nome") or u.nome
            # Só promovemos perfil quando o LDAP realmente informa admin.
            if info.get("perfil") == "adm":
                u.perfil = "adm"
            elif not u.perfil:
                u.perfil = "usuario"
            u.origem_login = "ldap"
            # NÃO tocar em setor_id nem ativo. Essas duas propriedades
            # pertencem exclusivamente à administração local.
            u.aguardando_setor = u.setor_id is None
            if not u.status:
                u.status = status_inicial

    db.session.commit()
    return u, "criado" if criado else "atualizado"

def desativar_ldap_nao_sincronizados(usuarios_ativos_sync):
    """LEGADO: mantido por compatibilidade, mas não altera o banco.

    O LDAP não pode desativar usuários locais. A ausência de um usuário em
    uma sincronização pode ocorrer por filtro/grupo do AD, alteração de
    associação ou indisponibilidade temporária. A situação ativo/inativo do
    Cen-Chat pertence exclusivamente ao controle local.
    """
    return None



def iniciar_sync_ldap_background():
    """Sincroniza usuários LDAP em segundo plano, sem bloquear a abertura do Cen-Chat."""
    if not ldap_enabled() or os.getenv("LDAP_SYNC_ON_START", "true").lower() not in {"1","true","yes","on"}:
        return
    def worker():
        try:
            with app.app_context():
                resultado = sync_ldap_users()
                logging.info("LDAP inicial: %s criados, %s atualizados, %s erros", resultado.get("criados",0), resultado.get("atualizados",0), len(resultado.get("erros",[])))
        except Exception:
            logging.exception("Sincronização LDAP inicial falhou")
    threading.Thread(target=worker, name="cen-chat-ldap-startup", daemon=True).start()

def sync_ldap_users(setor_slug=None):
    """Importa usuários dos grupos configurados no AD para o banco local.

    O LDAP é usado somente para descobrir/autenticar os usuários que pertencem
    aos grupos configurados. Setor, ativo/inativo e demais decisões de
    organização interna permanecem no Cen-Chat e não são sobrescritos pelo AD.
    """
    from ldap3 import SUBTREE
    from ldap3.utils.conv import escape_filter_chars

    conn = ldap_conectar_servico()
    resultado = {
        "criados": 0,
        "atualizados": 0,
        "ignorados": 0,
        "grupos_nao_encontrados": [],
        "erros": [],
        "usuarios": [],
    }

    try:
        encontrados = {}
        cfg = ldap_config()

        grupos_importacao = dict(ldap_setor_group_map())
        grupos_importacao[os.getenv("LDAP_GROUP_ADMIN", "Admins. do domínio")] = {"perfil": "adm", "setor_slug": "ti"}
        if env_bool("LDAP_IMPORTAR_GRUPOS_EXTRAS", "false"):
            grupos_importacao.update({
                "Glpi-Atendente-TI": {"perfil": "usuario", "setor_slug": "ti"},
                "Suporte_AD": {"perfil": "usuario", "setor_slug": "ti"},
                "NTFS_EN_TI_WR": {"perfil": "usuario", "setor_slug": "ti"},
                "NTFS_ALL_BACKUP": {"perfil": "usuario", "setor_slug": "ti"},
            })

        for grupo_ad, destino in grupos_importacao.items():
            if setor_slug and destino.get("setor_slug") != setor_slug:
                continue

            try:
                grupo_safe = escape_filter_chars(str(grupo_ad))
                filtro_grupo = f"(&(objectClass=group)(cn={grupo_safe}))"

                conn.search(
                    search_base=cfg["base_dn"],
                    search_filter=filtro_grupo,
                    search_scope=SUBTREE,
                    attributes=["distinguishedName", "cn"]
                )

                if not conn.entries:
                    resultado["grupos_nao_encontrados"].append(str(grupo_ad))
                    continue

                grupo_dn = conn.entries[0].entry_dn
                atributos = [
                    cfg["name_attr"],
                    cfg["user_attr"],
                    cfg["mail_attr"],
                    "memberOf",
                    "distinguishedName",
                    "userPrincipalName",
                    "userAccountControl",
                ]

                filtros = [
                    f"(&(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2))(memberOf:1.2.840.113556.1.4.1941:={grupo_dn}))",
                    f"(&(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2))(memberOf={grupo_dn}))",
                ]

                entries = []
                for filtro in filtros:
                    conn.search(
                        search_base=cfg["base_dn"],
                        search_filter=filtro,
                        search_scope=SUBTREE,
                        attributes=atributos
                    )
                    if conn.entries:
                        entries = list(conn.entries)
                        break

                for entry in entries:
                    info = ldap_entry_to_info(entry)
                    if not info.get("usuario"):
                        continue
                    # Não importa contas desativadas no AD.
                    if not info.get("ativo_ad", True):
                        continue

                    key = info["usuario"]
                    if key not in encontrados:
                        encontrados[key] = info

                    if destino.get("perfil") == "adm":
                        encontrados[key]["perfil"] = "adm"

            except Exception as e:
                resultado["erros"].append(f"{grupo_ad}: {e}")

        for info in encontrados.values():
            try:
                usuario, acao = upsert_usuario_ldap(info, status_inicial="offline")
                if acao == "criado":
                    resultado["criados"] += 1
                elif acao == "atualizado":
                    resultado["atualizados"] += 1
                else:
                    resultado["ignorados"] += 1

                if usuario:
                    resultado["usuarios"].append(f"{usuario.nome} ({usuario.usuario})")
            except Exception as e:
                db.session.rollback()
                resultado["erros"].append(f"{info.get('usuario')}: {e}")

        # NÃO desativar usuários ausentes nesta sincronização.
        # O estado ativo/inativo é 100% local ao Cen-Chat.
        # A lista encontrados serve apenas para importar/atualizar dados LDAP.

        try:
            garantir_matriz_setorial_final()
        except Exception:
            pass

        log_db(
            f"Sincronização LDAP: {resultado['criados']} criados, {resultado['atualizados']} atualizados, {len(resultado['erros'])} erros.",
            "ldap"
        )

        return resultado

    finally:
        try:
            conn.unbind()
        except Exception:
            pass

# ==========================================================
# FUNÇÕES DE APOIO
# ==========================================================

# ==========================================================

def log_db(acao, categoria="geral", usuario_id=None):
    """Grava auditoria sem depender de contexto HTTP.

    A sincronização LDAP e outras tarefas de fundo rodam fora de uma requisição
    Flask. Nesses casos, session.get() dispara "Working outside of request context".
    O log usa o usuario_id explícito quando fornecido e, quando não há request,
    grava NULL para o usuário. Falha ao auditar nunca derruba o Cen-Chat.
    """
    try:
        uid = usuario_id
        if uid is None and has_request_context():
            uid = session.get("uid")
        registro = Log(usuario_id=uid, acao=acao, categoria=categoria, criado_em=now())
        db.session.add(registro)
        db.session.commit()
    except Exception as e:
        try:
            db.session.rollback()
        except Exception:
            pass
        logging.exception("Falha ao gravar log no banco: %s", e)
    logging.info("[%s] %s", categoria, acao)

def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    return db.session.get(Usuario, uid)

def usuario_eh_administrador(u):
    """Administrador tem acesso global de comunicação, independente do setor.

    A regra acompanha o perfil administrativo do próprio Cen-Chat. Nesta clínica,
    os administradores atuais são Val (local) e Valdirene. Se outro usuário for
    promovido formalmente para perfil adm pelo Painel ADM, ele recebe a mesma
    exceção de matriz por coerência com a função administrativa.
    """
    try:
        return bool(u and str(getattr(u, "perfil", "")).strip().lower() == "adm")
    except Exception:
        return False

def login_required(fn):
    @wraps(fn)
    def wrap(*args, **kwargs):
        if not session.get("uid"):
            return redirect(url_for("login"))
        u = current_user()
        if not u or not u.ativo:
            session.clear()
            flash("Usuário bloqueado ou inexistente.", "danger")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrap

def admin_required(fn):
    @wraps(fn)
    def wrap(*args, **kwargs):
        u = current_user()
        if not usuario_eh_administrador(u):
            abort(403)
        return fn(*args, **kwargs)
    return wrap








# Cache em memória da matriz de permissões para que abrir o chat não consulte
# o banco uma vez por usuário/contato. O cache é invalidado somente quando o ADM salva
# mudanças, mantendo o desempenho da versão anterior.
_PERMISSOES_CACHE = None
_PERMISSOES_CACHE_READY = False


def setor_slug_usuario(u):
    try:
        if u and u.setor:
            return (u.setor.slug or "").lower()
    except Exception:
        pass
    return ""


def _regra_padrao_setorial(origem_slug, destino_slug):
    origem_slug = (origem_slug or "").lower()
    destino_slug = (destino_slug or "").lower()
    if not origem_slug or not destino_slug:
        return True
    if origem_slug == destino_slug:
        return True
    if origem_slug in ["ti", "apoio"] or destino_slug in ["ti", "apoio"]:
        return True
    if origem_slug == "profissionais":
        return destino_slug in ["profissionais", "apoio", "ti"]
    if destino_slug == "profissionais":
        return origem_slug in ["profissionais", "apoio", "ti"]
    return True


def _invalidar_cache_permissoes():
    global _PERMISSOES_CACHE, _PERMISSOES_CACHE_READY
    _PERMISSOES_CACHE = None
    _PERMISSOES_CACHE_READY = False


def _carregar_cache_permissoes():
    global _PERMISSOES_CACHE, _PERMISSOES_CACHE_READY
    if _PERMISSOES_CACHE_READY and _PERMISSOES_CACHE is not None:
        return _PERMISSOES_CACHE
    cache = {}
    try:
        rows = db.session.execute(text("""
            SELECT p.origem_id, p.destino_id, p.permitido,
                   so.slug AS origem_slug, sd.slug AS destino_slug
            FROM permissoes_setores p
            JOIN setores so ON so.id = p.origem_id
            JOIN setores sd ON sd.id = p.destino_id
        """)).mappings().all()
        for row in rows:
            cache[(int(row["origem_id"]), int(row["destino_id"]))] = bool(row["permitido"])
    except Exception:
        db.session.rollback()
    _PERMISSOES_CACHE = cache
    _PERMISSOES_CACHE_READY = True
    return cache


def setor_pode_conversar(origem_slug, destino_slug, origem_id=None, destino_id=None):
    """Consulta a matriz persistida pelo ADM e só cai no padrão para pares ausentes."""
    if origem_id and destino_id:
        cache = _carregar_cache_permissoes()
        chave = (int(origem_id), int(destino_id))
        if chave in cache:
            return bool(cache[chave])
    return _regra_padrao_setorial(origem_slug, destino_slug)


def garantir_matriz_setorial_final():
    """Garante apenas pares de setores ausentes, sem sobrescrever escolhas do ADM."""
    try:
        setores = Setor.query.filter_by(ativo=True).all()
        if not setores:
            _invalidar_cache_permissoes()
            return

        existentes = {
            (int(origem_id), int(destino_id))
            for origem_id, destino_id in db.session.execute(
                text("SELECT origem_id, destino_id FROM permissoes_setores")
            ).all()
        }

        novos = []
        for origem in setores:
            for destino in setores:
                chave = (int(origem.id), int(destino.id))
                if chave in existentes:
                    continue
                novos.append({
                    "origem_id": origem.id,
                    "destino_id": destino.id,
                    "permitido": _regra_padrao_setorial(origem.slug, destino.slug),
                })

        if novos:
            db.session.execute(
                text("""
                    INSERT INTO permissoes_setores (origem_id, destino_id, permitido)
                    VALUES (:origem_id, :destino_id, :permitido)
                """),
                novos,
            )
            db.session.commit()
        _invalidar_cache_permissoes()
    except Exception:
        db.session.rollback()
        _invalidar_cache_permissoes()


def liberar_todas_permissoes_conversa():
    """Ação manual do ADM: restaura o modelo padrão em todos os pares."""
    try:
        setores = Setor.query.filter_by(ativo=True).all()
        for origem in setores:
            for destino in setores:
                permitido = _regra_padrao_setorial(origem.slug, destino.slug)
                p = PermissaoSetor.query.filter_by(origem_id=origem.id, destino_id=destino.id).first()
                if p:
                    p.permitido = permitido
                else:
                    db.session.add(PermissaoSetor(
                        origem_id=origem.id,
                        destino_id=destino.id,
                        permitido=permitido,
                    ))
        db.session.commit()
    except Exception:
        db.session.rollback()
    _invalidar_cache_permissoes()


def nome_setor_chat(nome):
    """Nome visual dos setores no chat, sem alterar o valor gravado no banco."""
    original = str(nome or "").strip()
    norm = _ldap_norm_text(original)
    if norm == "recepção erasmo":
        return "Recepção"
    return original


app.jinja_env.globals["nome_setor_chat"] = nome_setor_chat


def pode_conversar(user_a, user_b):
    """Autoriza conversa individual respeitando a matriz do Cen-Chat.

    Administradores são globais: não sofrem bloqueio de setor. Os demais
    usuários obedecem exatamente ao par de setores salvo pelo Painel ADM.
    """
    if not user_a or not user_b:
        return False
    if user_a.id == user_b.id:
        return False
    if not getattr(user_a, "ativo", True) or not getattr(user_b, "ativo", True):
        return False

    # Os administradores (Val e Valdirene atualmente) não ficam presos à
    # matriz de setores. Isso vale para abrir, enviar e receber conversas.
    if usuario_eh_administrador(user_a) or usuario_eh_administrador(user_b):
        return True

    origem_id = getattr(user_a, "setor_id", None)
    destino_id = getattr(user_b, "setor_id", None)
    if not origem_id or not destino_id:
        # Usuário sem setor não possui regra setorial definida. Ele continua
        # acessível para não quebrar o fluxo de contas recém-criadas; o menu
        # lateral, porém, não exibe pastas para uma conta sem setor.
        return True

    return setor_pode_conversar(
        setor_slug_usuario(user_a),
        setor_slug_usuario(user_b),
        origem_id=origem_id,
        destino_id=destino_id,
    )


def setores_visiveis_para_usuario(user, setores, usuarios):
    """Filtra setores do menu pelo que o usuário realmente pode conversar.

    ADM enxerga todos os setores ativos (exceto o estado 'Sem setor'). Para
    usuários comuns, um setor só aparece quando existe pelo menos uma pessoa
    naquele setor que pode ser contatada segundo a matriz.
    """
    setores_validos = [
        s for s in (setores or [])
        if _ldap_norm_text(getattr(s, "nome", "")) != "sem setor"
    ]
    if usuario_eh_administrador(user):
        return setores_validos
    if not getattr(user, "setor_id", None):
        return []

    by_sector = {int(s.id): False for s in setores_validos}
    for u in usuarios or []:
        sid = getattr(u, "setor_id", None)
        if not sid or int(sid) not in by_sector:
            continue
        if not nome_visivel_chat(getattr(u, "nome", "")):
            continue
        if pode_conversar(user, u):
            by_sector[int(sid)] = True
    return [s for s in setores_validos if by_sector.get(int(s.id), False)]


def get_or_create_conversa(a_id, b_id):
    x, y = sorted([int(a_id), int(b_id)])
    conversa = Conversa.query.filter_by(usuario_a_id=x, usuario_b_id=y).first()
    if conversa:
        return conversa.id
    conversa = Conversa(usuario_a_id=x, usuario_b_id=y, criado_em=now())
    db.session.add(conversa)
    db.session.commit()
    return conversa.id

def nome_visivel_chat(nome):
    nome = (nome or '').strip()
    if not nome:
        return False
    # Exibe apenas nomes com formato humano, como nome sobrenome ou nome.sobrenome
    return bool(re.match(r"^[A-Za-zÀ-ÖØ-öø-ÿ]+(?:[ .][A-Za-zÀ-ÖØ-öø-ÿ]+)+$", nome))


def usuario_to_dict(u):
    return {
        "id": u.id,
        "nome": u.nome,
        "usuario": u.usuario,
        "perfil": u.perfil,
        "setor_id": u.setor_id,
        "setor_nome": u.setor.nome if u.setor else None,
        "status": u.status,
        "mensagem_ausencia": u.mensagem_ausencia or "",
    }


# ==========================================================
# ORGANIZAÇÃO LOCAL FIXA DOS SETORES
# O AD/LDAP NÃO TEM AUTORIDADE SOBRE setor_id nem ativo.
# Setores são independentes do LDAP e nunca são unificados automaticamente.
# A equipe pode criar, renomear, excluir e reorganizar livremente pelo Painel ADM
# ou diretamente no MariaDB.
# ==========================================================
LOCAL_SETOR_FIX_VERSION = "20260819-v1"
LOCAL_SETOR_FIX_MARKER = BASE_DIR / f".local_setores_{LOCAL_SETOR_FIX_VERSION}.done"

LOCAL_SETOR_PADRAO = {
    "adm-nacen": ("Adm Nacen", "Administração Nacen"),
    "almoxarifado": ("Almoxarifado", "Almoxarifado"),
    "apoio": ("Apoio", "Apoio interno"),
    "conferencia": ("Conferência", "Conferência"),
    "faturamento": ("Faturamento", "Faturamento"),
    "financeiro": ("Financeiro", "Financeiro"),
    "juridico": ("Jurídico", "Jurídico"),
    "marcacao": ("Marcação", "Marcação"),
    "profissionais": ("Profissionais", "Profissionais da clínica"),
    "recepcao": ("Recepção", "Recepção"),
    "recepcao-nacen": ("Recepção Nacen", "Recepção Nacen"),
    "recepcao-nacen-2": ("Recepção Nacen+", "Recepção Nacen+"),
    "rh": ("RH", "Recursos Humanos"),
    "secretarias": ("Secretarias", "Secretarias"),
    "ti": ("TI", "Tecnologia da informação"),
}


def _canonical_setor_slug(nome_ou_slug):
    n = _ldap_norm_text(nome_ou_slug)
    aliases = {
        "secretaria": "secretarias",
        "secretarias": "secretarias",
        "almoxarifado": "almoxarifado",
        "almoxarifados": "almoxarifado",
        "recepcao": "recepcao",
        "marcacao": "marcacao",
        "conferencia": "conferencia",
        "financeiro": "financeiro",
        "faturamento": "faturamento",
        "profissionais": "profissionais",
        "nacen": "rh",
        "rh": "rh",
        "juridico": "juridico",
        "juridíco": "juridico",
        "adm nacen": "adm-nacen",
        "adm-nacen": "adm-nacen",
        "recepcao nacen": "recepcao-nacen",
        "recepcao nacen+": "recepcao-nacen-2",
        "recepcao nacen mais": "recepcao-nacen-2",
        "apoio": "apoio",
        "ti": "ti",
    }
    return aliases.get(n, slugify(n))


def unificar_setores_duplicados():
    """Mantido por compatibilidade: setores nunca são fundidos automaticamente."""
    return False

def encontrar_usuario_por_nome_local(nome):
    alvo = _ldap_norm_text(nome)
    candidatos = Usuario.query.all()
    exato = next((u for u in candidatos if _ldap_norm_text(u.nome) == alvo), None)
    if exato:
        return exato
    return next((u for u in candidatos if alvo and alvo in _ldap_norm_text(u.nome)), None)


def aplicar_organizacao_local_inicial():
    """Aplica as mudanças solicitadas uma única vez, sem dependência do LDAP."""
    if LOCAL_SETOR_FIX_MARKER.exists():
        return

    setores = {s.slug: s for s in Setor.query.filter_by(ativo=True).all()}
    ti = setores.get("ti")
    financeiro = setores.get("financeiro")
    almox = setores.get("almoxarifado")
    marcacao = setores.get("marcacao")
    secretarias = setores.get("secretarias")

    def move(nome, setor_obj):
        if not setor_obj:
            return
        u = encontrar_usuario_por_nome_local(nome)
        if u:
            u.setor_id = setor_obj.id
            u.setor_manual = True
            u.aguardando_setor = False

    # Regras pedidas explicitamente.
    alvo_encontrado = False
    for _nome, _setor in [("Gabrielly Sena", almox), ("Egla Oliveira", almox), ("Amanda Andrade", marcacao), ("Adriele Faleiro", secretarias), ("Maichele Amorim", secretarias)]:
        if _setor and encontrar_usuario_por_nome_local(_nome):
            alvo_encontrado = True
        move(_nome, _setor)

    # Todo mundo que já estiver no TI vai para o Financeiro,
    # preservando somente Miguel, Alef e Valdirene no TI.
    preservados_ti = {_ldap_norm_text(x) for x in ("Miguel Silva", "Alef Menezes", "Valdirene")}
    if ti and financeiro:
        ti_users = Usuario.query.filter_by(setor_id=ti.id).all()
        if ti_users:
            alvo_encontrado = True
        for u in ti_users:
            if _ldap_norm_text(u.nome) not in preservados_ti:
                u.setor_id = financeiro.id
                u.setor_manual = True
                u.aguardando_setor = False

    # Contas pedidas para não aparecerem no chat: mantemos o registro inativo
    # para impedir que um novo sync do LDAP as recrie/ative.
    for nome in ("Leonardo Onclin", "Suporte Onfire", "Onfire Onfrie"):
        u = encontrar_usuario_por_nome_local(nome)
        if u:
            alvo_encontrado = True
            u.ativo = False
            u.setor_id = None
            u.aguardando_setor = True

    db.session.commit()
    if not alvo_encontrado:
        return
    try:
        LOCAL_SETOR_FIX_MARKER.write_text(LOCAL_SETOR_FIX_VERSION, encoding="utf-8")
    except Exception:
        logging.exception("Não foi possível registrar o marcador da organização local; a aplicação continuará normalmente.")

def garantir_coluna_setor_manual():
    """Migra bancos existentes sem perder a organização atual.

    Todos os usuários que já possuem setor no banco são considerados
    manualmente organizados nesta primeira migração, evitando que uma nova
    sincronização LDAP mova setores que a clínica já acertou. Usuários novos
    importados do AD começam com setor_manual=False.
    """
    try:
        if not coluna_existe_runtime("usuarios", "setor_manual"):
            db.session.execute(text("ALTER TABLE usuarios ADD COLUMN setor_manual BOOLEAN NOT NULL DEFAULT FALSE"))
            db.session.execute(text("UPDATE usuarios SET setor_manual = TRUE WHERE setor_id IS NOT NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Falha ao criar/migrar usuarios.setor_manual")

def init_db():
    db.create_all()
    garantir_coluna_setor_manual()

    setores = [
        ("Adm Nacen", "adm-nacen", "Administração Nacen"),
        ("Almoxarifado", "almoxarifado", "Almoxarifado"),
        ("Apoio", "apoio", "Apoio interno"),
        ("Conferência", "conferencia", "Conferência"),
        ("Faturamento", "faturamento", "Faturamento"),
        ("Financeiro", "financeiro", "Financeiro"),
        ("Jurídico", "juridico", "Jurídico"),
        ("Marcação", "marcacao", "Marcação"),
        ("Profissionais", "profissionais", "Profissionais da clínica"),
        ("Recepção", "recepcao", "Recepção"),
        ("Recepção Nacen", "recepcao-nacen", "Recepção Nacen"),
        ("Recepção Nacen+", "recepcao-nacen-2", "Recepção Nacen+"),
        ("RH", "rh", "Recursos Humanos"),
        ("Secretarias", "secretarias", "Secretarias"),
        ("TI", "ti", "Tecnologia da informação"),
    ]

    # Bootstrap somente para um banco realmente sem setores.
    # Depois que existir ao menos um setor, o Cen-Chat NUNCA recria setores
    # apagados e não repopula a lista padrão no restart.
    if Setor.query.count() == 0:
        for nome, slug, desc in setores:
            db.session.add(Setor(nome=nome, slug=slug, descricao=desc, ativo=True, criado_em=now()))
        db.session.commit()

    # Setores são 100% locais. Não unificamos nem fundimos setores automaticamente.

    all_setores = Setor.query.all()
    prof = Setor.query.filter_by(slug="profissionais").first()
    apoio = Setor.query.filter_by(slug="apoio").first()

    for origem in all_setores:
        for destino in all_setores:
            if not PermissaoSetor.query.filter_by(origem_id=origem.id, destino_id=destino.id).first():
                permitido = True
                if prof and (origem.id == prof.id or destino.id == prof.id):
                    permitido = origem.id == destino.id or (apoio and origem.id == apoio.id) or (apoio and destino.id == apoio.id)
                db.session.add(PermissaoSetor(origem_id=origem.id, destino_id=destino.id, permitido=permitido))
    db.session.commit()

    if not Usuario.query.filter_by(usuario="val").first():
        ti = Setor.query.filter_by(slug="ti").first()
        db.session.add(Usuario(
            nome="Val",
            usuario="val",
            senha_hash=generate_password_hash(DEFAULT_VAL_PASSWORD),
            perfil="adm",
            setor_id=ti.id if ti else None,
            ativo=True,
            aguardando_setor=False,
            local_emergencia=True,
            origem_login="local",
            criado_em=now()
        ))
        db.session.commit()

    # Mantém a conta Val padronizada para acesso administrativo local.
    val = Usuario.query.filter_by(usuario="val").first()
    if val:
        ti = Setor.query.filter_by(slug="ti").first()
        mudou = False
        if val.nome != "Val":
            val.nome = "Val"
            mudou = True
        if val.perfil != "adm":
            val.perfil = "adm"
            mudou = True
        if not val.ativo:
            val.ativo = True
            mudou = True
        if not val.local_emergencia:
            val.local_emergencia = True
            mudou = True
        if val.origem_login != "local":
            val.origem_login = "local"
            mudou = True
        if ti and val.setor_id != ti.id:
            val.setor_id = ti.id
            mudou = True
        # Atualiza a senha padrão desta versão.
        val.senha_hash = generate_password_hash(DEFAULT_VAL_PASSWORD)
        mudou = True
        if mudou:
            db.session.commit()

    if not AvisoGeral.query.first():
        db.session.add(AvisoGeral(titulo="Bem-vindo ao Cen-Chat", texto="Sistema interno em fase de testes.", ativo=True, criado_em=now()))
        db.session.commit()

    try:
        garantir_matriz_setorial_final()
    except Exception:
        pass


# ==========================================================
# CORREÇÃO DEFINITIVA - CHAT REAL / ABERTURA DE CONVERSA
# ==========================================================
_RUNTIME_READY = False

def coluna_existe_runtime(tabela, coluna):
    """Verifica a existência de uma coluna em qualquer backend suportado."""
    try:
        insp = inspect(db.engine)
        return any(str(c.get("name", "")).lower() == str(coluna).lower() for c in insp.get_columns(tabela))
    except Exception:
        db.session.rollback()
        logging.exception(
            "Não foi possível checar %s.%s; assumindo que existe para não travar o chat.",
            tabela, coluna
        )
        return True

def tipo_booleano_sql():
    """Tipo SQL usado pelo schema legado MariaDB/MySQL."""
    return "TINYINT(1)"

def garantir_colunas_chat_runtime():
    """
    Garante colunas usadas pelo chat em bancos antigos.
    Evita erro 500 ao abrir conversa.
    """
    try:
        if not coluna_existe_runtime("conversas", "atualizado_em"):
            db.session.execute(text("ALTER TABLE conversas ADD COLUMN atualizado_em VARCHAR(19)"))
            try:
                db.session.execute(text("UPDATE conversas SET atualizado_em = criado_em WHERE atualizado_em IS NULL"))
            except Exception:
                pass
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir conversas.atualizado_em")

    try:
        if not coluna_existe_runtime("mensagens", "lido_em"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN lido_em VARCHAR(19)"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.lido_em — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "apagado_em"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN apagado_em VARCHAR(19)"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.apagado_em — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "resposta_a_id"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN resposta_a_id INT NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.resposta_a_id — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "fixado"):
            db.session.execute(text(f"ALTER TABLE mensagens ADD COLUMN fixado {tipo_booleano_sql()} NOT NULL DEFAULT FALSE"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.fixado — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "fixado_em"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN fixado_em VARCHAR(19) NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.fixado_em — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "editado"):
            db.session.execute(text(f"ALTER TABLE mensagens ADD COLUMN editado {tipo_booleano_sql()} NOT NULL DEFAULT FALSE"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.editado — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "editado_em"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN editado_em VARCHAR(19) NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.editado_em — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "anexo_nome"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN anexo_nome VARCHAR(255) NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.anexo_nome — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "anexo_caminho"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN anexo_caminho VARCHAR(500) NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.anexo_caminho — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "anexo_tipo"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN anexo_tipo VARCHAR(120) NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.anexo_tipo — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "anexo_tamanho"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN anexo_tamanho INT NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.anexo_tamanho — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("mensagens", "encaminhada_de_id"):
            db.session.execute(text("ALTER TABLE mensagens ADD COLUMN encaminhada_de_id INT NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir mensagens.encaminhada_de_id — verifique permissões do usuário do banco.")

    try:
        if not coluna_existe_runtime("usuarios", "tremer_tela"):
            db.session.execute(text(f"ALTER TABLE usuarios ADD COLUMN tremer_tela {tipo_booleano_sql()} NOT NULL DEFAULT TRUE"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir usuarios.tremer_tela — verifique permissões do usuário do banco.")

    # Novas preferências do usuário.
    try:
        if not coluna_existe_runtime("usuarios", "tour_concluido"):
            db.session.execute(text(f"ALTER TABLE usuarios ADD COLUMN tour_concluido {tipo_booleano_sql()} NOT NULL DEFAULT FALSE"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir usuarios.tour_concluido")

    try:
        if not coluna_existe_runtime("usuarios", "mostrar_ultimo_visto"):
            db.session.execute(text(f"ALTER TABLE usuarios ADD COLUMN mostrar_ultimo_visto {tipo_booleano_sql()} NOT NULL DEFAULT TRUE"))
            db.session.commit()
    except Exception:
        db.session.rollback()
        logging.exception("Não foi possível garantir usuarios.mostrar_ultimo_visto")

def preparar_runtime_chat():
    global _RUNTIME_READY
    if _RUNTIME_READY:
        return True
    try:
        # Bancos antigos podem não ter colunas novas do model Usuario.
        # A migração precisa acontecer ANTES de qualquer Usuario.query.
        garantir_colunas_chat_runtime()
        init_db()
        try:
            criar_indices_performance()
        except Exception:
            logging.exception("Falha ao criar índices de desempenho; o chat continuará sem esses índices.")
        try:
            garantir_matriz_setorial_final()
        except Exception:
            logging.exception("Falha ao atualizar a matriz setorial; o chat continuará tentando em seguida.")
        _RUNTIME_READY = True
        return True
    except Exception:
        db.session.rollback()
        logging.exception("Falha ao preparar runtime do Cen-Chat")
        _RUNTIME_READY = False
        return False

@app.before_request
def before_request_runtime_chat():
    # A tela de login deve abrir mesmo que o MariaDB esteja temporariamente
    # indisponível. A preparação do banco só é necessária para autenticação
    # via POST e para as áreas autenticadas do sistema. Isso evita transformar
    # uma falha de banco em uma tela branca de 500 no /login.
    if request.endpoint in {"static", "login", "health_check"}:
        return
    preparar_runtime_chat()

def conversa_raw_buscar_ou_criar(user_id, other_id):
    """
    Busca/cria conversa usando SQL direto.
    Isso evita falha quando o ORM tenta ler coluna antiga/inexistente.
    """
    a = min(int(user_id), int(other_id))
    b = max(int(user_id), int(other_id))

    row = db.session.execute(
        text("SELECT id FROM conversas WHERE usuario_a_id = :a AND usuario_b_id = :b LIMIT 1"),
        {"a": a, "b": b}
    ).fetchone()

    if row:
        return int(row[0])

    agora = now()

    try:
        if coluna_existe_runtime("conversas", "atualizado_em"):
            db.session.execute(
                text("INSERT INTO conversas (usuario_a_id, usuario_b_id, criado_em, atualizado_em) VALUES (:a, :b, :criado, :atualizado)"),
                {"a": a, "b": b, "criado": agora, "atualizado": agora}
            )
        else:
            db.session.execute(
                text("INSERT INTO conversas (usuario_a_id, usuario_b_id, criado_em) VALUES (:a, :b, :criado)"),
                {"a": a, "b": b, "criado": agora}
            )
        db.session.commit()
    except Exception:
        db.session.rollback()
        # Pode ter sido criado em paralelo; tenta buscar de novo.
        row = db.session.execute(
            text("SELECT id FROM conversas WHERE usuario_a_id = :a AND usuario_b_id = :b LIMIT 1"),
            {"a": a, "b": b}
        ).fetchone()
        if row:
            return int(row[0])
        raise

    row = db.session.execute(
        text("SELECT id FROM conversas WHERE usuario_a_id = :a AND usuario_b_id = :b LIMIT 1"),
        {"a": a, "b": b}
    ).fetchone()
    return int(row[0]) if row else None

def conversa_raw_participantes(conversa_id):
    row = db.session.execute(
        text("SELECT usuario_a_id, usuario_b_id FROM conversas WHERE id = :id LIMIT 1"),
        {"id": int(conversa_id)}
    ).fetchone()
    if not row:
        return None
    return int(row[0]), int(row[1])

# ==========================================================
# ROTAS
# ==========================================================


# ==========================================================
# HELPERS ADM BLINDADO
# ==========================================================
def safe_count(model):
    try:
        return model.query.count()
    except Exception:
        return 0

def safe_all(query, default=None):
    try:
        return query.all()
    except Exception:
        return default if default is not None else []

def safe_limit(query, limit=50):
    try:
        return query.limit(limit).all()
    except Exception:
        return []

def safe_order(model, field_name="id", desc=False, limit=None):
    try:
        col = getattr(model, field_name)
        query = model.query.order_by(col.desc() if desc else col.asc())
        if limit:
            query = query.limit(limit)
        return query.all()
    except Exception:
        try:
            query = model.query
            if limit:
                query = query.limit(limit)
            return query.all()
        except Exception:
            return []




# ==========================================================
# OTIMIZAÇÃO DE ÍNDICES - MULTI-BANCO
# ==========================================================
def indice_existe(tabela, indice):
    try:
        return any(str(idx.get("name", "")).lower() == str(indice).lower()
                   for idx in inspect(db.engine).get_indexes(tabela))
    except Exception:
        db.session.rollback()
        return False

def criar_indices_performance():
    """Cria índices de desempenho para MariaDB/MySQL."""
    try:
        if not coluna_existe_runtime("conversas", "atualizado_em"):
            db.session.execute(text("ALTER TABLE conversas ADD COLUMN atualizado_em VARCHAR(19)"))
            db.session.execute(text("UPDATE conversas SET atualizado_em = criado_em WHERE atualizado_em IS NULL"))
            db.session.commit()
    except Exception:
        db.session.rollback()

    indices = [
        ("mensagens", "idx_mensagens_conversa_id", "conversa_id"),
        ("mensagens", "idx_mensagens_remetente_id", "remetente_id"),
        ("mensagens", "idx_mensagens_enviado_em", "enviado_em"),
        ("mensagens", "idx_mensagens_conversa_enviado", "conversa_id, enviado_em"),
        ("mensagens", "idx_mensagens_conversa_id_id", "conversa_id, id"),
        ("mensagens", "idx_mensagens_unread_perf", "conversa_id, remetente_id, lido_em, apagado_em, id"),
        ("mensagens", "idx_mensagens_busca_perf", "conversa_id, id"),
        ("conversas", "idx_conversas_usuario_a", "usuario_a_id"),
        ("conversas", "idx_conversas_usuario_b", "usuario_b_id"),
        ("conversas", "idx_conversas_par_perf", "usuario_a_id, usuario_b_id"),
        ("conversas", "idx_conversas_atualizado", "atualizado_em"),
        ("usuarios", "idx_usuarios_setor_id", "setor_id"),
        ("usuarios", "idx_usuarios_usuario", "usuario"),
        ("usuarios", "idx_usuarios_ativo_setor_nome", "ativo, setor_id, nome"),
        ("usuarios", "idx_usuarios_status_ping", "status, ultimo_ping"),
        ("favoritos", "idx_favoritos_usuario", "usuario_id, favorito_id"),
        ("permissoes_setores", "idx_permissoes_origem_destino", "origem_id, destino_id"),
        ("digitando", "idx_digitando_conversa_atualizado", "conversa_id, atualizado_em"),
        ("logs", "idx_logs_categoria_id", "categoria, id"),
    ]

    for tabela, nome_indice, colunas in indices:
        try:
            if not indice_existe(tabela, nome_indice):
                db.session.execute(text(f"CREATE INDEX {nome_indice} ON {tabela} ({colunas})"))
                db.session.commit()
        except Exception:
            db.session.rollback()

@app.route("/")
def index():
    try:
        if session.get("uid"):
            return redirect(url_for("chat"))
    except Exception:
        pass
    return redirect(url_for("login"))

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def login_post():
    if not preparar_runtime_chat():
        flash("O servidor ainda não conseguiu conectar ao banco de dados. Verifique o MariaDB e tente novamente.", "danger")
        return redirect(url_for("login"))

    usuario_login = ldap_normalizar_login(request.form.get("usuario", ""))
    senha = request.form.get("senha", "")

    usuario_local = Usuario.query.filter_by(usuario=usuario_login).first()

    # Conta Val é sempre local, mesmo com LDAP ligado.
    if usuario_local and usuario_local.local_emergencia:
        return login_local(usuario_local, senha)

    # Se LDAP estiver ligado, usuários normais vão pelo AD.
    if ldap_enabled():
        return login_via_ldap(usuario_login, senha)

    # Se LDAP estiver desligado, usa login local.
    if usuario_local:
        return login_local(usuario_local, senha)

    flash("Usuário ou senha inválidos.", "danger")
    log_db(f"Login inválido para {usuario_login}", "seguranca")
    return redirect(url_for("login"))

def login_local(u, senha):
    if u.bloqueado_ate and dt_parse(u.bloqueado_ate) and dt_parse(u.bloqueado_ate) > datetime.now():
        flash(f"Usuário bloqueado temporariamente até {u.bloqueado_ate}.", "danger")
        return redirect(url_for("login"))

    if not u.senha_hash or not check_password_hash(u.senha_hash, senha):
        u.tentativas_login = (u.tentativas_login or 0) + 1
        if u.tentativas_login >= MAX_LOGIN_ATTEMPTS:
            u.tentativas_login = 0
            u.bloqueado_ate = (datetime.now() + timedelta(minutes=LOCKOUT_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
        db.session.commit()
        flash("Usuário ou senha inválidos.", "danger")
        return redirect(url_for("login"))

    return concluir_login(u)

def login_via_ldap(usuario_login, senha):
    try:
        dados = autenticar_ldap(usuario_login, senha)
    except Exception as e:
        logging.exception("Erro LDAP: %s", e)
        flash(f"Usuário ou senha inválidos no domínio. Detalhe: {e}", "danger")
        return redirect(url_for("login"))

    if not dados:
        flash("Usuário não encontrado no AD ou senha inválida.", "danger")
        return redirect(url_for("login"))

    u, _ = upsert_usuario_ldap(dados, status_inicial="offline")
    if not u:
        flash("Não foi possível criar/atualizar o usuário LDAP.", "danger")
        return redirect(url_for("login"))

    try:
        aplicar_regras_ldap_fixas()
        db.session.refresh(u)
    except Exception:
        db.session.rollback()
        logging.exception("Falha ao aplicar regras locais LDAP no login")

    if usuario_ldap_bloqueado_por_regra(u) or not u.ativo:
        flash("Este usuário está bloqueado para o Cen-Chat.", "danger")
        return redirect(url_for("login"))

    return concluir_login(u)


def concluir_login(u):
    if not u.ativo:
        flash("Usuário bloqueado.", "danger")
        return redirect(url_for("login"))

    u.ultimo_login = now()
    u.ultimo_ping = now()
    u.status = "online"
    u.tentativas_login = 0
    u.bloqueado_ate = None
    db.session.commit()

    session.permanent = True
    session["uid"] = u.id
    session["usuario"] = u.usuario
    log_db("Login realizado", "login", u.id)
    return redirect(url_for("chat"))

@app.route("/logout")
def logout():
    u = current_user()
    if u:
        u.status = "offline"
        u.ultimo_ping = now()
        db.session.commit()
        log_db("Logout", "login", u.id)
    session.clear()
    return redirect(url_for("login"))

@app.route("/chat")
@login_required
def chat():
    user = current_user()

    if Setor.query.count() == 0:
        init_db()

    setores = Setor.query.filter_by(ativo=True).order_by(Setor.nome).all()
    # "Sem setor" é um estado de usuário, não uma pasta de conversa.
    setores = [s for s in setores if _ldap_norm_text(getattr(s, "nome", "")) != "sem setor"]
    usuarios = Usuario.query.filter(Usuario.ativo == True, Usuario.id != user.id).order_by(Usuario.nome).all()
    usuarios = [u for u in usuarios if nome_visivel_chat(u.nome)]
    fav_ids = {f.favorito_id for f in Favorito.query.filter_by(usuario_id=user.id).all() if any(x.id == f.favorito_id for x in usuarios)}
    avisos = AvisoGeral.query.filter_by(ativo=True).order_by(AvisoGeral.id.desc()).limit(3).all()
    allowed = {u.id: pode_conversar(user, u) for u in usuarios}
    status_map = {u.id: status_efetivo(u) for u in usuarios}
    # Novo comportamento: setores sem nenhum contato permitido não são
    # apresentados ao usuário comum. Administradores continuam vendo os 15
    # setores ativos para poder gerenciá-los e atender qualquer setor.
    setores = setores_visiveis_para_usuario(user, setores, [u for u in usuarios if allowed.get(u.id)])
    # Base autorizada do Erasminho: disponibilizada somente para o navegador
    # autenticado que abriu o chat, para ser enviada ao serviço de IA online.
    erasminho_kb = ""
    try:
        kb_path = BASE_DIR / "knowledge" / "erasminho_base.md"
        erasminho_kb = kb_path.read_text(encoding="utf-8")[:30000]
    except Exception:
        erasminho_kb = ""
    return render_template("chat.html", user=user, setores=setores, usuarios=usuarios, allowed=allowed,
                           fav_ids=fav_ids, avisos=avisos, themes=THEMES, status_labels=STATUS_LABELS,
                           status_map=status_map, erasminho_kb=erasminho_kb)

@app.route("/admin/espaco_disco")
@login_required
@admin_required
def admin_espaco_disco():
    """Monitoramento simples de espaço em disco pra pasta de anexos.
    Dá pra consultar direto pelo navegador ou por um script de monitoramento."""
    try:
        uso = shutil.disk_usage(str(UPLOADS_DIR))
        total_anexos_bytes = sum(
            f.stat().st_size for f in UPLOADS_DIR.rglob("*") if f.is_file()
        )
        return jsonify({
            "ok": True,
            "disco_total_gb": round(uso.total / (1024**3), 2),
            "disco_livre_gb": round(uso.free / (1024**3), 2),
            "disco_usado_gb": round(uso.used / (1024**3), 2),
            "reserva_minima_mb": ANEXO_ESPACO_MINIMO_MB,
            "anexos_total_mb": round(total_anexos_bytes / (1024**2), 2),
            "alerta": uso.free < (ANEXO_ESPACO_MINIMO_MB * 1024 * 1024 * 2),
        })
    except Exception as e:
        return jsonify({"ok": False, "erro": str(e)}), 500

@app.route("/admin")
@login_required
@admin_required
def admin():
    """Painel ADM blindado.

    Esta versão evita consultas extras de métricas que podem quebrar em bancos antigos
    quando alguma coluna ainda não foi migrada. O painel continua abrindo e os cards
    usam valores seguros. As métricas mais pesadas ficam fora do carregamento inicial.
    """
    try:
        init_db()
    except Exception:
        db.session.rollback()
        logging.exception("Falha ao inicializar banco no painel ADM")

    try:
        setores = safe_order(Setor, "nome")
    except Exception:
        db.session.rollback()
        setores = []

    try:
        usuarios = [u for u in safe_order(Usuario, "nome") if getattr(u, "ativo", True)]
    except Exception:
        db.session.rollback()
        usuarios = []

    usuarios_ativos = list(usuarios)
    usuarios_inativos = []

    try:
        avisos = safe_order(AvisoGeral, "id", desc=True, limit=80)
    except Exception:
        db.session.rollback()
        avisos = []

    try:
        logs = safe_order(Log, "id", desc=True, limit=80)
    except Exception:
        db.session.rollback()
        logs = []

    try:
        pendentes = Usuario.query.filter_by(aguardando_setor=True).all()
    except Exception:
        db.session.rollback()
        pendentes = []

    perm_map = {}
    try:
        for p in PermissaoSetor.query.all():
            perm_map[(p.origem_id, p.destino_id)] = p.permitido
    except Exception:
        db.session.rollback()
        perm_map = {}

    # Valores seguros para o template premium do ADM.
    # Não fazem consultas extras para evitar erro 500 em banco antigo.
    stats = {
        "usuarios": len(usuarios_ativos),
        "usuarios_ativos": len(usuarios_ativos),
        "usuarios_inativos": 0,
        "setores": len(setores),
        "avisos": len(avisos),
        "logs": len(logs),
        "mensagens_hoje": 0,
        "usuarios_online": sum(1 for u in usuarios_ativos if getattr(u, "status", "") == "online"),
        "usuarios_sem_setor": sum(1 for u in usuarios_ativos if not getattr(u, "setor_id", None)),
        "usuarios_ldap": 0,
    }

    usuarios_envio_massa = [u for u in usuarios_ativos if int(u.id) != int(current_user().id)]

    # Agrupa por setor pra montar as "pastinhas" da tela de envio em massa
    # e também da aba Usuários — mesma lógica reaproveitada nas duas telas.
    def agrupar_por_setor(lista_usuarios):
        grupos = {}
        for u in lista_usuarios:
            nome_setor = u.setor.nome if getattr(u, "setor", None) else "Sem setor"
            grupos.setdefault(nome_setor, []).append(u)
        return [
            {"nome": nome, "slug": re.sub(r"[^a-z0-9]+", "-", nome.lower()).strip("-") or "sem-setor", "usuarios": lista}
            for nome, lista in sorted(grupos.items(), key=lambda item: item[0].lower())
        ]

    setores_envio_massa = agrupar_por_setor(usuarios_envio_massa)
    usuarios_ativos_por_setor = agrupar_por_setor(usuarios_ativos)

    return render_template(
        "admin.html",
        setores=setores,
        usuarios=usuarios,
        usuarios_ativos=usuarios_ativos,
        usuarios_inativos=usuarios_inativos,
        usuarios_envio_massa=usuarios_envio_massa,
        setores_envio_massa=setores_envio_massa,
        usuarios_ativos_por_setor=usuarios_ativos_por_setor,
        avisos=avisos,
        logs=logs,
        pendentes=pendentes,
        perm_map=perm_map,
        status_labels=STATUS_LABELS,
        stats=stats,
        admin_safe=True,
    )

def _push_payload_for_message(sender, msg, conversa_id):
    return {
        "title": f"Cen-Chat · {sender.nome}",
        "body": (msg.texto or "Nova mensagem")[:160],
        "tag": f"cen-chat-conversa-{conversa_id}",
        "data": {
            "url": f"/chat?open={int(msg.remetente_id)}",
            "conversa_id": int(conversa_id),
            "sender_id": int(sender.id),
        }
    }

def _send_web_push_to_users(user_ids, payload):
    """Envia Web Push sem deixar uma falha de push quebrar o envio da mensagem."""
    if not WEB_PUSH_ENABLED:
        return
    ids = {int(x) for x in (user_ids or []) if x is not None}
    if not ids:
        return
    try:
        with app.app_context():
            subs = PushSubscription.query.filter(PushSubscription.usuario_id.in_(ids)).all()
            for sub in list(subs):
                subscription_info = {
                    "endpoint": sub.endpoint,
                    "keys": {"p256dh": sub.p256dh, "auth": sub.auth},
                }
                try:
                    webpush(
                        subscription_info=subscription_info,
                        data=json.dumps(payload, ensure_ascii=False),
                        vapid_private_key=VAPID_PRIVATE_KEY,
                        vapid_claims={"sub": VAPID_CLAIMS_EMAIL},
                        ttl=60 * 60 * 24,
                    )
                except Exception as exc:
                    # 401/403/404/410: inscrição incompatível, expirada ou
                    # criada com outro par de chaves VAPID. Removemos a inscrição
                    # para impedir que isso quebre/"suje" o servidor.
                    status_code = getattr(getattr(exc, "response", None), "status_code", None)
                    if status_code in (401, 403, 404, 410):
                        db.session.delete(sub)
                        try:
                            db.session.commit()
                        except Exception:
                            db.session.rollback()
                        logging.info("Web Push: inscrição %s removida (HTTP %s). O navegador poderá se inscrever novamente.", sub.id, status_code)
                    else:
                        logging.warning("Web Push falhou para subscription %s: %s", sub.id, exc)
    except Exception:
        logging.exception("Erro geral no envio de Web Push")

def disparar_web_push_mensagem(recipient_ids, sender, msg, conversa_id):
    if not WEB_PUSH_ENABLED:
        return
    payload = _push_payload_for_message(sender, msg, conversa_id)
    # Rede e provedor de push podem demorar; não bloqueia a resposta do chat.
    threading.Thread(
        target=_send_web_push_to_users,
        args=(recipient_ids, payload),
        daemon=True,
        name="cen-chat-webpush",
    ).start()

@app.route("/service-worker.js")
def service_worker():
    sw_path = BASE_DIR / "static" / "sw.js"
    return send_file(sw_path, mimetype="application/javascript", max_age=0)

@app.route("/api/push/public-key")
@login_required
def api_push_public_key():
    return jsonify(ok=True, enabled=WEB_PUSH_ENABLED, public_key=VAPID_PUBLIC_KEY if WEB_PUSH_ENABLED else "")

@app.route("/api/push/subscribe", methods=["POST"])
@login_required
def api_push_subscribe():
    if not WEB_PUSH_ENABLED:
        return jsonify(ok=False, enabled=False, erro="Web Push ainda não está configurado no servidor."), 503
    payload = request.get_json(force=True) or {}
    endpoint = str(payload.get("endpoint") or "").strip()
    keys = payload.get("keys") or {}
    p256dh = str(keys.get("p256dh") or "").strip()
    auth = str(keys.get("auth") or "").strip()
    if not endpoint or not p256dh or not auth:
        return jsonify(ok=False, erro="Inscrição de push inválida."), 400
    user = current_user()
    sub = PushSubscription.query.filter_by(endpoint=endpoint).first()
    if sub:
        sub.usuario_id = user.id
        sub.p256dh = p256dh
        sub.auth = auth
        sub.atualizado_em = now()
    else:
        db.session.add(PushSubscription(
            usuario_id=user.id, endpoint=endpoint, p256dh=p256dh, auth=auth,
            criado_em=now(), atualizado_em=now()
        ))
    db.session.commit()
    return jsonify(ok=True)

@app.route("/api/push/unsubscribe", methods=["POST"])
@login_required
def api_push_unsubscribe():
    payload = request.get_json(force=True) or {}
    endpoint = str(payload.get("endpoint") or "").strip()
    if endpoint:
        PushSubscription.query.filter_by(usuario_id=current_user().id, endpoint=endpoint).delete(
            synchronize_session=False
        )
        db.session.commit()
    return jsonify(ok=True)

@app.route("/api/chat_setores")
@login_required
def api_chat_setores():
    """Estrutura dos setores em poucas consultas, incluindo última mensagem e online por setor."""
    user = current_user()
    try:
        setores = Setor.query.filter_by(ativo=True).order_by(Setor.nome).all()
        # Mantém a mesma lista visual do /chat: "Sem setor" não aparece como pasta.
        setores = [s for s in setores if _ldap_norm_text(getattr(s, "nome", "")) != "sem setor"]
        usuarios = Usuario.query.filter(Usuario.ativo == True, Usuario.id != user.id).order_by(Usuario.nome).all()
        fav_ids = {f.favorito_id for f in Favorito.query.filter_by(usuario_id=user.id).all()}
        allowed_map = {u.id: pode_conversar(user, u) for u in usuarios}
        setores = setores_visiveis_para_usuario(user, setores, [u for u in usuarios if allowed_map.get(u.id)])

        preview_rows = db.session.execute(text("""
            SELECT
                CASE WHEN c.usuario_a_id = :uid THEN c.usuario_b_id ELSE c.usuario_a_id END AS other_id,
                lm.id AS last_id, lm.texto AS last_texto, lm.enviado_em AS last_time
            FROM conversas c
            JOIN (
                SELECT conversa_id, MAX(id) AS last_id
                FROM mensagens
                WHERE apagado_em IS NULL
                GROUP BY conversa_id
            ) x ON x.conversa_id = c.id
            JOIN mensagens lm ON lm.id = x.last_id
            WHERE c.usuario_a_id = :uid OR c.usuario_b_id = :uid
        """), {"uid": user.id}).mappings().all()
        previews = {int(r["other_id"]): r for r in preview_rows if r.get("other_id")}

        by_sector = {int(s.id): [] for s in setores}
        online_counts = {int(s.id): 0 for s in setores}

        for u in usuarios:
            sid = int(u.setor_id) if u.setor_id else None
            if sid not in by_sector or not nome_visivel_chat(u.nome) or not allowed_map.get(u.id):
                continue
            eff = status_efetivo(u)
            p = previews.get(int(u.id))
            last_text = ((p.get("last_texto") if p else "") or "").replace("\n", " ").strip()
            item = {
                "id": u.id, "nome": u.nome, "setor_id": u.setor_id,
                "setor_nome": nome_setor_chat(u.setor.nome) if u.setor else "Sem setor",
                "status": eff, "status_label": STATUS_LABELS.get(eff, eff),
                "mensagem_ausencia": u.mensagem_ausencia or "",
                "favorito": u.id in fav_ids,
                "ultima_mensagem": last_text[:120],
                "ultima_mensagem_em": p.get("last_time") if p else None,
                "tem_conversa": bool(p),
            }
            by_sector[sid].append(item)
            if eff == "online":
                online_counts[sid] += 1

        payload = []
        for setor in setores:
            people = by_sector.get(int(setor.id), [])
            people.sort(key=lambda x: x["nome"].lower())
            payload.append({
                "id": setor.id, "nome": nome_setor_chat(setor.nome), "slug": setor.slug,
                "usuarios": people, "online_count": int(online_counts.get(int(setor.id), 0)),
            })

        return jsonify({
            "ok": True, "setores": payload,
            "sem_setor": sum(1 for u in usuarios if not u.setor_id and nome_visivel_chat(u.nome)),
            "atualizado_em": now(),
        })
    except Exception as e:
        db.session.rollback()
        logging.exception("Erro ao atualizar setores do chat: %s", e)
        return jsonify({"ok": False, "setores": [], "erro": type(e).__name__}), 500


@app.route("/api/status_usuarios")
@login_required
def api_status_usuarios():
    """Status atual (online/offline/etc) de todos os usuários que aparecem
    na barra lateral do usuário logado. Usado pra manter o pontinho de
    status certo mesmo sem dar F5, inclusive quando alguém desloga."""
    user = current_user()
    try:
        usuarios = Usuario.query.filter(Usuario.ativo == True, Usuario.id != user.id).all()
        data = {}
        for u in usuarios:
            if not nome_visivel_chat(u.nome) or not pode_conversar(user, u):
                continue
            eff = status_efetivo(u)
            data[str(u.id)] = {
                "status": eff,
                "label": STATUS_LABELS.get(eff, STATUS_LABELS.get("offline", eff)),
                "mensagem_ausencia": u.mensagem_ausencia or "",
                "mostrar_ultimo_visto": bool(getattr(u, "mostrar_ultimo_visto", True)),
                "ultimo_visto": u.ultimo_ping if (eff == "offline" and getattr(u, "mostrar_ultimo_visto", True)) else None,
            }
        return jsonify({"ok": True, "usuarios": data})
    except Exception as e:
        logging.exception("Erro ao buscar status dos usuários: %s", e)
        return jsonify({"ok": False, "erro": type(e).__name__}), 500


@app.route("/api/chat_dashboard")
@login_required
def api_chat_dashboard():
    user = current_user()
    inicio_hoje = datetime.now().strftime("%Y-%m-%d 00:00:00")
    try:
        total_usuarios = Usuario.query.filter(Usuario.ativo == True).count()
        usuarios_online_query = Usuario.query.filter(Usuario.ativo == True, Usuario.status == "online").all()
        usuarios_online = sum(1 for u in usuarios_online_query if status_efetivo(u) == "online")
        setores_ativos = len(setores_visiveis_para_usuario(
            user,
            Setor.query.filter_by(ativo=True).order_by(Setor.nome).all(),
            Usuario.query.filter(Usuario.ativo == True, Usuario.id != user.id).all(),
        ))
        sem_setor = Usuario.query.filter(Usuario.ativo == True, Usuario.setor_id.is_(None)).count()
        mensagens_hoje = Mensagem.query.filter(Mensagem.enviado_em >= inicio_hoje).count()
        conversas_total = Conversa.query.count()
        online_users = [u for u in usuarios_online_query if u.id != user.id and status_efetivo(u) == "online"]
        online_users.sort(key=lambda u: u.nome)
        online_payload = []
        for u in online_users:
            if nome_visivel_chat(u.nome) and pode_conversar(user, u):
                online_payload.append(usuario_to_dict(u))
            if len(online_payload) >= 10:
                break
        return jsonify({
            "ok": True,
            "total_usuarios": total_usuarios,
            "usuarios_online": usuarios_online,
            "setores_ativos": setores_ativos,
            "sem_setor": sem_setor,
            "mensagens_hoje": mensagens_hoje,
            "conversas_total": conversas_total,
            "online_users": online_payload,
            "atualizado_em": now(),
        })
    except Exception as e:
        logging.exception("Erro no dashboard do chat: %s", e)
        return jsonify({"ok": False, "erro": type(e).__name__}), 500


@app.route("/api/conversas_preview")
@login_required
def api_conversas_preview():
    user = current_user()
    try:
        rows = db.session.execute(text("""
            SELECT
                c.id AS conversa_id,
                CASE WHEN c.usuario_a_id = :uid THEN c.usuario_b_id ELSE c.usuario_a_id END AS other_id,
                COALESCE(u.nome, 'Usuário') AS other_nome,
                COALESCE(s.nome, 'Sem setor') AS setor_nome,
                u.setor_id AS setor_id,
                COALESCE(u.status, 'offline') AS status,
                u.ultimo_ping AS ultimo_visto,
                COALESCE(u.mostrar_ultimo_visto, :mostrar_ultimo_visto_padrao) AS mostrar_ultimo_visto,
                lm.id AS last_id,
                lm.texto AS last_texto,
                lm.enviado_em AS last_time,
                COALESCE(unread.total, 0) AS unread_count
            FROM conversas c
            JOIN (
                SELECT conversa_id, MAX(id) AS last_id
                FROM mensagens
                WHERE apagado_em IS NULL
                GROUP BY conversa_id
            ) last_msg ON last_msg.conversa_id = c.id
            JOIN mensagens lm ON lm.id = last_msg.last_id
            LEFT JOIN usuarios u ON u.id = CASE WHEN c.usuario_a_id = :uid THEN c.usuario_b_id ELSE c.usuario_a_id END
            LEFT JOIN setores s ON s.id = u.setor_id
            LEFT JOIN (
                SELECT conversa_id, COUNT(*) AS total
                FROM mensagens
                WHERE remetente_id <> :uid
                  AND lido_em IS NULL
                  AND apagado_em IS NULL
                GROUP BY conversa_id
            ) unread ON unread.conversa_id = c.id
            WHERE c.usuario_a_id = :uid OR c.usuario_b_id = :uid
            ORDER BY lm.id DESC
            LIMIT 80
        """), {"uid": user.id, "mostrar_ultimo_visto_padrao": True}).mappings().all()

        items = []
        for row in rows:
            other_id = int(row["other_id"] or 0)
            if not other_id or not row["other_nome"] or not nome_visivel_chat(row["other_nome"]):
                continue
            other = db.session.get(Usuario, other_id)
            if not other or not getattr(other, "ativo", True) or not pode_conversar(user, other):
                continue
            items.append({
                "conversa_id": int(row["conversa_id"]),
                "other_id": other_id,
                "other_nome": row["other_nome"],
                "setor_nome": row["setor_nome"],
                "setor_id": int(row["setor_id"]) if row.get("setor_id") else None,
                "status": status_efetivo(other),
                "ultimo_visto": row["ultimo_visto"],
                "mostrar_ultimo_visto": bool(row["mostrar_ultimo_visto"]),
                "last_id": int(row["last_id"] or 0),
                "last_texto": (row["last_texto"] or "")[:120],
                "last_time": row["last_time"],
                "unread_count": int(row["unread_count"] or 0),
            })
        return jsonify({"ok": True, "items": items})
    except Exception as e:
        logging.exception("Erro em conversas preview: %s", e)
        return jsonify({"ok": False, "items": [], "erro": type(e).__name__}), 500


@app.route("/api/marcar_todas_lidas", methods=["POST"])
@login_required
def api_marcar_todas_lidas():
    user = current_user()
    conversas = Conversa.query.filter((Conversa.usuario_a_id == user.id) | (Conversa.usuario_b_id == user.id)).all()
    conversa_ids = [c.id for c in conversas]
    if not conversa_ids:
        return jsonify({"ok": True, "marcadas": 0})
    try:
        changed = Mensagem.query.filter(
            Mensagem.conversa_id.in_(conversa_ids),
            Mensagem.remetente_id != user.id,
            Mensagem.lido_em.is_(None),
            Mensagem.apagado_em.is_(None)
        ).update({Mensagem.lido_em: now()}, synchronize_session=False)
        db.session.commit()
        return jsonify({"ok": True, "marcadas": int(changed or 0)})
    except Exception as e:
        db.session.rollback()
        logging.exception("Erro ao marcar todas como lidas: %s", e)
        return jsonify({"ok": False, "erro": type(e).__name__}), 500


@app.route("/api/conversa/<int:other_id>")
@login_required
def api_conversa(other_id):
    try:
        preparar_runtime_chat()
        user = current_user()
        other = Usuario.query.get(int(other_id))

        if not user:
            return jsonify({"ok": False, "erro": "Sessão expirada. Entre novamente."}), 401

        if not other:
            return jsonify({"ok": False, "erro": "Usuário não encontrado."}), 404

        if other.id == user.id:
            return jsonify({"ok": False, "erro": "Você não pode abrir conversa consigo mesmo."}), 400

        if not getattr(user, "ativo", True):
            return jsonify({"ok": False, "erro": "Seu usuário está inativo."}), 403

        if not getattr(other, "ativo", True):
            return jsonify({"ok": False, "erro": "Usuário inativo."}), 403

        if not pode_conversar(user, other):
            return jsonify({
                "ok": False,
                "erro": "Esta conversa não está liberada pelas permissões do seu setor."
            }), 403

        conversa_id = conversa_raw_buscar_ou_criar(user.id, other.id)
        if not conversa_id:
            return jsonify({"ok": False, "erro": "Não foi possível criar a conversa no banco."}), 500

        return jsonify({
            "ok": True,
            "conversa_id": conversa_id,
            "other": usuario_to_dict(other)
        })

    except Exception as e:
        db.session.rollback()
        logging.exception("Erro real ao abrir conversa com usuário %s: %s", other_id, e)
        return jsonify({
            "ok": False,
            "erro": f"Erro ao abrir conversa: {type(e).__name__}"
        }), 500


@app.route("/api/conversa_info/<int:conversa_id>")
@login_required
def api_conversa_info(conversa_id):
    """Reabre exatamente a mesma conversa já registrada, sem criar outra."""
    try:
        preparar_runtime_chat()
        user = current_user()
        participantes = conversa_raw_participantes(conversa_id)
        if not participantes:
            return jsonify({"ok": False, "erro": "Conversa não encontrada."}), 404
        if user.id not in participantes and user.perfil != "adm":
            return jsonify({"ok": False, "erro": "Você não participa desta conversa."}), 403
        other_id = participantes[1] if participantes[0] == user.id else participantes[0]
        other = db.session.get(Usuario, int(other_id))
        if not other or not getattr(other, "ativo", True):
            return jsonify({"ok": False, "erro": "Usuário da conversa não está disponível."}), 404
        if not pode_conversar(user, other):
            return jsonify({"ok": False, "erro": "Você não pode abrir esta conversa."}), 403
        return jsonify({
            "ok": True,
            "conversa_id": int(conversa_id),
            "other": usuario_to_dict(other)
        })
    except Exception as e:
        db.session.rollback()
        logging.exception("Erro ao reabrir conversa %s: %s", conversa_id, e)
        return jsonify({"ok": False, "erro": f"Erro ao abrir conversa: {type(e).__name__}"}), 500


@app.route("/api/conversa/<int:conversa_id>/buscar")
@login_required
def api_buscar_mensagens_conversa(conversa_id):
    """Busca mensagens somente na conversa selecionada."""
    user = current_user()
    q = (request.args.get("q") or "").strip()
    if len(q) < 2:
        return jsonify({"ok": True, "resultados": []})

    participantes = conversa_raw_participantes(conversa_id)
    if not participantes or user.id not in participantes:
        return jsonify({"ok": False, "erro": "Você não participa desta conversa."}), 403
    outro_id = participantes[1] if participantes[0] == user.id else participantes[0]
    outro = db.session.get(Usuario, int(outro_id))
    if not outro or not pode_conversar(user, outro):
        return jsonify({"ok": False, "erro": "Você não pode acessar esta conversa."}), 403

    rows = db.session.execute(text("""
        SELECT id, remetente_id, texto, enviado_em
        FROM mensagens
        WHERE conversa_id = :cid
          AND apagado_em IS NULL
          AND texto LIKE :q
        ORDER BY id DESC
        LIMIT 30
    """), {"cid": int(conversa_id), "q": f"%{q}%"}).mappings().all()

    return jsonify({"ok": True, "resultados": [{
        "id": int(r["id"]), "remetente_id": int(r["remetente_id"]),
        "texto": (r["texto"] or "")[:240], "enviado_em": r["enviado_em"]
    } for r in rows]})


@app.route("/api/mensagens/<int:conversa_id>")
@login_required
def api_mensagens(conversa_id):
    try:
        preparar_runtime_chat()
        user = current_user()
        participantes = conversa_raw_participantes(conversa_id)

        if not participantes:
            return jsonify({"ok": False, "erro": "Conversa não encontrada.", "mensagens": []}), 404

        if user.id not in participantes and user.perfil != "adm":
            return jsonify({"ok": False, "erro": "Você não participa desta conversa.", "mensagens": []}), 403

        try:
            limit = int(request.args.get("limit", CHAT_MESSAGES_DEFAULT_LIMIT))
        except Exception:
            limit = CHAT_MESSAGES_DEFAULT_LIMIT

        if limit < 20:
            limit = 20
        if limit > CHAT_MESSAGES_MAX_LIMIT:
            limit = CHAT_MESSAGES_MAX_LIMIT

        before_id = request.args.get("before_id", type=int)

        query = Mensagem.query.filter_by(conversa_id=conversa_id)
        if before_id:
            query = query.filter(Mensagem.id < before_id)

        mensagens = query.order_by(Mensagem.id.desc()).limit(limit).all()
        mensagens = list(reversed(mensagens))

        ids_para_marcar_lida = [
            msg_lida.id for msg_lida in mensagens
            if msg_lida.remetente_id != user.id and hasattr(msg_lida, "lido_em") and not msg_lida.lido_em
        ]
        if ids_para_marcar_lida:
            Mensagem.query.filter(Mensagem.id.in_(ids_para_marcar_lida)).update(
                {Mensagem.lido_em: now()},
                synchronize_session=False
            )
            db.session.commit()

        data = []
        resposta_ids = {m.resposta_a_id for m in mensagens if getattr(m, "resposta_a_id", None)}
        respostas_map = {}
        if resposta_ids:
            originais = Mensagem.query.filter(Mensagem.id.in_(resposta_ids)).all()
            for o in originais:
                respostas_map[o.id] = {
                    "id": o.id,
                    "remetente_id": o.remetente_id,
                    "remetente_nome": o.remetente.nome if o.remetente else "",
                    "texto": ("Mensagem apagada" if getattr(o, "apagado_em", None) else o.texto)[:140],
                }

        msg_ids = [m.id for m in mensagens]
        encaminhada_nomes = {}
        encaminhada_ids = {m.encaminhada_de_id for m in mensagens if getattr(m, "encaminhada_de_id", None)}
        if encaminhada_ids:
            for u in Usuario.query.filter(Usuario.id.in_(encaminhada_ids)).all():
                encaminhada_nomes[u.id] = u.nome

        reacoes_map = {}
        if msg_ids:
            try:
                linhas_reacao = Reacao.query.filter(Reacao.mensagem_id.in_(msg_ids)).all()
                agregada = {}
                for r in linhas_reacao:
                    chave = (r.mensagem_id, r.emoji)
                    if chave not in agregada:
                        agregada[chave] = {"emoji": r.emoji, "total": 0, "mine": False}
                    agregada[chave]["total"] += 1
                    if r.usuario_id == user.id:
                        agregada[chave]["mine"] = True
                for (mid, emoji), info in agregada.items():
                    reacoes_map.setdefault(mid, []).append(info)
            except Exception:
                reacoes_map = {}

        for m in mensagens:
            if user.id == m.remetente_id and getattr(m, "apagado_por_remetente", False):
                continue
            if user.id != m.remetente_id and getattr(m, "apagado_por_destinatario", False):
                continue

            texto = "Mensagem apagada" if getattr(m, "apagado_em", None) else m.texto
            anexo = None
            if getattr(m, "anexo_caminho", None) and not getattr(m, "apagado_em", None):
                anexo = {
                    "nome": m.anexo_nome,
                    "tipo": m.anexo_tipo,
                    "tamanho": m.anexo_tamanho,
                    "url": url_for("api_anexo", msg_id=m.id),
                    "imagem": bool(m.anexo_tipo and m.anexo_tipo.startswith("image/")),
                }
            data.append({
                "id": m.id,
                "remetente_id": m.remetente_id,
                "texto": texto,
                "enviado_em": m.enviado_em,
                "apagado": bool(getattr(m, "apagado_em", None)),
                "fixado": bool(getattr(m, "fixado", False)),
                "resposta_a": respostas_map.get(getattr(m, "resposta_a_id", None)),
                "lido": bool(getattr(m, "lido_em", None)),
                "editado": bool(getattr(m, "editado", False)),
                "anexo": anexo,
                "encaminhada_de": encaminhada_nomes.get(getattr(m, "encaminhada_de_id", None)),
                "reacoes": reacoes_map.get(m.id, []),
            })

        tem_mais = False
        try:
            if mensagens:
                primeiro_id = mensagens[0].id
                tem_mais = Mensagem.query.filter(
                    Mensagem.conversa_id == conversa_id,
                    Mensagem.id < primeiro_id
                ).limit(1).count() > 0
        except Exception:
            tem_mais = False

        return jsonify({"ok": True, "mensagens": data, "limit": limit, "tem_mais": tem_mais})

    except Exception as e:
        db.session.rollback()
        logging.exception("Erro ao carregar mensagens da conversa %s: %s", conversa_id, e)
        return jsonify({"ok": False, "erro": f"Erro ao carregar mensagens: {type(e).__name__}", "mensagens": []}), 500


@app.route("/api/enviar", methods=["POST"])
@login_required
def api_enviar():
    try:
        preparar_runtime_chat()
        user = current_user()
        data = request.get_json(force=True)
        conversa_id = int(data.get("conversa_id"))
        texto_msg = (data.get("texto") or "").strip()

        if not texto_msg:
            return jsonify({"ok": False, "erro": "Mensagem vazia."}), 400

        participantes = conversa_raw_participantes(conversa_id)
        if not participantes:
            return jsonify({"ok": False, "erro": "Conversa não encontrada."}), 404

        if user.id not in participantes:
            return jsonify({"ok": False, "erro": "Você não participa desta conversa."}), 403

        resposta_a_id = data.get("resposta_a_id")
        if resposta_a_id:
            try:
                resposta_a_id = int(resposta_a_id)
                original = db.session.get(Mensagem, resposta_a_id)
                if not original or original.conversa_id != conversa_id:
                    resposta_a_id = None
            except (TypeError, ValueError):
                resposta_a_id = None

        msg = Mensagem(
            conversa_id=conversa_id,
            remetente_id=user.id,
            texto=texto_msg,
            enviado_em=now(),
            resposta_a_id=resposta_a_id
        )
        db.session.add(msg)

        try:
            if coluna_existe_runtime("conversas", "atualizado_em"):
                db.session.execute(
                    text("UPDATE conversas SET atualizado_em = :agora WHERE id = :id"),
                    {"agora": now(), "id": conversa_id}
                )
        except Exception:
            pass

        db.session.commit()
        db.session.refresh(msg)
        log_db("Mensagem enviada", "chat", user.id)
        recipient_ids = [uid for uid in participantes if int(uid) != int(user.id)]
        # Entrega em tempo real com o objeto da mensagem — sem novo GET ao banco no navegador.
        ws_send_to_users(recipient_ids, {"type": "message.new", "message": mensagem_para_evento(msg)})
        disparar_web_push_mensagem(recipient_ids, user, msg, conversa_id)
        return jsonify({"ok": True, "id": msg.id, "message": mensagem_para_evento(msg)})

    except Exception as e:
        db.session.rollback()
        logging.exception("Erro ao enviar mensagem: %s", e)
        return jsonify({"ok": False, "erro": f"Erro ao enviar: {type(e).__name__}"}), 500


@app.route("/api/editar_mensagem/<int:msg_id>", methods=["POST"])
@login_required
def api_editar_mensagem(msg_id):
    user = current_user()
    payload = request.get_json(force=True) or {}
    novo_texto = (payload.get("texto") or "").strip()

    if not novo_texto:
        return jsonify(ok=False, erro="Mensagem vazia."), 400

    m = db.session.get(Mensagem, msg_id)
    if not m:
        return jsonify(ok=False), 404
    if m.remetente_id != user.id:
        return jsonify(ok=False, erro="Só é possível editar suas próprias mensagens."), 403
    if getattr(m, "apagado_em", None):
        return jsonify(ok=False, erro="Não é possível editar uma mensagem apagada."), 400

    m.texto = novo_texto[:4000]
    m.editado = True
    m.editado_em = now()
    db.session.commit()
    log_db(f"Mensagem {msg_id} editada.", "chat", user.id)
    c = db.session.get(Conversa, m.conversa_id)
    if c:
        ws_send_to_users([c.usuario_a_id, c.usuario_b_id], {"type": "message.edited", "conversa_id": c.id, "id": m.id, "texto": m.texto, "editado": True})
    return jsonify(ok=True, texto=m.texto)


def _anexo_extensao_permitida(nome_arquivo):
    ext = Path(nome_arquivo).suffix.lower()
    return ext not in ANEXO_EXTENSOES_BLOQUEADAS


@app.route("/api/enviar_anexo", methods=["POST"])
@login_required
def api_enviar_anexo():
    try:
        preparar_runtime_chat()
        user = current_user()
        conversa_id = int(request.form.get("conversa_id"))
        legenda = (request.form.get("texto") or "").strip()
        resposta_a_id = request.form.get("resposta_a_id")

        participantes = conversa_raw_participantes(conversa_id)
        if not participantes:
            return jsonify(ok=False, erro="Conversa não encontrada."), 404
        if user.id not in participantes:
            return jsonify(ok=False, erro="Você não participa desta conversa."), 403

        arquivo = request.files.get("arquivo")
        if not arquivo or not arquivo.filename:
            return jsonify(ok=False, erro="Nenhum arquivo enviado."), 400

        nome_original = secure_filename(arquivo.filename) or "arquivo"
        if not _anexo_extensao_permitida(nome_original):
            return jsonify(ok=False, erro="Este tipo de arquivo não é permitido."), 400

        # Descobre o tamanho antes de gravar no disco, sem precisar salvar
        # e depois apagar caso não caiba.
        arquivo.stream.seek(0, os.SEEK_END)
        tamanho_estimado = arquivo.stream.tell()
        arquivo.stream.seek(0)
        if not espaco_livre_suficiente(tamanho_estimado):
            logging.warning("Upload recusado por falta de espaço em disco (%s bytes pedidos).", tamanho_estimado)
            return jsonify(ok=False, erro="Sem espaço de armazenamento disponível no servidor no momento. Avise o TI."), 507

        pasta_conversa = UPLOADS_DIR / str(conversa_id)
        pasta_conversa.mkdir(parents=True, exist_ok=True)
        nome_disco = f"{uuid.uuid4().hex}_{nome_original}"
        caminho_disco = pasta_conversa / nome_disco
        arquivo.save(str(caminho_disco))
        tamanho = caminho_disco.stat().st_size
        tipo = arquivo.mimetype or mimetypes.guess_type(nome_original)[0] or "application/octet-stream"

        try:
            resposta_a_id = int(resposta_a_id) if resposta_a_id else None
            if resposta_a_id:
                original = db.session.get(Mensagem, resposta_a_id)
                if not original or original.conversa_id != conversa_id:
                    resposta_a_id = None
        except (TypeError, ValueError):
            resposta_a_id = None

        msg = Mensagem(
            conversa_id=conversa_id,
            remetente_id=user.id,
            texto=legenda or nome_original,
            enviado_em=now(),
            resposta_a_id=resposta_a_id,
            anexo_nome=nome_original,
            anexo_caminho=f"{conversa_id}/{nome_disco}",
            anexo_tipo=tipo,
            anexo_tamanho=tamanho,
        )
        db.session.add(msg)

        try:
            if coluna_existe_runtime("conversas", "atualizado_em"):
                db.session.execute(
                    text("UPDATE conversas SET atualizado_em = :agora WHERE id = :id"),
                    {"agora": now(), "id": conversa_id}
                )
        except Exception:
            pass

        db.session.commit()
        db.session.refresh(msg)
        log_db("Anexo enviado", "chat", user.id)
        recipient_ids = [uid for uid in participantes if int(uid) != int(user.id)]
        ws_send_to_users(recipient_ids, {"type": "message.new", "message": mensagem_para_evento(msg)})
        disparar_web_push_mensagem(recipient_ids, user, msg, conversa_id)
        return jsonify({"ok": True, "id": msg.id, "message": mensagem_para_evento(msg)})

    except Exception as e:
        db.session.rollback()
        logging.exception("Erro ao enviar anexo: %s", e)
        return jsonify({"ok": False, "erro": f"Erro ao enviar anexo: {type(e).__name__}"}), 500


@app.route("/api/anexo/<int:msg_id>")
@login_required
def api_anexo(msg_id):
    user = current_user()
    m = db.session.get(Mensagem, msg_id)
    if not m or not getattr(m, "anexo_caminho", None):
        abort(404)
    c = db.session.get(Conversa, m.conversa_id)
    if not c or (user.id not in [c.usuario_a_id, c.usuario_b_id] and user.perfil != "adm"):
        abort(403)
    caminho = UPLOADS_DIR / m.anexo_caminho
    if not caminho.exists():
        abort(404)
    return send_file(
        str(caminho),
        mimetype=m.anexo_tipo or "application/octet-stream",
        as_attachment=not (m.anexo_tipo or "").startswith("image/"),
        download_name=m.anexo_nome or caminho.name,
    )


@app.route("/api/reagir_mensagem/<int:msg_id>", methods=["POST"])
@login_required
def api_reagir_mensagem(msg_id):
    user = current_user()
    payload = request.get_json(force=True) or {}
    emoji = (payload.get("emoji") or "").strip()
    if not emoji:
        return jsonify(ok=False, erro="Emoji inválido."), 400

    m = db.session.get(Mensagem, msg_id)
    if not m:
        return jsonify(ok=False), 404
    c = db.session.get(Conversa, m.conversa_id)
    if not c or user.id not in [c.usuario_a_id, c.usuario_b_id]:
        return jsonify(ok=False), 403

    existente = Reacao.query.filter_by(mensagem_id=msg_id, usuario_id=user.id).first()
    removida = False
    if existente:
        if existente.emoji == emoji:
            db.session.delete(existente)
            removida = True
        else:
            existente.emoji = emoji
    else:
        db.session.add(Reacao(mensagem_id=msg_id, usuario_id=user.id, emoji=emoji, criado_em=now()))
    db.session.commit()

    linhas = Reacao.query.filter_by(mensagem_id=msg_id).all()
    agregada = {}
    for r in linhas:
        agregada.setdefault(r.emoji, {"emoji": r.emoji, "total": 0, "mine": False})
        agregada[r.emoji]["total"] += 1
        if r.usuario_id == user.id:
            agregada[r.emoji]["mine"] = True
    return jsonify(ok=True, removida=removida, reacoes=list(agregada.values()))


@app.route("/api/encaminhar_mensagem/<int:msg_id>", methods=["POST"])
@login_required
def api_encaminhar_mensagem(msg_id):
    user = current_user()
    payload = request.get_json(force=True) or {}
    destino_id = payload.get("destino_id")

    original = db.session.get(Mensagem, msg_id)
    if not original:
        return jsonify(ok=False), 404
    c_origem = db.session.get(Conversa, original.conversa_id)
    if not c_origem or user.id not in [c_origem.usuario_a_id, c_origem.usuario_b_id]:
        return jsonify(ok=False), 403
    if getattr(original, "apagado_em", None):
        return jsonify(ok=False, erro="Não é possível encaminhar uma mensagem apagada."), 400

    try:
        destino_id = int(destino_id)
    except (TypeError, ValueError):
        return jsonify(ok=False, erro="Destinatário inválido."), 400

    destino = db.session.get(Usuario, destino_id)
    if not destino or not destino.ativo:
        return jsonify(ok=False, erro="Destinatário inválido."), 400
    if not pode_conversar(user, destino):
        return jsonify(ok=False, erro="Você não pode enviar mensagens para este usuário."), 403

    conversa_id = conversa_raw_buscar_ou_criar(user.id, destino.id)
    if not conversa_id:
        return jsonify(ok=False, erro="Não foi possível abrir a conversa de destino."), 500

    nova = Mensagem(
        conversa_id=conversa_id,
        remetente_id=user.id,
        texto=original.texto,
        enviado_em=now(),
        encaminhada_de_id=original.remetente_id,
        anexo_nome=original.anexo_nome,
        anexo_caminho=original.anexo_caminho,
        anexo_tipo=original.anexo_tipo,
        anexo_tamanho=original.anexo_tamanho,
    )
    db.session.add(nova)

    try:
        if coluna_existe_runtime("conversas", "atualizado_em"):
            db.session.execute(
                text("UPDATE conversas SET atualizado_em = :agora WHERE id = :id"),
                {"agora": now(), "id": conversa_id}
            )
    except Exception:
        pass

    db.session.commit()
    log_db(f"Mensagem {msg_id} encaminhada para {destino.nome}.", "chat", user.id)
    return jsonify(ok=True, conversa_id=conversa_id, destino={"id": destino.id, "nome": destino.nome})


@app.route("/api/apagar_mensagem/<int:msg_id>", methods=["POST"])
@login_required
def api_apagar_msg(msg_id):
    user = current_user()
    payload = request.get_json(silent=True) or {}
    modo = (payload.get("modo") or "para_mim").strip()

    m = db.session.get(Mensagem, msg_id)
    if not m:
        return jsonify(ok=False), 404

    c = db.session.get(Conversa, m.conversa_id)
    if not c or user.id not in [c.usuario_a_id, c.usuario_b_id]:
        return jsonify(ok=False), 403

    if modo == "para_todos":
        if m.remetente_id != user.id:
            return jsonify(ok=False, error="Somente o remetente pode apagar para todos."), 403
        m.apagado_por_remetente = True
        m.apagado_por_destinatario = True
        m.apagado_em = now()
        db.session.commit()
        log_db(f"Mensagem {msg_id} apagada para todos.", "auditoria")
        ws_send_to_users([c.usuario_a_id, c.usuario_b_id], {"type": "message.deleted", "conversa_id": c.id, "id": m.id, "mode": "all"})
        return jsonify(ok=True)

    if m.remetente_id == user.id:
        m.apagado_por_remetente = True
    else:
        m.apagado_por_destinatario = True

    db.session.commit()
    log_db(f"Mensagem {msg_id} apagada para mim.", "auditoria")
    if m.remetente_id != user.id:
        ws_send_to_users([m.remetente_id], {"type": "message.deleted", "conversa_id": c.id, "id": m.id, "mode": "self"})
    return jsonify(ok=True)

@app.route("/api/fixar_mensagem/<int:msg_id>", methods=["POST"])
@login_required
def api_fixar_mensagem(msg_id):
    user = current_user()
    m = db.session.get(Mensagem, msg_id)
    if not m:
        return jsonify(ok=False), 404

    c = db.session.get(Conversa, m.conversa_id)
    if not c or user.id not in [c.usuario_a_id, c.usuario_b_id]:
        return jsonify(ok=False), 403

    m.fixado = not bool(getattr(m, "fixado", False))
    m.fixado_em = now() if m.fixado else None
    db.session.commit()
    log_db(f"Mensagem {msg_id} {'fixada' if m.fixado else 'desfixada'}.", "chat", user.id)
    return jsonify(ok=True, fixado=m.fixado)


@app.route("/api/mensagens_fixadas/<int:conversa_id>")
@login_required
def api_mensagens_fixadas(conversa_id):
    user = current_user()
    c = db.session.get(Conversa, conversa_id)
    if not c or user.id not in [c.usuario_a_id, c.usuario_b_id]:
        return jsonify(ok=False), 403

    fixadas = Mensagem.query.filter_by(conversa_id=conversa_id, fixado=True).order_by(Mensagem.id.desc()).all()
    data = [{
        "id": m.id,
        "remetente_id": m.remetente_id,
        "remetente_nome": m.remetente.nome if m.remetente else "",
        "texto": ("Mensagem apagada" if getattr(m, "apagado_em", None) else m.texto)[:140],
        "fixado_em": m.fixado_em,
    } for m in fixadas]
    return jsonify(ok=True, mensagens=data)


@app.route("/api/unread")
@login_required
def api_unread():
    user = current_user()

    try:
        rows = db.session.execute(text("""
            SELECT
                x.conversa_id,
                x.total_nao_lidas,
                x.last_id,
                m.texto,
                m.enviado_em,
                CASE
                    WHEN c.usuario_a_id = :uid THEN c.usuario_b_id
                    ELSE c.usuario_a_id
                END AS other_id,
                COALESCE(u.nome, 'Usuário') AS other_nome
            FROM (
                SELECT
                    m.conversa_id AS conversa_id,
                    COUNT(*) AS total_nao_lidas,
                    MAX(m.id) AS last_id
                FROM mensagens m
                JOIN conversas c ON c.id = m.conversa_id
                WHERE (c.usuario_a_id = :uid OR c.usuario_b_id = :uid)
                  AND m.remetente_id <> :uid
                  AND (m.apagado_por_destinatario = 0 OR m.apagado_por_destinatario IS NULL)
                  AND m.lido_em IS NULL
                  AND m.apagado_em IS NULL
                GROUP BY m.conversa_id
                ORDER BY last_id DESC
                LIMIT :limite
            ) x
            JOIN mensagens m ON m.id = x.last_id
            JOIN conversas c ON c.id = x.conversa_id
            LEFT JOIN usuarios u ON u.id = CASE
                WHEN c.usuario_a_id = :uid THEN c.usuario_b_id
                ELSE c.usuario_a_id
            END
            ORDER BY x.last_id DESC
        """), {"uid": user.id, "limite": UNREAD_MAX_CONVERSAS}).mappings().all()

        # Depois da consulta agregada, aplica a mesma regra de permissão do
        # chat para não exibir notificações de conversas que ficaram proibidas
        # após uma mudança do Painel ADM.
        other_ids = {int(r["other_id"]) for r in rows if r.get("other_id")}
        outros = {}
        if other_ids:
            outros = {u.id: u for u in Usuario.query.filter(Usuario.id.in_(other_ids), Usuario.ativo == True).all()}

        items = []
        total = 0
        for row in rows:
            other_id = int(row["other_id"] or 0)
            other = outros.get(other_id)
            if not other or not pode_conversar(user, other):
                continue
            count = int(row["total_nao_lidas"] or 0)
            total += count
            items.append({
                "conversa_id": int(row["conversa_id"]),
                "other_id": other_id,
                "other_nome": row["other_nome"],
                "count": count,
                "last_id": int(row["last_id"]),
                "texto": (row["texto"] or "")[:160],
                "enviado_em": row["enviado_em"],
            })

        return jsonify({"total": total, "items": items})
    except Exception:
        logging.exception("Falha ao consultar notificações otimizadas")
        return jsonify({"total": 0, "items": []})


@app.route("/api/digitando", methods=["POST"])
@login_required
def api_digitando():
    user = current_user()
    payload = request.get_json(force=True)
    conversa_id = int(payload.get("conversa_id") or 0)
    ativo = bool(payload.get("ativo"))
    c = db.session.get(Conversa, conversa_id)
    if not c or user.id not in [c.usuario_a_id, c.usuario_b_id]:
        return jsonify(ok=False), 403
    d = Digitando.query.filter_by(conversa_id=conversa_id, usuario_id=user.id).first()
    if ativo:
        if not d:
            d = Digitando(conversa_id=conversa_id, usuario_id=user.id)
            db.session.add(d)
        d.atualizado_em = now()
    else:
        if d:
            db.session.delete(d)
    db.session.commit()
    other_id = c.usuario_b_id if c.usuario_a_id == user.id else c.usuario_a_id
    ws_send_to_users([other_id], {"type": "typing", "conversa_id": conversa_id, "usuario_id": user.id, "nome": user.nome, "ativo": ativo})
    return jsonify(ok=True)

@app.route("/api/digitando/<int:conversa_id>")
@login_required
def api_digitando_get(conversa_id):
    user = current_user()
    limite = (datetime.now() - timedelta(seconds=DIGITANDO_EXPIRA_SECONDS)).strftime("%Y-%m-%d %H:%M:%S")

    rows = db.session.execute(text("""
        SELECT d.usuario_id, u.nome
        FROM digitando d
        LEFT JOIN usuarios u ON u.id = d.usuario_id
        WHERE d.conversa_id = :cid
          AND d.usuario_id <> :uid
          AND d.atualizado_em >= :limite
        ORDER BY d.atualizado_em DESC
        LIMIT 10
    """), {"cid": conversa_id, "uid": user.id, "limite": limite}).mappings().all()

    data = [{"usuario_id": int(r["usuario_id"]), "nome": r["nome"] or ""} for r in rows]
    return jsonify(ok=True, digitando=data)


@app.route("/api/status", methods=["POST"])
@login_required
def api_status():
    user = current_user()
    status = request.get_json(force=True).get("status", "online")
    if status not in STATUS_LABELS:
        status = "online"
    user.status = status
    user.ultimo_ping = now()
    db.session.commit()
    ws_send_to_users([u.id for u in Usuario.query.filter(Usuario.id != user.id).all()], {"type": "presence", "usuario_id": user.id, "status": status, "ultimo_ping": user.ultimo_ping})
    return jsonify(ok=True)

@app.route("/api/config_usuario", methods=["POST"])
@login_required
def api_config_usuario():
    user = current_user()
    payload = request.get_json(force=True)
    user.mensagem_ausencia = (payload.get("mensagem_ausencia") or "")[:250]
    user.som_notificacao = bool(payload.get("som_notificacao"))
    user.bloqueio_inatividade = bool(payload.get("bloqueio_inatividade"))
    user.tremer_tela = bool(payload.get("tremer_tela"))
    user.mostrar_ultimo_visto = bool(payload.get("mostrar_ultimo_visto", True))
    db.session.commit()
    return jsonify(ok=True)

@app.route("/api/tour/refazer", methods=["POST"])
@login_required
def api_tour_refazer():
    user = current_user()
    user.tour_concluido = False
    db.session.commit()
    return jsonify(ok=True)

@app.route("/api/tour/concluir", methods=["POST"])
@login_required
def api_tour_concluir():
    user = current_user()
    user.tour_concluido = True
    db.session.commit()
    return jsonify(ok=True)

@app.route("/api/tema", methods=["POST"])
@login_required
def api_tema():
    user = current_user()
    tema = request.get_json(force=True).get("tema", "verde-clinica")
    if tema not in THEMES:
        tema = "verde-clinica"
    user.tema = tema
    db.session.commit()
    return jsonify(ok=True)

@app.route("/api/favorito/<int:fav_id>", methods=["POST"])
@login_required
def api_favorito(fav_id):
    user = current_user()
    fav = Favorito.query.filter_by(usuario_id=user.id, favorito_id=fav_id).first()
    if fav:
        db.session.delete(fav)
        marcado = False
    else:
        db.session.add(Favorito(usuario_id=user.id, favorito_id=fav_id, criado_em=now()))
        marcado = True
    db.session.commit()
    return jsonify(ok=True, marcado=marcado)

@app.route("/api/buscar_mensagens")
@login_required
def api_buscar_mensagens():
    user = current_user()
    q = (request.args.get("q") or "").strip()
    if len(q) < 2:
        return jsonify(ok=True, resultados=[])

    rows = db.session.execute(text("""
        SELECT
            m.id,
            m.texto,
            m.enviado_em,
            CASE
                WHEN c.usuario_a_id = :uid THEN c.usuario_b_id
                ELSE c.usuario_a_id
            END AS other_id,
            COALESCE(u.nome, '') AS other_nome
        FROM mensagens m
        JOIN conversas c ON c.id = m.conversa_id
        LEFT JOIN usuarios u ON u.id = CASE
            WHEN c.usuario_a_id = :uid THEN c.usuario_b_id
            ELSE c.usuario_a_id
        END
        WHERE (c.usuario_a_id = :uid OR c.usuario_b_id = :uid)
          AND m.texto LIKE :q
          AND m.apagado_em IS NULL
        ORDER BY m.id DESC
        LIMIT 30
    """), {"uid": user.id, "q": f"%{q}%"}).mappings().all()

    data = [{
        "id": int(r["id"]),
        "texto": r["texto"],
        "enviado_em": r["enviado_em"],
        "other_id": int(r["other_id"]),
        "other_nome": r["other_nome"]
    } for r in rows]

    return jsonify(ok=True, resultados=data)


@app.route("/api/ping", methods=["POST"])
@login_required
def api_ping():
    user = current_user()
    agora_ts = time.time()
    ultimo_ts = float(session.get("last_ping_db_ts") or 0)

    # Evita que muitos usuários gravem no banco a cada poucos segundos.
    # O navegador pode chamar o ping com frequência, mas o banco só recebe update por intervalo.
    if agora_ts - ultimo_ts >= PING_DB_INTERVAL_SECONDS:
        user.ultimo_ping = now()
        db.session.commit()
        session["last_ping_db_ts"] = agora_ts

    return jsonify(ok=True)

@app.route("/api/revalidar", methods=["POST"])
@login_required
def api_revalidar():
    user = current_user()
    senha = request.get_json(force=True).get("senha", "")
    if user.origem_login == "local" and user.senha_hash and check_password_hash(user.senha_hash, senha):
        return jsonify(ok=True)
    # Para usuário LDAP, revalidar com AD.
    if user.origem_login == "ldap" and ldap_enabled():
        try:
            if autenticar_ldap(user.usuario, senha):
                return jsonify(ok=True)
        except Exception:
            pass
    return jsonify(ok=False), 403

@app.route("/admin/avisos/criar", methods=["POST"])
@login_required
@admin_required
def admin_aviso_criar():
    aviso = AvisoGeral(titulo=request.form.get("titulo","").strip(), texto=request.form.get("texto","").strip(), ativo=True, criado_por=current_user().id, criado_em=now())
    if aviso.titulo and aviso.texto:
        db.session.add(aviso)
        db.session.commit()
    return redirect(url_for("admin"))


@app.route("/mensagens-massa", methods=["POST"])
@login_required
def mensagem_massa():
    """Envia uma mensagem persistente para todos os usuários ativos ou para um setor.

    Cada destinatário recebe a mensagem na sua própria conversa 1:1 com o remetente.
    Assim o histórico continua sendo normal, pesquisável e compatível com o chat
    existente, sem criar um "canal paralelo" que poderia quebrar o WebSocket.
    """
    remetente = current_user()
    texto = (request.form.get("texto") or "").strip()
    setor_ids_raw = [str(v).strip() for v in request.form.getlist("setor_id") if str(v).strip()]
    # Compatibilidade com versões antigas: ainda aceitamos destinatario_id,
    # mas a interface atual envia somente setores.
    ids_raw = request.form.getlist("destinatario_id")

    if not texto:
        flash("Digite a mensagem antes de enviar.", "danger")
        return redirect(url_for("chat"))

    if len(texto) > 2000:
        flash("A mensagem em massa pode ter no máximo 2000 caracteres.", "danger")
        return redirect(url_for("chat"))

    try:
        query = Usuario.query.filter(Usuario.ativo == True, Usuario.id != remetente.id)

        # A nova interface seleciona pastas/setores, nunca pessoas individualmente.
        # "all" significa todos os colaboradores ativos.
        selected_sector_ids = []
        include_no_sector = False
        all_sectors = any(value.lower() == "all" for value in setor_ids_raw)

        if not all_sectors:
            for raw_id in setor_ids_raw:
                try:
                    value = int(raw_id)
                    if value == 0:
                        include_no_sector = True
                    elif value > 0 and value not in selected_sector_ids:
                        selected_sector_ids.append(value)
                except (TypeError, ValueError):
                    continue

        # A interface atual escolhe pessoas dentro das pastas. Quando há
        # destinatario_id, eles têm prioridade e os setores servem apenas como navegação.
        selected_ids = []
        for raw_id in ids_raw:
            try:
                value = int(raw_id)
                if value > 0 and value not in selected_ids and value != int(remetente.id):
                    selected_ids.append(value)
            except (TypeError, ValueError):
                continue

        if selected_ids:
            query = query.filter(Usuario.id.in_(selected_ids))
        elif not all_sectors:
            filters = []
            if selected_sector_ids:
                filters.append(Usuario.setor_id.in_(selected_sector_ids))
            if include_no_sector:
                filters.append(Usuario.setor_id.is_(None))
            if filters:
                query = query.filter(db.or_(*filters))

        candidatos = query.order_by(Usuario.nome.asc()).all()
        destinatarios = [u for u in candidatos if pode_conversar(remetente, u)]
        bloqueados_por_permissao = max(0, len(candidatos) - len(destinatarios))

        if not destinatarios:
            flash("Nenhum usuário autorizado pelo painel de permissões foi encontrado para receber a mensagem.", "warning")
            return redirect(url_for("chat"))

        # Busca todas as conversas do remetente de uma vez, evitando centenas de SELECTs.
        conversas_existentes = Conversa.query.filter(
            db.or_(Conversa.usuario_a_id == remetente.id, Conversa.usuario_b_id == remetente.id)
        ).all()

        por_destinatario = {}
        for conv in conversas_existentes:
            outro_id = conv.usuario_b_id if conv.usuario_a_id == remetente.id else conv.usuario_a_id
            por_destinatario[int(outro_id)] = conv

        novas_conversas = []
        for destinatario in destinatarios:
            if int(destinatario.id) not in por_destinatario:
                a, b = sorted([int(remetente.id), int(destinatario.id)])
                conv = Conversa(
                    usuario_a_id=a,
                    usuario_b_id=b,
                    criado_em=now(),
                    atualizado_em=now(),
                )
                novas_conversas.append((destinatario, conv))
                por_destinatario[int(destinatario.id)] = conv

        if novas_conversas:
            db.session.add_all([conv for _, conv in novas_conversas])
            db.session.flush()

        agora = now()
        mensagens = []
        destinatarios_mensagens = []

        for destinatario in destinatarios:
            conv = por_destinatario[int(destinatario.id)]
            conv.atualizado_em = agora
            msg = Mensagem(
                conversa_id=conv.id,
                remetente_id=remetente.id,
                texto=texto,
                enviado_em=agora,
            )
            mensagens.append(msg)
            destinatarios_mensagens.append((destinatario.id, msg, conv.id))

        db.session.add_all(mensagens)
        db.session.flush()

        # Materializa os eventos ANTES do commit terminar, mas não envia ainda.
        # Os objetos SQLAlchemy não atravessam threads; os dicionários prontos, sim.
        ws_jobs = [
            (recipient_id, {"type": "message.new", "message": mensagem_para_evento(msg)})
            for recipient_id, msg, _conv_id in destinatarios_mensagens
        ]

        db.session.commit()

        # O banco é a fonte de verdade. Só depois do commit os eventos são disparados.
        # O envio WebSocket é assíncrono para o remetente não ficar esperando N conexões.
        def _ws_massa(jobs):
            try:
                for recipient_id, event in jobs:
                    ws_send_to_users([recipient_id], event)
            except Exception:
                logging.exception("Falha no WebSocket da mensagem em massa")

        threading.Thread(
            target=_ws_massa,
            args=(ws_jobs,),
            daemon=True,
            name="cen-chat-ws-massa",
        ).start()

        # Web Push em lote, em uma única thread, sem bloquear o painel ADM.
        # Os payloads são materializados antes de sair da requisição para não
        # depender de objetos SQLAlchemy após o fechamento da sessão HTTP.
        if WEB_PUSH_ENABLED:
            push_jobs = [
                (recipient_id, _push_payload_for_message(remetente, msg, conv_id))
                for recipient_id, msg, conv_id in destinatarios_mensagens
            ]

            def _push_massa(jobs):
                try:
                    for recipient_id, payload in jobs:
                        _send_web_push_to_users([recipient_id], payload)
                except Exception:
                    logging.exception("Falha no Web Push da mensagem em massa")

            threading.Thread(
                target=_push_massa,
                args=(push_jobs,),
                daemon=True,
                name="cen-chat-webpush-massa",
            ).start()

        if all_sectors:
            destino_log = "todos os setores"
        elif selected_ids:
            destino_log = f"{len(selected_ids)} usuário(s) selecionado(s)"
        elif selected_sector_ids:
            destino_log = "setores: " + ", ".join(map(str, selected_sector_ids))
        elif include_no_sector:
            destino_log = "usuários sem setor"
        else:
            destino_log = "seleção atual"
        log_db(
            f"Mensagem em massa enviada para {len(destinatarios)} usuário(s) — {destino_log}.",
            "admin",
            remetente.id,
        )
        extra = f" {bloqueados_por_permissao} destinatário(s) foram ignorados pela matriz de permissões." if bloqueados_por_permissao else ""
        flash(f"Mensagem enviada com sucesso para {len(destinatarios)} usuário(s)." + extra, "success")
        return redirect(url_for("chat"))

    except Exception as e:
        db.session.rollback()
        logging.exception("Erro ao enviar mensagem em massa: %s", e)
        flash("Não foi possível enviar a mensagem em massa. Nenhuma alteração pendente foi mantida.", "danger")
        return redirect(url_for("chat"))

@app.route("/admin/avisos/<int:id>/toggle", methods=["POST"])
@login_required
@admin_required
def admin_aviso_toggle(id):
    a = db.session.get(AvisoGeral, id)
    if a:
        a.ativo = not a.ativo
        db.session.commit()
    return redirect(url_for("admin"))

@app.route("/admin/usuarios/criar", methods=["POST"])
@login_required
@admin_required
def admin_criar_usuario():
    nome = request.form.get("nome","").strip()
    usuario = request.form.get("usuario","").strip().lower()
    senha = request.form.get("senha","")
    setor_id = request.form.get("setor_id") or None
    perfil = request.form.get("perfil","usuario")
    if nome and usuario and senha and not Usuario.query.filter_by(usuario=usuario).first():
        db.session.add(Usuario(nome=nome, usuario=usuario, senha_hash=generate_password_hash(senha), perfil=perfil, setor_id=setor_id, setor_manual=bool(setor_id), ativo=True, aguardando_setor=False if setor_id else True, origem_login="local", criado_em=now()))
        db.session.commit()
    return redirect(url_for("admin"))

@app.route("/admin/usuarios/<int:id>/setor", methods=["POST"])
@login_required
@admin_required
def admin_usuario_setor(id):
    u = db.session.get(Usuario, id)
    if u:
        setor_id = request.form.get("setor_id") or None
        fixar = request.form.get("fixar_setor") == "1"
        u.setor_id = int(setor_id) if setor_id else None
        u.setor_manual = bool(setor_id) and fixar
        u.aguardando_setor = False if setor_id else True
        db.session.commit()
    return redirect(url_for("admin"))


@app.route("/admin/usuarios/<int:id>/setor/desfixar", methods=["POST"])
@login_required
@admin_required
def admin_usuario_desfixar_setor(id):
    u = db.session.get(Usuario, id)
    if u:
        u.setor_manual = False
        db.session.commit()
        flash("Setor liberado para o LDAP. A próxima sincronização poderá atualizar o setor conforme o grupo AD.", "success")
    return redirect(url_for("admin"))

@app.route("/admin/usuarios/<int:id>/senha", methods=["POST"])
@login_required
@admin_required
def admin_usuario_senha(id):
    u = db.session.get(Usuario, id)
    senha = request.form.get("senha","")
    if u and senha and u.origem_login == "local":
        u.senha_hash = generate_password_hash(senha)
        db.session.commit()
    return redirect(url_for("admin"))

@app.route("/admin/usuarios/<int:id>/toggle", methods=["POST"])
@login_required
@admin_required
def admin_usuario_toggle(id):
    u = db.session.get(Usuario, id)
    if u and not u.local_emergencia:
        u.ativo = not u.ativo
        db.session.commit()
    return redirect(url_for("admin"))


@app.route("/admin/usuarios/<int:id>/excluir", methods=["POST"])
@login_required
@admin_required
def admin_usuario_excluir(id):
    admin = current_user()
    u = db.session.get(Usuario, id)
    if not u:
        flash("Usuário não encontrado.", "danger")
        return redirect(url_for("admin"))
    if u.local_emergencia:
        flash("A conta de emergência Val não pode ser excluída.", "danger")
        return redirect(url_for("admin"))
    if admin and admin.id == u.id:
        flash("Você não pode excluir seu próprio usuário logado.", "danger")
        return redirect(url_for("admin"))

    # Preserva auditoria: não apaga mensagens, conversas, logs nem favoritos.
    u.ativo = False
    u.status = "offline"
    db.session.commit()
    flash("Usuário desativado. Histórico preservado para auditoria.", "success")
    log_db(f"Usuário {u.usuario} desativado pelo administrador.", "admin")
    return redirect(url_for("admin"))

@app.route("/admin/setores/criar", methods=["POST"])
@login_required
@admin_required
def admin_setor_criar():
    nome = (request.form.get("nome") or "").strip()
    slug_base = request.form.get("slug") or nome
    descricao = (request.form.get("descricao") or "").strip()

    if not nome:
        flash("Informe o nome do setor.", "danger")
        return redirect(url_for("admin") + "#admin-setores")

    slug = slugify_unico(slug_base)

    try:
        s = Setor(nome=nome, slug=slug, descricao=descricao, ativo=True, criado_em=now())
        db.session.add(s)
        db.session.flush()

        for other in Setor.query.filter(Setor.id != s.id).all():
            # Permissões são opcionais e nunca controlam a existência do setor.
            if not PermissaoSetor.query.filter_by(origem_id=s.id, destino_id=other.id).first():
                db.session.add(PermissaoSetor(origem_id=s.id, destino_id=other.id, permitido=True))
            if not PermissaoSetor.query.filter_by(origem_id=other.id, destino_id=s.id).first():
                db.session.add(PermissaoSetor(origem_id=other.id, destino_id=s.id, permitido=True))

        db.session.commit()
        flash(f"Setor '{nome}' criado com sucesso.", "success")
    except Exception:
        db.session.rollback()
        logging.exception("Falha ao criar setor %s", nome)
        flash("Não foi possível criar o setor. Nenhuma alteração foi aplicada.", "danger")

    return redirect(url_for("admin") + "#admin-setores")

@app.route("/admin/setores/<int:id>/editar", methods=["POST"])
@login_required
@admin_required
def admin_setor_editar(id):
    s = db.session.get(Setor, id)
    if s:
        s.nome = request.form.get("nome", s.nome)
        s.slug = slugify_unico(request.form.get("slug") or s.nome, excluir_id=s.id)
        s.descricao = request.form.get("descricao","")
        s.ativo = request.form.get("ativo") == "1"
        db.session.commit()
    return redirect(url_for("admin"))

@app.route("/admin/setores/<int:id>/excluir", methods=["POST"])
@login_required
@admin_required
def admin_setor_excluir(id):
    s = db.session.get(Setor, id)
    if s:
        for u in Usuario.query.filter_by(setor_id=s.id).all():
            u.setor_id = None
            u.aguardando_setor = True
        PermissaoSetor.query.filter((PermissaoSetor.origem_id == s.id) | (PermissaoSetor.destino_id == s.id)).delete(synchronize_session=False)
        db.session.delete(s)
        db.session.commit()
        flash("Setor excluído com sucesso.", "success")
    return redirect(url_for("admin"))



@app.route("/admin/ldap/sincronizar", methods=["POST"])
@login_required
@admin_required
def admin_ldap_sincronizar():
    try:
        resultado = sync_ldap_users()
        flash(
            f"LDAP sincronizado: {resultado['criados']} criados, {resultado['atualizados']} atualizados, {len(resultado['erros'])} erros.",
            "success" if not resultado["erros"] else "warning"
        )
    except Exception as e:
        logging.exception("Falha na sincronização LDAP: %s", e)
        flash(f"Falha na sincronização LDAP: {e}", "danger")
    return redirect(url_for("admin"))

@app.route("/admin/ldap/sincronizar/<setor_slug>", methods=["POST"])
@login_required
@admin_required
def admin_ldap_sincronizar_setor(setor_slug):
    try:
        resultado = sync_ldap_users(setor_slug=setor_slug)
        flash(
            f"LDAP {setor_slug}: {resultado['criados']} criados, {resultado['atualizados']} atualizados.",
            "success" if not resultado["erros"] else "warning"
        )
    except Exception as e:
        logging.exception("Falha na sincronização LDAP do setor %s: %s", setor_slug, e)
        flash(f"Falha na sincronização LDAP do setor {setor_slug}: {e}", "danger")
    return redirect(url_for("admin"))

@app.route("/admin/permissoes/liberar-todas", methods=["POST"])
@login_required
@admin_required
def admin_permissoes_liberar_todas():
    liberar_todas_permissoes_conversa()
    flash("Todas as conversas entre usuários ativos foram liberadas.", "success")
    return redirect(url_for("admin"))

@app.route("/admin/permissoes", methods=["POST"])
@login_required
@admin_required
def admin_permissoes():
    for origem in Setor.query.all():
        for destino in Setor.query.all():
            p = PermissaoSetor.query.filter_by(origem_id=origem.id, destino_id=destino.id).first()
            if not p:
                p = PermissaoSetor(origem_id=origem.id, destino_id=destino.id)
                db.session.add(p)
            p.permitido = request.form.get(f"perm_{origem.id}_{destino.id}") == "on"
    db.session.commit()
    _invalidar_cache_permissoes()
    return redirect(url_for("admin"))

@app.route("/exportar/conversa/<int:conversa_id>/<fmt>")
@login_required
def exportar_conversa(conversa_id, fmt):
    user = current_user()
    c = db.session.get(Conversa, conversa_id)
    if user.perfil != "adm":
        abort(403)
    if not c or user.id not in [c.usuario_a_id, c.usuario_b_id] or fmt not in ("txt","html"):
        abort(403)
    other_id = c.usuario_b_id if c.usuario_a_id == user.id else c.usuario_a_id
    other = db.session.get(Usuario, other_id)
    msgs = Mensagem.query.filter_by(conversa_id=conversa_id).order_by(Mensagem.id).all()
    if fmt == "txt":
        linhas = [f"Cen-Chat - Exportação", f"Conversa com: {other.nome}", f"Gerado em: {now()}", "="*70]
        for m in msgs:
            linhas.append(f"[{m.enviado_em}] {m.remetente.nome}: {m.texto}")
        return Response("\n".join(linhas), mimetype="text/plain; charset=utf-8", headers={"Content-Disposition": f"attachment; filename=conversa_{other.usuario}.txt"})
    html = "<html><meta charset='utf-8'><body><h1>Cen-Chat</h1>" + "".join([f"<p><b>{m.remetente.nome}</b> [{m.enviado_em}]: {m.texto}</p>" for m in msgs]) + "</body></html>"
    return Response(html, mimetype="text/html; charset=utf-8", headers={"Content-Disposition": f"attachment; filename=conversa_{other.usuario}.html"})

def backup_zip_completo():
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        # O banco definitivo é MariaDB/MySQL; o backup lógico do banco deve ser feito no servidor de banco.
        db_file = APP_DIR / "cenchat.db"
        if db_file.exists():
            z.write(db_file, "cenchat.db")
        if (APP_DIR / ".env").exists():
            z.write(APP_DIR / ".env", "config/.env")
        for p in LOG_DIR.glob("*.log"):
            z.write(p, f"logs/{p.name}")
        z.writestr("README_BACKUP.txt", f"Backup completo gerado em {now()}\nO banco do Cen-Chat usa MariaDB/MySQL. Faça também o dump lógico do banco pelo servidor de banco.\n")
    out.seek(0)
    return out

@app.route("/admin/backup/completo", methods=["POST"])
@login_required
@admin_required
def backup_completo():
    return send_file(backup_zip_completo(), as_attachment=True, download_name=f"backup_completo_cenchat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip", mimetype="application/zip")

@app.route("/admin/backup/usuario/<int:id>", methods=["POST"])
@login_required
@admin_required
def backup_usuario(id):
    u = db.session.get(Usuario, id)
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{u.usuario}/RESUMO.txt", f"Backup usuário {u.nome} gerado em {now()}")
    out.seek(0)
    return send_file(out, as_attachment=True, download_name=f"backup_usuario_{u.usuario}.zip", mimetype="application/zip")

@app.route("/admin/backup/setor/<int:id>", methods=["POST"])
@login_required
@admin_required
def backup_setor(id):
    s = db.session.get(Setor, id)
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("RESUMO.txt", f"Backup setor {s.nome} gerado em {now()}")
        for u in Usuario.query.filter_by(setor_id=s.id).all():
            z.writestr(f"{s.slug}/{u.usuario}/usuario.txt", f"{u.nome} - {u.usuario}")
    out.seek(0)
    return send_file(out, as_attachment=True, download_name=f"backup_setor_{s.slug}.zip", mimetype="application/zip")

@app.context_processor
def inject():
    return {"current_user": current_user(), "themes": THEMES, "status_labels": STATUS_LABELS}

@app.errorhandler(Exception)
def handle_error(e):
    logging.exception("Erro no Cen-Chat: %s", e)
    if getattr(e, "code", None) in (403, 404):
        return e
    return "Erro interno registrado nos logs técnicos.", 500


@app.route("/health")
def health_check():
    return jsonify({"ok": True, "servico": "cen-chat", "status": "online"})

@app.route("/api/diagnostico")
@login_required
def api_diagnostico():
    """Diagnóstico simples do navegador/servidor sem expor segredos."""
    db_ok = False
    db_error = None
    try:
        db.session.execute(text("SELECT 1")).scalar()
        db_ok = True
    except Exception as exc:
        db.session.rollback()
        db_error = type(exc).__name__
    ws_ok = bool(_WS_THREAD and _WS_THREAD.is_alive() and _WS_SERVER is not None and _WS_LOOP is not None and _WS_LOOP.is_running())
    return jsonify({
        "ok": True,
        "versao": "20260928-permissoes-setores",
        "banco": db_ok,
        "banco_erro": db_error,
        "websocket": ws_ok,
        "websocket_porta": WS_PORT,
        "waitress": True,
    })

@app.route("/api/ws/token")
@login_required
def api_ws_token():
    user = current_user()
    ativo = bool(_WS_THREAD and _WS_THREAD.is_alive() and _WS_SERVER is not None and _WS_LOOP is not None and _WS_LOOP.is_running())
    if not ativo:
        return jsonify({"ok": False, "erro": "Servidor WebSocket indisponível.", "porta": WS_PORT, "rota": WS_PATH, "detalhe": _WS_START_ERROR}), 503
    return jsonify({"ok": True, "token": criar_ws_token(user.id), "porta": WS_PORT, "rota": WS_PATH, "ttl": WS_TOKEN_MAX_AGE})

@app.route("/api/ws/status")
@login_required
def api_ws_status():
    """Diagnóstico do canal WebSocket sem expor conexões ou tokens."""
    ativo = bool(_WS_THREAD and _WS_THREAD.is_alive() and _WS_SERVER is not None and _WS_LOOP is not None and _WS_LOOP.is_running())
    return jsonify({
        "ok": True,
        "ativo": ativo,
        "porta": WS_PORT,
        "rota": WS_PATH,
        "thread_viva": bool(_WS_THREAD and _WS_THREAD.is_alive()),
        "servidor_iniciado": bool(_WS_SERVER is not None),
        "clientes_conectados": ws_client_count(),
        "erro_inicializacao": _WS_START_ERROR,
    })


@app.route("/api/marcar_lida/<int:conversa_id>", methods=["POST"])
@login_required
def api_marcar_lida(conversa_id):
    user = current_user()
    conv = Conversa.query.get_or_404(conversa_id)

    if user.id not in [conv.usuario_a_id, conv.usuario_b_id]:
        abort(403)

    msgs = Mensagem.query.filter(
        Mensagem.conversa_id == conversa_id,
        Mensagem.remetente_id != user.id,
        Mensagem.apagado_por_destinatario == False,
        Mensagem.apagado_em.is_(None)
    ).all()

    changed = 0
    for msg in msgs:
        if hasattr(msg, "lido_em"):
            if not msg.lido_em:
                msg.lido_em = now()
                changed += 1

    if changed:
        db.session.commit()
        lidos_ids = [int(m.id) for m in msgs if m.lido_em and m.remetente_id != user.id]
        remetente_ids = {int(m.remetente_id) for m in msgs if m.lido_em}
        ws_send_to_users(remetente_ids, {"type": "message.read", "conversa_id": conversa_id, "reader_id": user.id, "message_ids": lidos_ids, "timestamp": now()})

    return jsonify({"ok": True, "marcadas": changed})





@app.route("/admin/aviso/<int:aviso_id>/editar", methods=["POST"])
@login_required
@admin_required
def admin_editar_aviso(aviso_id):
    aviso = AvisoGeral.query.get_or_404(aviso_id)
    titulo = (request.form.get("titulo") or "").strip()
    texto = (request.form.get("texto") or request.form.get("mensagem") or "").strip()

    if hasattr(aviso, "titulo"):
        aviso.titulo = titulo or getattr(aviso, "titulo", "") or "Aviso"
    if hasattr(aviso, "texto"):
        aviso.texto = texto
    elif hasattr(aviso, "mensagem"):
        aviso.mensagem = texto
    elif hasattr(aviso, "conteudo"):
        aviso.conteudo = texto

    db.session.commit()
    log_db(f"Aviso {aviso_id} editado.", "auditoria")
    return redirect(url_for("admin"))

@app.route("/admin/aviso/<int:aviso_id>/toggle", methods=["POST"])
@login_required
@admin_required
def admin_toggle_aviso(aviso_id):
    aviso = AvisoGeral.query.get_or_404(aviso_id)
    if hasattr(aviso, "ativo"):
        aviso.ativo = not bool(aviso.ativo)
        db.session.commit()
        log_db(f"Aviso {aviso_id} ativado/desativado.", "auditoria")
    return redirect(url_for("admin"))

@app.route("/admin/aviso/<int:aviso_id>/excluir", methods=["POST"])
@login_required
@admin_required
def admin_excluir_aviso(aviso_id):
    aviso = AvisoGeral.query.get_or_404(aviso_id)
    db.session.delete(aviso)
    db.session.commit()
    log_db(f"Aviso {aviso_id} excluído.", "auditoria")
    return redirect(url_for("admin"))



@app.route("/admin/auditoria/usuario/<int:usuario_id>/html")
@login_required
@admin_required
def admin_auditoria_usuario_html(usuario_id):
    alvo = Usuario.query.get_or_404(usuario_id)

    conversas = Conversa.query.filter(
        db.or_(Conversa.usuario_a_id == alvo.id, Conversa.usuario_b_id == alvo.id)
    ).order_by(Conversa.atualizado_em.desc()).all()

    rows = []
    for conv in conversas:
        other_id = conv.usuario_b_id if conv.usuario_a_id == alvo.id else conv.usuario_a_id
        other = db.session.get(Usuario, other_id)
        mensagens = Mensagem.query.filter_by(conversa_id=conv.id).order_by(Mensagem.id.asc()).all()
        rows.append({"conversa": conv, "other": other, "mensagens": mensagens})

    html = render_template("auditoria_usuario.html", alvo=alvo, rows=rows, gerado_em=now())
    safe_nome = re.sub(r"[^a-zA-Z0-9_-]+", "_", alvo.nome or f"usuario_{alvo.id}").strip("_").lower() or f"usuario_{alvo.id}"
    filename = f"auditoria_pessoal_{safe_nome}.html"
    return Response(
        html,
        mimetype="text/html; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )



@app.route("/admin/usuarios/<int:id>/editar-completo", methods=["POST"])
@login_required
@admin_required
def admin_usuario_editar_completo(id):
    u = db.session.get(Usuario, id)
    if not u:
        flash("Usuário não encontrado.", "danger")
        return redirect(url_for("admin"))

    nome = request.form.get("nome", "").strip()
    usuario_login = request.form.get("usuario", "").strip().lower()
    senha = request.form.get("senha", "")
    perfil = request.form.get("perfil", "usuario")
    setor_id = request.form.get("setor_id") or None
    fixar_setor = request.form.get("fixar_setor") == "1"
    status = request.form.get("status", u.status)

    if nome:
        u.nome = nome
    if usuario_login:
        existente = Usuario.query.filter(Usuario.usuario == usuario_login, Usuario.id != u.id).first()
        if not existente:
            u.usuario = usuario_login
    if not u.local_emergencia:
        u.perfil = perfil
    u.setor_id = int(setor_id) if setor_id else None
    u.setor_manual = bool(setor_id) and fixar_setor
    u.aguardando_setor = False if setor_id else True
    u.status = status
    if senha and u.origem_login == "local":
        u.senha_hash = generate_password_hash(senha)

    db.session.commit()
    flash("Usuário atualizado.", "success")
    log_db(f"Usuário {u.usuario} atualizado pelo administrador.", "admin")
    return redirect(url_for("admin"))

if __name__ == "__main__":
    host = os.getenv("APP_HOST", "0.0.0.0")
    port = int(os.getenv("APP_PORT", "5050"))
    print(f"Cen-Chat HTTP: http://{host}:{port}", flush=True)
    print(f"Cen-Chat WebSocket: ws://{WS_HOST}:{WS_PORT}{WS_PATH}", flush=True)
    ws_ok = iniciar_websocket()
    if not ws_ok:
        print("ATENÇÃO: o HTTP vai subir, mas o tempo real está indisponível.", flush=True)
    else:
        print(f"Tempo real confirmado na porta {WS_PORT}.", flush=True)

    # Prepara o banco MariaDB/MySQL antes de aceitar tráfego, mas sem derrubar
    # o servidor caso o banco esteja temporariamente indisponível. Nesse caso
    # o before_request tentará novamente na primeira requisição.
    with app.app_context():
        db_ok = preparar_runtime_chat()
        _prepare_vapid_subscription_state()
    if db_ok:
        print("OK: banco MariaDB/MySQL preparado.", flush=True)
    else:
        print("ATENÇÃO: banco ainda não está disponível; o Cen-Chat continuará tentando na primeira requisição.", flush=True)

    iniciar_sync_ldap_background()

    try:
        from waitress import serve
        logging.info("Iniciando HTTP/Waitress em %s:%s", host, port)
        print(f"OK: HTTP/Waitress ativo em http://{host}:{port}", flush=True)
        print(f"Use no navegador: http://10.10.10.192:{port}/chat", flush=True)
        serve(app, host=host, port=port, threads=int(os.getenv("WAITRESS_THREADS", "48")), connection_limit=int(os.getenv("WAITRESS_CONNECTION_LIMIT", "1000")), channel_timeout=int(os.getenv("WAITRESS_CHANNEL_TIMEOUT", "120")))
    except Exception:
        logging.exception("Falha ao iniciar Waitress; usando app.run")
        print("Waitress falhou; iniciando Flask fallback...", flush=True)
        app.run(debug=False, host=host, port=port, threaded=True)
