@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title Cen-Chat - Instalacao

REM --- Garante permissao de Administrador para o Firewall ---
if /I not "%~1"=="--elevated" (
  fltmc >nul 2>&1
  if errorlevel 1 (
    echo Solicitando permissao de Administrador para concluir a instalacao...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/c \"%~f0\" --elevated' -WorkingDirectory '%~dp0' -Verb RunAs -Wait"
    exit /b %errorlevel%
  )
)

cls
echo.
echo ==========================================================
echo                  CEN-CHAT - INSTALADOR
echo ==========================================================
echo.
echo Este instalador nao altera nem recria o banco MariaDB existente.
echo.
echo Portas:
echo   HTTP       5050
echo   WebSocket 5051
 echo.
echo O instalador vai:
echo   1. Criar um venv novo
echo   2. Instalar as dependencias do requirements.txt
echo   3. Corrigir/criar o SECRET_KEY do .env quando necessario
echo   4. Liberar as portas 5050 e 5051 no Firewall do Windows
echo   5. Validar a instalacao
echo.
echo ==========================================================
echo.

set "PYTHON_CMD="
py -3.13 -V >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=py -3.13"
if not defined PYTHON_CMD (
  py -3.12 -V >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -3.12"
)
if not defined PYTHON_CMD (
  python3.13.exe -V >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=python3.13.exe"
)
if not defined PYTHON_CMD (
  python3.12.exe -V >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=python3.12.exe"
)
if not defined PYTHON_CMD goto :NO_PYTHON
if not exist "requirements.txt" goto :NO_REQUIREMENTS
if not exist "app.py" goto :NO_APP

if exist "venv" (
  echo Removendo ambiente Python antigo...
  rmdir /s /q "venv"
)

echo.
echo [1/5] Criando ambiente Python...
%PYTHON_CMD% -m venv venv
if errorlevel 1 goto :VENV_ERROR
if not exist "venv\Scripts\python.exe" goto :VENV_ERROR

echo.
echo [2/5] Atualizando pip e instalando dependencias...
"venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :PIP_ERROR
"venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :PIP_ERROR

if not exist ".env" (
  if exist ".env.example" (
    copy /y ".env.example" ".env" >nul
    echo .env criado a partir do .env.example.
  ) else goto :ENV_ERROR
)

echo.
echo [3/5] Validando .env...
"venv\Scripts\python.exe" -c "from pathlib import Path; import secrets; p=Path('.env'); t=p.read_text(encoding='utf-8-sig') if p.exists() else ''; lines=t.splitlines(); desired={'APP_HOST':'0.0.0.0','APP_PORT':'5050','WS_HOST':'0.0.0.0','WS_PORT':'5051'}; out=[]; seen=set(); [ (out.append(key+'='+desired[key]), seen.add(key)) if key in desired and key not in seen else (out.append(line) if key not in desired else None) for line in lines for key in [line.split('=',1)[0].strip() if '=' in line else ''] ]; [out.append(k+'='+v) for k,v in desired.items() if k not in seen]; out.append('SECRET_KEY='+secrets.token_hex(32)) if not any(x.startswith('SECRET_KEY=') for x in out) else None; p.write_text('\n'.join(out)+'\n',encoding='utf-8'); print('Configuracao do .env validada.')"
if errorlevel 1 goto :ENV_ERROR

echo.
echo [4/5] Configurando Firewall (5050 + 5051)...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ErrorActionPreference='Stop'; foreach($p in @(5050,5051)){ $n='Cen-Chat Porta '+$p; Get-NetFirewallRule -DisplayName $n -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue; New-NetFirewallRule -DisplayName $n -Direction Inbound -Protocol TCP -LocalPort $p -Action Allow -Profile Any | Out-Null }; Write-Host '[OK] Portas 5050 e 5051 liberadas.'"
if errorlevel 1 (
  echo [AVISO] Nao foi possivel criar automaticamente as regras do Firewall.
  echo O Cen-Chat pode funcionar localmente, mas computadores da rede podem nao acessar 5050/5051.
)

echo.
echo [5/5] Validando instalacao...
"venv\Scripts\python.exe" -m py_compile app.py sincronizar_ldap.py scripts\gerar_vapid.py
if errorlevel 1 goto :SYNTAX_ERROR
"venv\Scripts\python.exe" -c "import flask,sqlalchemy,pymysql,waitress,websockets; print('Dependencias principais OK'); print('websockets',websockets.__version__)"
if errorlevel 1 goto :PIP_ERROR

if not exist "logs" mkdir "logs"

echo.
echo ==========================================================
echo                INSTALACAO CONCLUIDA
 echo ==========================================================
echo.
echo Execute inicia.bat para iniciar o servidor.
echo Acesso: http://10.10.10.192:5050/login
echo.
pause
exit /b 0

:NO_PYTHON
echo ERRO: Python 3.12 ou 3.13 nao encontrado.
echo Instale Python e marque "Add Python to PATH".
pause
exit /b 1
:NO_REQUIREMENTS
echo ERRO: requirements.txt nao encontrado.
pause
exit /b 1
:NO_APP
echo ERRO: app.py nao encontrado.
pause
exit /b 1
:VENV_ERROR
echo ERRO ao criar o ambiente virtual.
pause
exit /b 1
:PIP_ERROR
echo ERRO ao instalar as dependencias Python.
pause
exit /b 1
:ENV_ERROR
echo ERRO ao criar/configurar o .env.
pause
exit /b 1
:SYNTAX_ERROR
echo ERRO: falha na validacao de sintaxe Python.
pause
exit /b 1
