# Instalação do CEN-Chat

1. O banco MariaDB `cenchat` já deve existir no servidor.
2. Prefira Python 3.12 ou 3.13 no Windows para esta versão.
3. Extraia o pacote.
4. Rode `instalar.bat`.
5. O instalador remove o `venv` antigo, cria um novo, instala as dependências e libera as portas 5050 e 5051 no Firewall do Windows.
6. O instalador não cria/importa o banco e não procura `Banco.sql`.
7. Depois da instalação, rode `inicia.bat`.
8. Deixe a janela do servidor aberta enquanto o Cen-Chat estiver em uso.
9. Acesse `http://10.10.10.192:5050/login`.

O `INICIAR_OCULTO.vbs` permanece disponível apenas para quem precisar iniciar o servidor sem manter o CMD visível.

### Diagnóstico

Depois de entrar no Cen-Chat, `http://SEU_SERVIDOR:5050/api/diagnostico` mostra o estado do banco e do WebSocket. O navegador também exibe o indicador de tempo real no chat.
