CREATE INDEX idx_mensagens_conversa_id ON mensagens (conversa_id);
CREATE INDEX idx_mensagens_remetente_id ON mensagens (remetente_id);
CREATE INDEX idx_mensagens_enviado_em ON mensagens (enviado_em);
CREATE INDEX idx_mensagens_conversa_enviado ON mensagens (conversa_id, enviado_em);
CREATE INDEX idx_mensagens_conversa_id_id ON mensagens (conversa_id, id);

CREATE INDEX idx_conversas_usuario_a ON conversas (usuario_a_id);
CREATE INDEX idx_conversas_usuario_b ON conversas (usuario_b_id);
CREATE INDEX idx_conversas_atualizado ON conversas (atualizado_em);

CREATE INDEX idx_usuarios_setor_id ON usuarios (setor_id);
CREATE INDEX idx_usuarios_usuario ON usuarios (usuario);

CREATE INDEX idx_permissoes_origem_destino ON permissoes_setores (origem_id, destino_id);
CREATE INDEX idx_digitando_conversa_atualizado ON digitando (conversa_id, atualizado_em);
