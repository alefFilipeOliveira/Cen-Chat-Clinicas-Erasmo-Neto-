-- Execute apenas se preferir migrar manualmente o banco existente.
-- O app também cria esta coluna automaticamente na inicialização.

ALTER TABLE usuarios ADD COLUMN setor_manual BOOLEAN NOT NULL DEFAULT FALSE;
UPDATE usuarios SET setor_manual = TRUE WHERE setor_id IS NOT NULL;

-- Se a coluna já existir, não execute novamente.
