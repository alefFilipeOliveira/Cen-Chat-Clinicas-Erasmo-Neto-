# LDAP e setores do Cen-Chat

O LDAP é usado para localizar e autenticar usuários.

Os setores pertencem exclusivamente ao Cen-Chat. A sincronização LDAP não cria
setores, não altera `usuarios.setor_id` e não ativa/desativa usuários existentes.
Usuários novos entram sem setor e podem ser organizados pelo Painel ADM ou
diretamente no banco MariaDB/MySQL.
