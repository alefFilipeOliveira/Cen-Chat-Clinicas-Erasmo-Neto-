-- Cen-Chat: alinhamento visual/cadastral dos 15 setores atuais
-- Execute com backup do banco. O script não apaga usuários nem histórico.
-- Ajuste nomes existentes e cria apenas o que estiver faltando.

UPDATE setores SET nome='Jurídico', slug='juridico', ativo=1 WHERE LOWER(nome) IN ('juridíco','juridico');
UPDATE setores SET nome='RH', slug='rh', ativo=1 WHERE LOWER(nome)='nacen';
UPDATE setores SET ativo=0 WHERE LOWER(nome)='sem setor';

INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Apoio','apoio','Apoio interno',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='apoio');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Conferência','conferencia','Conferência',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='conferencia');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Faturamento','faturamento','Faturamento',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='faturamento');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Financeiro','financeiro','Financeiro',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='financeiro');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Marcação','marcacao','Marcação',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='marcacao');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Profissionais','profissionais','Profissionais da clínica',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='profissionais');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Recepção','recepcao','Recepção',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='recepcao');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Recepção Nacen','recepcao-nacen','Recepção Nacen',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='recepcao-nacen');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Recepção Nacen+','recepcao-nacen-2','Recepção Nacen+',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='recepcao-nacen-2');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Secretarias','secretarias','Secretarias',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='secretarias');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Almoxarifado','almoxarifado','Almoxarifado',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='almoxarifado');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'Adm Nacen','adm-nacen','Administração Nacen',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='adm-nacen');
INSERT INTO setores (nome, slug, descricao, ativo, criado_em)
SELECT 'TI','ti','Tecnologia da informação',1,NOW()
WHERE NOT EXISTS (SELECT 1 FROM setores WHERE slug='ti');
