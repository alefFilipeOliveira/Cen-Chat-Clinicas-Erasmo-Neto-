# Cen-Chat — Atualização após 1 mês de uso

## Correções e melhorias

- Exceção operacional para Valdirene: a matriz de permissões não impede a comunicação dela com outros setores.
- Envio em massa passa a respeitar a matriz de permissões; destinatários não autorizados são ignorados.
- Busca de mensagens dentro da conversa, com destaque da mensagem encontrada.
- Botão `🔍 Busca` no topo abre a busca de histórico existente.
- Abaixo do nome do usuário fica somente a última mensagem; quando não existe conversa, fica vazio.
- Setores mostram a quantidade de pessoas online no próprio cabeçalho.
- Respostas longas e mensagens muito grandes recebem quebra de linha adequada para evitar cortes visuais.
- Endpoint de setores foi refeito para usar consultas em lote, reduzindo consultas repetidas.
- Conversas recentes usam menos consultas repetidas ao banco.
- Atualizações automáticas de setores e dashboard foram espaçadas para reduzir carga.
- Permissões continuam persistentes no banco e não são restauradas pelo LDAP.

## Validação realizada

- Compilação Python (`app.py`, `sincronizar_ldap.py`, `scripts/gerar_vapid.py`).
- Verificação sintática JavaScript (`chat.js`, `erasminho.js`).
- Validação AST de rotas e funções principais.
- Verificação estática dos recursos solicitados.
- Teste de integridade do ZIP final.

## Observação

Os testes realizados nesta preparação são de código, estrutura e integridade do pacote. O comportamento final ainda depende do MariaDB, LDAP, navegador e rede do ambiente da clínica.


## Ajuste complementar — setores e Erasminho (25/09/2026)
- Removido o contador/botão em formato de bolinha vermelha do cabeçalho dos setores; a quantidade de mensagens não lidas continua ao lado do usuário.
- “Sem setor” deixou de aparecer como pasta de conversa no /chat; continua disponível no painel administrativo para correção de vínculos.
- O Erasminho agora tenta autorizar o navegador automaticamente na primeira pergunta, com criação temporária quando o Puter permitir.
- A chamada da IA deixou de usar `stream:true` para evitar o cenário documentado de requisições que podem ficar penduradas em erros; também foi removido `max_tokens`.
- O modelo padrão do navegador foi alinhado para `gpt-5-nano`, que é o modelo padrão documentado atualmente pelo Puter.js.
- O painel do Erasminho passou a mostrar o estado de conexão/autorização e o erro fica em uma única ação de recuperação, sem loop de “Tentar novamente”.

- A pasta “Sem setor” não aparece mais no chat; o banco continua preservando esse estado para usuários sem vínculo.
- “Recepção Erasmo” é exibida como “Recepção” no chat, sem alterar o nome gravado no banco.
- Foi incluído `docs/ATUALIZAR_SETORES_15.sql` como apoio para alinhar uma instalação/banco antigo aos 15 setores atuais, sem apagar usuários ou histórico.
