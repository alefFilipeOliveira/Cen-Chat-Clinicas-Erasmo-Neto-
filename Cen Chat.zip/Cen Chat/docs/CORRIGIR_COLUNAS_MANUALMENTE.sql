-- ==========================================================
-- CEN-CHAT — Correção manual de colunas que faltam
-- ==========================================================
-- Rode este script DIRETO no seu banco (phpMyAdmin, HeidiSQL,
-- DBeaver, MySQL Workbench, ou linha de comando do mysql/mariadb),
-- conectado no banco "cenchat" (ou o nome que você usa).
--
-- Isso resolve o erro "Unknown column 'usuarios.tremer_tela'..."
-- (e qualquer outra coluna que a migração automática do sistema
-- não tenha conseguido criar sozinha, por qualquer motivo).
--
-- É seguro rodar mesmo que algumas dessas colunas já existam —
-- o "IF NOT EXISTS" faz o banco simplesmente ignorar a linha que
-- já foi aplicada antes, sem dar erro.
--
-- Se o seu MySQL/MariaDB for muito antigo e não aceitar
-- "IF NOT EXISTS" aqui (erro de sintaxe logo na 1ª linha), me avise
-- que eu te mando uma versão sem isso — só que aí você teria que
-- rodar coluna por coluna, ignorando manualmente as que já existem.
-- ==========================================================

ALTER TABLE conversas ADD COLUMN IF NOT EXISTS atualizado_em VARCHAR(19);

ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS lido_em VARCHAR(19);
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS apagado_em VARCHAR(19);
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS resposta_a_id INT NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS fixado TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS fixado_em VARCHAR(19) NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS editado TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS editado_em VARCHAR(19) NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS anexo_nome VARCHAR(255) NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS anexo_caminho VARCHAR(500) NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS anexo_tipo VARCHAR(120) NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS anexo_tamanho INT NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS encaminhada_de_id INT NULL;

ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS tremer_tela TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS tour_concluido TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS mostrar_ultimo_visto TINYINT(1) NOT NULL DEFAULT 1;

-- Confirma no final quais colunas existem de fato nas duas tabelas
-- principais, pra você comparar visualmente com a lista acima.
SHOW COLUMNS FROM mensagens;
SHOW COLUMNS FROM usuarios;
