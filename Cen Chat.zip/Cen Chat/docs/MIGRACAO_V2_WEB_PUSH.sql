-- ==========================================================
-- CEN-CHAT - MIGRAÇÃO V2
-- Corrige o erro "Unknown column 'usuarios.tremer_tela'"
-- e cria suporte a Web Push, tour guiado e visto por último.
-- Execute no banco cenchat se quiser migrar manualmente.
-- ==========================================================

USE cenchat;

ALTER TABLE usuarios
  ADD COLUMN IF NOT EXISTS tremer_tela TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS tour_concluido TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS mostrar_ultimo_visto TINYINT(1) NOT NULL DEFAULT 1;

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INT NOT NULL AUTO_INCREMENT,
  usuario_id INT NOT NULL,
  endpoint VARCHAR(2048) NOT NULL,
  p256dh VARCHAR(255) NOT NULL,
  auth VARCHAR(255) NOT NULL,
  criado_em VARCHAR(19) NULL,
  atualizado_em VARCHAR(19) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_push_endpoint (endpoint),
  KEY idx_push_usuario (usuario_id),
  CONSTRAINT fk_push_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
