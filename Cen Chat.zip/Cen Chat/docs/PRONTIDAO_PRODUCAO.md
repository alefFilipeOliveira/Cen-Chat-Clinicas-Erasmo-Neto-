# Cen-Chat — Checklist pra uso ativo com muitos usuários simultâneos

Este documento resume o que foi revisado e ajustado no código, e o que
ainda depende de decisões de infraestrutura (fora do código) antes de
colocar o Cen-Chat em uso ativo com uma base grande de usuários (na
casa das centenas de pessoas conectadas ao mesmo tempo).

## ✅ O que já foi corrigido no código

- **Verificação de mensagens não lidas ficou adaptativa.** Antes rodava
  fixo a cada 2 segundos pra todo mundo, o tempo todo — inclusive com a
  aba em segundo plano. Agora o intervalo varia conforme a situação de
  cada pessoa (conversando ativamente, aba parada, aba em segundo
  plano), reduzindo bastante a carga de fundo sem perder a sensação de
  "instantâneo" pra quem está de fato usando. Ver `unreadPollDelay()`
  em `static/js/chat.js`.
- **Limite de espaço em disco pros anexos.** Antes não existia nenhuma
  proteção — hoje o servidor recusa o upload (com aviso claro pro
  usuário) se o espaço livre em disco cair abaixo da reserva mínima
  configurada (`ANEXO_ESPACO_MINIMO_MB` no `.env`, padrão 1GB).
- **Monitoramento de disco pro ADM.** Nova rota `/admin/espaco_disco`
  retorna espaço total, livre, usado e um alerta booleano — dá pra
  plugar num script de monitoramento simples (cron + curl + e-mail,
  por exemplo).

## ⚠️ O que já estava bom e eu tinha avaliado errado

Numa conversa anterior eu disse que não havia índice pensado
especificamente pras consultas mais usadas. Isso estava **errado** —
o projeto já tem uma função (`criar_indices_performance`) que roda
automaticamente e cria índices compostos bem desenhados, incluindo um
específico pra contagem de não lidas
(`idx_mensagens_unread_perf`). Não havia necessidade de mexer nisso.

## 🔧 O que depende da infraestrutura (fora do código)

Isso aqui eu não consigo resolver escrevendo código — depende de
decisões e configuração no servidor/rede da clínica.

### 1. Colocar um proxy reverso na frente (nginx ou IIS)

Hoje o Cen-Chat roda direto no waitress, exposto na porta 5050. Pra
uso ativo com muita gente, o recomendado é colocar um proxy reverso
na frente. Isso resolve **duas coisas ao mesmo tempo**:

- **HTTPS** — o que também destrava a notificação nativa do navegador
  (Chrome bloqueia isso em HTTP puro).
- **Resiliência** — o proxy pode ter timeout/retry configurado, e é
  mais fácil trocar a porta/servidor por trás sem todo mundo perceber.

Exemplo mínimo de configuração com **nginx** (ajustar
`server_name`/certificado conforme o ambiente da clínica):

```nginx
server {
    listen 443 ssl;
    server_name cenchat.clinica.local;

    ssl_certificate     /caminho/para/seu_certificado.crt;
    ssl_certificate_key /caminho/para/sua_chave.key;

    client_max_body_size 25m;  # tem que ser >= ANEXO_MAX_MB do .env

    location / {
        proxy_pass http://127.0.0.1:5050;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
    }
}

server {
    listen 80;
    server_name cenchat.clinica.local;
    return 301 https://$host$request_uri;
}
```

Numa rede interna sem CA pública, um certificado autoassinado ou uma
CA interna já resolve — o navegador vai pedir uma confirmação na
primeira vez, mas destrava a Notification API normalmente depois.

### 2. Rodar um teste de carga antes do dia real

Veja `docs/teste_carga.py` — um script pronto usando
[Locust](https://locust.io/) simulando o comportamento real de um
usuário (login, checagem de não lidas, abrir conversa, enviar
mensagem). Rode isso num ambiente de teste/homologação, nunca direto
em produção com dados reais.

Instalação e execução:

```bash
pip install locust
locust -f docs/teste_carga.py --host http://ENDERECO-DO-SERVIDOR:5050
```

Depois abra `http://localhost:8089` no navegador, configure quantos
usuários simulados quer (ex: 400) e o ritmo de entrada, e acompanhe o
tempo de resposta e taxa de erro em tempo real.

### 3. Política de retenção de anexos

O limite de espaço em disco agora impede que o servidor trave por
falta de espaço, mas não apaga nada sozinho. Vale decidir com a
clínica: anexos antigos (ex: mais de 1 ano) devem ser arquivados ou
apagados? Isso hoje é uma decisão manual/operacional, não uma
funcionalidade automática do sistema.

### 4. LDAP em horário de pico

Se o login usa LDAP/Active Directory, vale confirmar com o time de
TI/infra que o servidor de LDAP aguenta um pico de autenticações no
início do expediente (muita gente logando ao mesmo tempo é comum
gerar lentidão momentânea, mas isso é responsabilidade do servidor de
diretório, não deste aplicativo).

## Resumo

Com os ajustes de código já feitos, o Cen-Chat está tecnicamente mais
preparado para uma carga maior de usuários. Os itens de infraestrutura
acima (proxy reverso/HTTPS e teste de carga, principalmente) são o que
eu recomendo resolver antes de anunciar uso ativo para todos.
