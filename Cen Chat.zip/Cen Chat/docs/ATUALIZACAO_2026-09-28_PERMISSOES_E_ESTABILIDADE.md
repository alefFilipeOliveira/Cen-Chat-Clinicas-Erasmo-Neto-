# Cen-Chat — Atualização 2026-09-28

## Permissões
- Administradores por `perfil=adm` têm comunicação global e não ficam presos à matriz setorial.
- Removida a exceção específica de Valdirene; a regra agora é administrativa e consistente.
- Usuários comuns veem somente os setores que possuem pelo menos um contato permitido pela matriz.
- A mesma proteção é aplicada no backend a abertura de conversa, notificações e envio em massa.

## Setores
- Mantidos os 15 setores de trabalho: Adm Nacen, Almoxarifado, Apoio, Conferência, Faturamento, Financeiro, Jurídico, Marcação, Profissionais, Recepção, Recepção Nacen, Recepção Nacen+, RH, Secretarias e TI.
- `Sem setor` continua sendo estado de usuário, não pasta de conversa.
- Removida a exibição do contador/bolinha de não lidas no cabeçalho dos setores.
- Contagem de mensagens continua ao lado do usuário.

## Correções técnicas
- Corrigido `api_conversas_preview`: faltava `u.setor_id` no SELECT, mas o código tentava ler `row["setor_id"]`, podendo gerar erro 500 e deixar cards em carregamento.
- Erro de bloqueio de conversa deixou de mencionar uma regra antiga fixa de Profissionais e passou a usar a mensagem genérica da matriz ADM.
- Adicionado diagnóstico autenticado em `/api/diagnostico`.
- O instalador foi simplificado para somente `instalar.bat` e `inicia.bat`; os testes operacionais do WebSocket foram integrados ao diagnóstico da aplicação.
- Waitress fixado em 3.0.2, com instalador preferindo Python 3.13/3.12.

## Validação realizada
- Compilação estática de Python com `py_compile` e checagens de estrutura.
- Verificação sintática do JavaScript com `node --check`.
- Integridade do pacote ZIP.
- Neste ambiente foi possível validar sintaxe e o protocolo WebSocket de forma isolada, mas não foi possível iniciar MariaDB/LDAP nem executar o cenário Windows/Firewall da clínica. A validação final de rede deve ser feita no servidor da clínica.
