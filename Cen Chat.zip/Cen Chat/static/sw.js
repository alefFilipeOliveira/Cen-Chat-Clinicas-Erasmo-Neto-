/* Cen-Chat Web Push Service Worker
   Este arquivo precisa ser servido em /service-worker.js para ter escopo no sistema inteiro. */

self.addEventListener("install", event => {
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("push", event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; }
  catch(e) {
    data = {title:"Cen-Chat", body:event.data ? event.data.text() : "Nova mensagem"};
  }

  const title = data.title || "Cen-Chat · Nova mensagem";
  const options = {
    body: data.body || "Você recebeu uma nova mensagem.",
    icon: "/static/img/favicon.png",
    badge: "/static/img/favicon.png",
    tag: data.tag || "cen-chat-message",
    renotify: true,
    requireInteraction: false,
    data: data.data || {}
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", event => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || "/chat";
  event.waitUntil((async()=>{
    const clientList = await clients.matchAll({type:"window", includeUncontrolled:true});
    for(const client of clientList){
      try{
        const target = new URL(targetUrl, self.location.origin);
        const current = new URL(client.url);
        if(current.origin === target.origin){
          await client.focus();
          client.navigate(target.href);
          return;
        }
      }catch(e){}
    }
    await clients.openWindow(targetUrl);
  })());
});
