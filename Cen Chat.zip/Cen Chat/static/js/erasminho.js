/* Erasminho — rebuilt from scratch.
 * Uses the current Puter.js browser API directly.
 * No duplicate event bindings, no dynamic script injection, no fake AI success.
 */
(() => {
  'use strict';

  const READY_EVENT = 'erasminho-ready';
  const STATUS_EVENT = 'erasminho-status';
  const MODEL = 'gpt-5-nano';
  const AUTH_TIMEOUT_MS = 20000;
  const AI_TIMEOUT_MS = 35000;

  function boot() {
    const widget = document.getElementById('erasmoWidget');
    const toggle = document.getElementById('erasmoToggleBtn');
    const panel = document.getElementById('erasmoPanel');
    const close = document.getElementById('erasmoCloseBtn');
    const guide = document.getElementById('erasmoGuide');
    const guideOpen = document.getElementById('erasmoGuideOpenBtn');
    const guideClose = document.getElementById('erasmoGuideClose');
    const guideStart = document.getElementById('erasmoGuideStart');
    const guideBackdrop = guide?.querySelector('.erasmo-guide-backdrop');
    const connectionStatus = document.getElementById('erasmoConnectionStatus');
    const compose = document.getElementById('erasminhoCompose');
    const input = document.getElementById('erasminhoInput');
    const send = document.getElementById('erasminhoSendBtn');
    const body = document.getElementById('erasmoBody');

    if (!widget || !toggle || !panel || !compose || !input || !body) return false;
    if (widget.dataset.erasminhoBound === '1') return true;
    widget.dataset.erasminhoBound = '1';

    const kb = String(window.ERASMINHO_KB || '').trim();
    const conversation = [];
    let busy = false;

    const systemPrompt = [
      'Você é o Erasminho, assistente oficial de IA do Cen-Chat.',
      'Responda em português do Brasil, de forma natural, clara e útil.',
      'Ajude com o funcionamento do Cen-Chat, chat, setores, LDAP/AD, administração e dúvidas sobre a plataforma.',
      'Use a base autorizada abaixo quando ela trouxer informações específicas da clínica.',
      'Não invente procedimentos, regras ou informações internas.',
      'Quando a base não contiver a resposta, diga isso claramente e recomende confirmar com o setor responsável.',
      'Você não executa ações no sistema e nunca deve fingir que alterou usuários, setores, mensagens ou configurações.',
      '',
      'BASE AUTORIZADA:',
      kb || '(nenhuma base adicional fornecida)'
    ].join('\n');

    function emitStatus(status, detail = '') {
      window.dispatchEvent(new CustomEvent(STATUS_EVENT, { detail: { status, detail } }));
      widget.dataset.aiStatus = status;
      if (connectionStatus) {
        const labels = {
          offline: 'IA indisponível',
          connecting: 'Conectando...',
          authenticating: 'Autorizando...',
          streaming: 'Respondendo...',
          thinking: 'Pensando...',
          ready: 'IA pronta',
          error: 'Erro de conexão'
        };
        connectionStatus.textContent = detail ? `${labels[status] || status} · ${detail}` : (labels[status] || status);
      }
    }

    function open() {
      widget.classList.add('open');
      toggle.setAttribute('aria-expanded', 'true');
      panel.setAttribute('aria-hidden', 'false');
      if (!body.childElementCount) {
        appendMessage('Oi! Eu sou o Erasminho 🤖. Pode mandar sua dúvida.', 'ai');
      }
      setTimeout(() => input.focus(), 30);
    }

    function closePanel() {
      widget.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      panel.setAttribute('aria-hidden', 'true');
    }

    function openGuide() {
      if (!guide) return;
      guide.classList.add('open');
      guide.setAttribute('aria-hidden', 'false');
    }

    function closeGuide() {
      if (!guide) return;
      guide.classList.remove('open');
      guide.setAttribute('aria-hidden', 'true');
    }

    function appendMessage(text, role) {
      const row = document.createElement('div');
      row.className = `erasmo-msg-row ${role === 'user' ? 'is-user' : 'is-ai'}`;
      const bubble = document.createElement('div');
      bubble.className = `erasmo-msg ${role === 'user' ? 'erasmo-msg-user' : 'erasmo-msg-ia'}`;
      bubble.textContent = String(text ?? '');
      row.appendChild(bubble);
      body.appendChild(row);
      body.scrollTop = body.scrollHeight;
      return { row, bubble };
    }

    function setBusy(value) {
      busy = Boolean(value);
      input.disabled = busy;
      if (send) send.disabled = busy;
      widget.classList.toggle('busy', busy);
      emitStatus(busy ? 'thinking' : 'ready');
    }

    function ensurePuter() {
      return Boolean(window.puter?.ai?.chat);
    }

    async function ensurePuterAuth() {
      if (!window.puter?.auth) {
        throw new Error('A autenticação do Erasminho não carregou neste navegador.');
      }

      try {
        if (window.puter.auth.isSignedIn()) return true;
      } catch (_) {}

      emitStatus('authenticating');
      const authPromise = (typeof window.puter.auth.signIn === 'function')
        ? window.puter.auth.signIn({ attempt_temp_user_creation: true })
        : (typeof window.puter.ui?.authenticateWithPuter === 'function'
            ? window.puter.ui.authenticateWithPuter()
            : Promise.reject(new Error('Este navegador não oferece a autenticação do Erasminho.')));

      await Promise.race([
        authPromise,
        new Promise((_, reject) => setTimeout(() => reject(new Error('A autorização do Erasminho demorou demais. Verifique se o navegador bloqueou a janela de autorização.')), AUTH_TIMEOUT_MS))
      ]);

      try {
        if (window.puter.auth.isSignedIn()) return true;
      } catch (_) {}
      return true;
    }

    function extractText(part) {
      if (!part) return '';
      if (typeof part === 'string') return part;
      if (typeof part.text === 'string') return part.text;
      if (typeof part.delta?.text === 'string') return part.delta.text;
      if (typeof part.message?.content === 'string') return part.message.content;
      if (Array.isArray(part.message?.content)) {
        return part.message.content.filter(x => x?.type === 'text').map(x => x.text || '').join('');
      }
      if (typeof part.content === 'string') return part.content;
      if (Array.isArray(part.content)) {
        return part.content.filter(x => x?.type === 'text').map(x => x.text || '').join('');
      }
      return '';
    }

    async function completeWithPuter(messages, bubble) {
      if (!ensurePuter()) {
        throw new Error('Puter.js não está disponível no navegador.');
      }

      await ensurePuterAuth();
      emitStatus('connecting');

      // Evitamos stream:true aqui porque versões recentes do Puter.js podem
      // ficar penduradas indefinidamente quando há um erro no provedor.
      // A resposta normal é mais previsível na rede da clínica.
      const request = window.puter.ai.chat(messages, {
        model: MODEL,
        temperature: 0.35
      });
      const response = await Promise.race([
        request,
        new Promise((_, reject) => setTimeout(() => reject(new Error('A IA demorou mais de 35 segundos para responder.')), AI_TIMEOUT_MS))
      ]);

      emitStatus('ready');
      const accumulated = extractText(response);
      bubble.textContent = accumulated;

      if (!accumulated.trim()) {
        throw new Error('A IA conectou, mas não retornou texto.');
      }
      return accumulated.trim();
    }

    function addRetry(row, question, authError = false) {
      if (row.querySelector('.erasmo-retry')) return;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'erasmo-retry';
      button.textContent = authError ? '🔐 Conectar Erasminho' : '↻ Tentar novamente';
      button.addEventListener('click', () => {
        button.remove();
        ask(question, true);
      }, { once: true });
      row.appendChild(button);
    }

    async function ask(question, silentUser = false) {
      const q = String(question || '').trim();
      if (!q || busy) return;

      if (!silentUser) appendMessage(q, 'user');
      input.value = '';
      setBusy(true);
      emitStatus('connecting');

      const answer = appendMessage('', 'ai');
      answer.bubble.classList.add('erasmo-streaming');

      const messages = [
        { role: 'system', content: systemPrompt },
        ...conversation.slice(-12),
        { role: 'user', content: q }
      ];

      try {
        const text = await completeWithPuter(messages, answer.bubble);
        conversation.push(
          { role: 'user', content: q },
          { role: 'assistant', content: text }
        );
      } catch (error) {
        console.error('[Erasminho]', error);
        const message = error?.message || 'Erro desconhecido.';
        const authError = /auth|autoriz|token|popup|login|sess[aã]o/i.test(message);
        emitStatus('error', message);
        answer.bubble.textContent = authError
          ? `O Erasminho precisa autorizar este navegador uma única vez.\n\n${message}`
          : `Não consegui falar com a IA agora.\n\n${message}`;
        addRetry(answer.row, q, authError);
      } finally {
        answer.bubble.classList.remove('erasmo-streaming');
        setBusy(false);
        input.focus();
        body.scrollTop = body.scrollHeight;
      }
    }

    toggle.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      widget.classList.contains('open') ? closePanel() : open();
    });

    close?.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      closePanel();
    });

    guideOpen?.addEventListener('click', event => {
      event.preventDefault();
      openGuide();
    });
    guideClose?.addEventListener('click', closeGuide);
    guideBackdrop?.addEventListener('click', closeGuide);
    guideStart?.addEventListener('click', () => {
      closeGuide();
      open();
    });

    compose.addEventListener('submit', event => {
      event.preventDefault();
      if (!busy) ask(input.value);
    });

    input.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        compose.requestSubmit();
      }
    });

    window.CEN_ERASMINHO = {
      open,
      close: closePanel,
      ask,
      clear() {
        conversation.length = 0;
        body.innerHTML = '';
        appendMessage('Conversa limpa. Pode mandar outra dúvida.', 'ai');
      },
      status() {
        return {
          puterLoaded: Boolean(window.puter?.ai?.chat),
          puterSignedIn: (() => { try { return Boolean(window.puter?.auth?.isSignedIn?.()); } catch (_) { return false; } })(),
          model: MODEL,
          busy,
          messages: conversation.length
        };
      }
    };

    emitStatus(ensurePuter() ? 'ready' : 'offline', ensurePuter() ? '' : 'Puter.js ainda não carregou.');
    window.dispatchEvent(new CustomEvent(READY_EVENT));
    return true;
  }

  function start() {
    if (boot()) return;
    let attempts = 0;
    const timer = setInterval(() => {
      if (boot() || ++attempts >= 100) clearInterval(timer);
    }, 100);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
