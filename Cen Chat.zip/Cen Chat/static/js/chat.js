
(function normalizeOldTheme(){
  const map = {
    "azul-clarinho":"oceano",
    "gelo-clinico":"laranja-claro",
    "branco-simples":"laranja-claro",
    "roxo-borboleta":"aurora",
    "lavanda":"laranja-claro",
    "ruby":"vermelho-normal",
    "areia":"laranja-claro"
  };
  const saved = localStorage.getItem("cen-chat-theme");
  if(saved && map[saved]){
    localStorage.setItem("cen-chat-theme", map[saved]);
  }
})();


const MAX_POPUPS = 4;

const EMOJI_CATEGORIES = {
  recentes: {label:"Recentes", icon:"🕘", emojis:[]},
  rostos: {label:"Rostos", icon:"😊", emojis:["😀","😃","😄","😁","😆","😅","😂","🤣","😊","😇","🙂","🙃","😉","😌","😍","🥰","😘","😗","😙","😚","😋","😛","😝","😜","🤪","🤨","🧐","🤓","😎","🤩","🥳","😏","😒","😞","😔","😟","😕","🙁","☹️","😣","😖","😫","😩","🥺","😢","😭","😤","😠","😡","🤬","🤯","😳","🥵","🥶","😱","😨","😰","😥","😓","🤗","🤔","🤭","🤫","🤥","😶","😐","😑","😬","🙄","😯","😦","😧","😮","😲","🥱","😴"]},
  gestos: {label:"Gestos", icon:"👍", emojis:["👋","🤚","🖐️","✋","👌","🤌","🤏","✌️","🤞","🤟","🤘","🤙","👈","👉","👆","👇","☝️","👍","👎","✊","👊","🤛","🤜","👏","🙌","👐","🙏","💪","🫶"]},
  coracoes: {label:"Corações", icon:"❤️", emojis:["❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝"]},
  comida: {label:"Comida", icon:"🍔", emojis:["☕","🍵","🥤","🧃","🍎","🍌","🍇","🍓","🍍","🥭","🍞","🥐","🥨","🧀","🍳","🥞","🍔","🍟","🍕","🌭","🥪","🌮","🌯","🥗","🍝","🍜","🍲","🍛","🍣","🍱","🍰","🧁","🍫","🍬","🍭"]},
  objetos: {label:"Objetos", icon:"📌", emojis:["💬","💭","📌","📍","📎","📝","📄","📋","📅","⏰","🔔","📣","📢","📞","📱","💻","🖥️","⌨️","🖱️","🖨️","🔒","🔑","🛡️","⚙️","🔧","🔨","🧰","💡","🔍","📦","🗂️","🗃️"]},
  clinica: {label:"Clínica", icon:"🏥", emojis:["🏥","🚑","🩺","💊","🧪","🧬","🦠","🧼","🧴","🩹","🌡️","🫀","🫁","🦷","👨‍⚕️","👩‍⚕️","😷","🤒","🤕"]},
  eventos: {label:"Eventos", icon:"🎉", emojis:["✅","☑️","✔️","❌","⚠️","🚫","❗","❓","💯","🔥","✨","⭐","🌟","🎉","🎊","🎈","🎁","🏆","🥇","🥈","🥉","🚀","⚡","🌈","☀️","🌙"]}
};

const dock = document.querySelector("#chatDock");
const dockSecondary = document.querySelector("#chatDockSecondary");
// Alterna os popups entre o dock principal (esquerda) e o secundário
// (direita), deixando o mais recente sempre no principal e distribuindo
// os demais pra não empilhar tudo do mesmo lado.
function escolherDock(){
  const secundarioVisivel = !!(dockSecondary && dockSecondary.offsetParent !== null);
  if(!secundarioVisivel) return dock;
  const principal = dock?.children.length || 0;
  const secundario = dockSecondary?.children.length || 0;
  return principal <= secundario ? dock : dockSecondary;
}
const openPopups = new Map();
const popupReplyState = new Map();
const messageCache = new Map();
const typingCache = new Map();
let unreadTotal = 0;
let lastUnreadSignature = "";
// Marca a última atividade da pessoa para ajustar o intervalo de atualização
// de mensagens não lidas sem manter consultas rápidas quando a tela está parada.
let lastActivityTs = Date.now();
const RECENT_CONVERSATIONS_KEY = "cen-chat-recent-conversations";
// Marca se essa lista já foi preenchida alguma vez neste navegador — sem
// isso, toda vez que a pessoa limpava as conversas recentes de propósito,
// a próxima atualização do dashboard enchia tudo de novo sozinha, porque
// não tinha como diferenciar "nunca teve nada" de "acabou de limpar".
const RECENT_CONVERSATIONS_SEEDED_KEY = "cen-chat-recent-conversations-seeded";
let browserAlertsEnabled = false;
let lastDesktopNotificationSignature = "";
let unreadFocusEnabled = false;
let previewCache = [];
let dashboardBusy = false;

// Atualiza a atividade sem deixar cada movimento do mouse virar trabalho no JS.
let lastActivityEventTs = 0;
function markUserActivity(){
  const nowTs = Date.now();
  if(nowTs - lastActivityEventTs < 1000) return;
  lastActivityEventTs = nowTs;
  lastActivityTs = nowTs;
}
document.addEventListener("pointerdown", markUserActivity, {passive:true});
document.addEventListener("keydown", markUserActivity, {passive:true});
document.addEventListener("touchstart", markUserActivity, {passive:true});

// ==========================================================
// TEMPO REAL — WebSocket nativo
// ==========================================================
let cenRealtimeSocket = null;
let cenRealtimeConnected = false;
let cenRealtimeRetry = 0;
let cenRealtimeRetryTimer = null;

function setRealtimeIndicator(status){
  const candidates = document.querySelectorAll('[data-realtime-status], #realtimeStatus, .realtime-status');
  candidates.forEach(el=>{
    if(status === 'connected'){ el.textContent = '⚡ Tempo real ativo'; el.classList.add('connected'); el.classList.remove('connecting','offline'); }
    else if(status === 'connecting'){ el.textContent = '↻ Conectando tempo real…'; el.classList.add('connecting'); el.classList.remove('connected','offline'); }
    else { el.textContent = '○ Tempo real indisponível — reconectando…'; el.classList.add('offline'); el.classList.remove('connected','connecting'); }
  });
}

function realtimeUrl(token, porta, rota){
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const path = (rota || '/ws').startsWith('/') ? (rota || '/ws') : `/${rota}`;
  return `${proto}//${location.hostname}:${porta}${path}?token=${encodeURIComponent(token)}`;
}

function replaceOptimisticWithMessage(popup, optimistic, message){
  if(!popup || !message) return;
  optimistic?.remove();
  appendRealtimeMessage(popup, message, true);
}

function appendRealtimeMessage(popup, m, stick=true){
  if(!popup || !m) return;
  const body=popup.querySelector('.popup-body');
  if(!body) return;
  const id=String(m.id||'');
  if(id && body.querySelector(`.msg[data-msg-id="${id}"]`)) return;
  const mine=Number(m.remetente_id)===Number(window.CEN_USER.id);
  const div=document.createElement('div');
  const texto=m.texto||'';
  const bigEmoji=isOnlyEmoji(texto) && !m.anexo;
  div.className='msg'+(mine?' mine':'')+(bigEmoji?' emoji-only':'')+(m.fixado?' is-pinned':'');
  if(id) div.dataset.msgId=id;
  div.dataset.fullTime=formatFullDateTime(m.enviado_em);
  const hora=formatTime(m.enviado_em);
  const editedLabel=(m.editado && !m.apagado)?' <small class="edited-mark">(editado)</small>':'';
  const readMark=mine?`<small class="delivery-mark${m.lido?' read':''}">✓✓</small>`:'';
  const pinLabel=m.fixado?'Desfixar':'Fixar';
  const pinBadge=m.fixado?'<span class="pin-badge" title="Mensagem fixada">📌</span>':'';
  const forwardBadge=m.encaminhada_de?`<div class="forwarded-tag">↪ Encaminhada de ${escapeHtml(m.encaminhada_de)}</div>`:'';
  const replyBlock=m.resposta_a?`<button type="button" class="msg-reply-quote" data-scroll-to="${m.resposta_a.id}"><strong>${escapeHtml(m.resposta_a.remetente_id===window.CEN_USER.id?'Você':m.resposta_a.remetente_nome)}</strong><span>${escapeHtml(m.resposta_a.texto)}</span></button>`:'';
  const anexoBlock=renderAnexoBlock(m.anexo);
  const reacoesBlock=renderReacoesBlock(m.reacoes||[], m.id);
  const podeEditar=mine&&!m.apagado&&!m.anexo;
  const podeEncaminhar=!m.apagado;
  const menuItems=mine
    ? `<button type="button" data-reply="${m.id}">Responder</button><button type="button" data-react="${m.id}">Reagir</button>${podeEncaminhar?`<button type="button" data-forward="${m.id}">Encaminhar</button>`:''}<button type="button" data-copy="${m.id}">Copiar</button><button type="button" data-pin="${m.id}">${pinLabel}</button>${podeEditar?`<button type="button" data-edit="${m.id}">Editar</button>`:''}<button type="button" data-del-self="${m.id}">Apagar para mim</button><button type="button" data-del-all="${m.id}">Apagar para todos</button>`
    : `<button type="button" data-reply="${m.id}">Responder</button><button type="button" data-react="${m.id}">Reagir</button>${podeEncaminhar?`<button type="button" data-forward="${m.id}">Encaminhar</button>`:''}<button type="button" data-copy="${m.id}">Copiar</button><button type="button" data-pin="${m.id}">${pinLabel}</button>`;
  const menu=`<div class="msg-actions"><button class="msg-menu-btn" type="button">⋮</button><div class="msg-menu">${menuItems}</div></div>`;
  const apagada=m.apagado;
  div.innerHTML=`${forwardBadge}${replyBlock}${anexoBlock}<div class="msg-text">${pinBadge}${escapeHtml(texto)}</div><span class="msg-time">${escapeHtml(hora)}${editedLabel} ${apagada?'':readMark}</span>${reacoesBlock}${menu}`;
  body.appendChild(div);
  bindMessageMenus(body,popup,Number(m.conversa_id));
  popup.dataset.lastMsgId=id || popup.dataset.lastMsgId || '0';
  if(stick) body.scrollTop=body.scrollHeight;
}

function updateMessageReadState(conversaId, ids){
  const popup=[...openPopups.values()].find(p=>String(p.dataset.conversaId)===String(conversaId));
  if(!popup) return;
  const wanted=new Set((ids||[]).map(String));
  popup.querySelectorAll('.msg.mine[data-msg-id]').forEach(el=>{
    if(!wanted.size || wanted.has(String(el.dataset.msgId))){
      const mark=el.querySelector('.delivery-mark');
      if(mark){ mark.textContent='✓✓'; mark.classList.add('read'); }
    }
  });
}

async function resyncOpenPopupsAfterRealtimeConnect(){
  // Se o WebSocket caiu por alguns segundos, mensagens podem ter chegado
  // durante a reconexão. O banco continua sendo a fonte de verdade.
  const popups=[...openPopups.values()];
  for(const popup of popups){
    if(!popup?.dataset?.conversaId) continue;
    const conversaId=Number(popup.dataset.conversaId);
    messageCache.delete(String(conversaId));
    await loadMessages(popup, conversaId, false).catch(()=>{});
  }
  refreshUnread(true);
  scheduleDashboardSync();
}

function handleRealtimeEvent(ev){
  const type=ev?.type;
  if(type==='connected'){
    cenRealtimeConnected=true;
    cenRealtimeRetry=0;
    setRealtimeIndicator('connected');
    resyncOpenPopupsAfterRealtimeConnect();
    return;
  }
  if(type==='message.new'){
    const m=ev.message;
    if(!m) return;
    const popup=[...openPopups.values()].find(p=>String(p.dataset.conversaId)===String(m.conversa_id));
    if(popup){
      // A resposta HTTP e o evento WebSocket podem chegar em ordem diferente.
      // Se a mensagem é nossa e ainda existe uma bolha otimista, substituímos
      // essa bolha diretamente para não duplicar a mensagem.
      const minha = Number(m.remetente_id)===Number(window.CEN_USER.id);
      const optimistic = minha ? popup.querySelector('.msg.optimistic') : null;
      if(optimistic){
        replaceOptimisticWithMessage(popup, optimistic, m);
      } else {
        // Mesmo minimizado, o popup recebe a mensagem. Apenas evitamos
        // rolar automaticamente quando ele não está visível.
        appendRealtimeMessage(popup,m,!popup.classList.contains('minimized'));
      }
      if(!popup.classList.contains('minimized')){
        markConversationSeen(m.conversa_id, Number(m.id||0));
        fetch(`/api/marcar_lida/${m.conversa_id}`,{method:'POST'}).catch(()=>{});
      }
    }
    refreshUnread(true);
    scheduleDashboardSync();
    return;
  }
  if(type==='message.read'){
    updateMessageReadState(ev.conversa_id, ev.message_ids||[]); return;
  }
  if(type==='message.edited'){
    const popup=[...openPopups.values()].find(p=>String(p.dataset.conversaId)===String(ev.conversa_id));
    const el=popup?.querySelector(`.msg[data-msg-id="${ev.id}"]`);
    if(el){ const text=el.querySelector('.msg-text'); if(text) text.innerHTML=escapeHtml(ev.texto||''); let time=el.querySelector('.msg-time'); if(time && !time.innerHTML.includes('(editado)')) time.innerHTML+= ' <small class="edited-mark">(editado)</small>'; }
    return;
  }
  if(type==='message.deleted'){
    const popup=[...openPopups.values()].find(p=>String(p.dataset.conversaId)===String(ev.conversa_id));
    const el=popup?.querySelector(`.msg[data-msg-id="${ev.id}"]`);
    if(el){ const text=el.querySelector('.msg-text'); if(text) text.textContent='Mensagem apagada'; el.classList.add('is-deleted'); el.querySelectorAll('.msg-actions').forEach(x=>x.remove()); }
    refreshUnread(false); return;
  }
  if(type==='typing'){
    const popup=[...openPopups.values()].find(p=>String(p.dataset.conversaId)===String(ev.conversa_id));
    const line=popup?.querySelector('.typing-line');
    if(line){ line.innerHTML=ev.ativo?'<div class="typing-bubble"><span></span><span></span><span></span></div>':''; }
    return;
  }
  if(type==='presence'){ refreshSidebarStatuses(); refreshDashboardRealtime(); return; }
}

function sanitizeRealtimeUrl(raw){
  try{
    const u=new URL(raw, location.href);
    u.search='';
    return u.toString();
  }catch(_){ return '<url indisponível>'; }
}

async function connectRealtime(){
  if(!window.CEN_USER?.id || typeof WebSocket==='undefined') return;
  if(cenRealtimeSocket && (cenRealtimeSocket.readyState===WebSocket.OPEN || cenRealtimeSocket.readyState===WebSocket.CONNECTING)) return;
  clearTimeout(cenRealtimeRetryTimer);
  setRealtimeIndicator('connecting');
  try{
    const res=await fetch('/api/ws/token',{cache:'no-store',credentials:'same-origin',headers:{'Cache-Control':'no-cache'}});
    const contentType=res.headers.get('content-type')||'';
    if(!contentType.toLowerCase().includes('application/json')){
      if(res.redirected || res.status===401 || res.status===403){
        window.location.href='/login';
        return;
      }
      throw new Error(`Resposta inválida do servidor (${res.status})`);
    }
    const data=await res.json();
    if(!res.ok || !data.ok) throw new Error(data?.erro || 'Não foi possível obter token WebSocket');
    const ws=new WebSocket(realtimeUrl(data.token,data.porta,data.rota));
    cenRealtimeSocket=ws;
    ws.onopen=()=>{
      setRealtimeIndicator('connecting');
      try{ws.send(JSON.stringify({type:'hello'}));}catch(e){}
      clearInterval(connectRealtime._heartbeat);
      connectRealtime._heartbeat=setInterval(()=>{
        if(ws.readyState===WebSocket.OPEN){ try{ ws.send(JSON.stringify({type:'ping',client_time:Date.now()})); }catch(e){} }
      },15000);
    };
    ws.onmessage=(event)=>{
      try{ handleRealtimeEvent(JSON.parse(event.data)); }catch(e){ console.warn('Evento WebSocket inválido',e); }
    };
    ws.onerror=(err)=>{
      console.warn('Cen-Chat WebSocket: falha de conexão', {url:sanitizeRealtimeUrl(ws.url),error:err});
    };
    ws.onclose=(event)=>{
      clearInterval(connectRealtime._heartbeat);
      cenRealtimeConnected=false;
      if(cenRealtimeSocket===ws) cenRealtimeSocket=null;
      setRealtimeIndicator('offline');
      const delay=Math.min(15000, Math.max(1000, 1000*Math.pow(2, Math.min(cenRealtimeRetry, 4))));
      cenRealtimeRetry=Math.min(cenRealtimeRetry+1,10);
      cenRealtimeRetryTimer=setTimeout(connectRealtime, delay);
      if(event?.code && event.code!==1000) console.warn('Cen-Chat WebSocket encerrado', {code:event.code,reason:event.reason||''});
    };
  }catch(err){
    cenRealtimeConnected=false; setRealtimeIndicator('offline');
    cenRealtimeRetry=Math.min(cenRealtimeRetry+1,10);
    cenRealtimeRetryTimer=setTimeout(connectRealtime, Math.min(10000,800+cenRealtimeRetry*500));
  }
}

window.CEN_REALTIME={connect:connectRealtime,isConnected:()=>cenRealtimeConnected};
// Inicia o canal WebSocket assim que o módulo carrega.
// Sem esta chamada, o indicador ficava eternamente em “Conectando tempo real”.
connectRealtime();
window.addEventListener('online',()=>{ clearTimeout(cenRealtimeRetryTimer); cenRealtimeRetry=0; connectRealtime(); });
document.addEventListener('visibilitychange',()=>{ if(document.visibilityState==='visible' && !cenRealtimeConnected){ connectRealtime(); } });


function getRecentConversations(){
  try{
    const items = JSON.parse(localStorage.getItem(RECENT_CONVERSATIONS_KEY) || "[]");
    return Array.isArray(items) ? items : [];
  }catch(e){ return []; }
}
function saveRecentConversations(items){
  localStorage.setItem(RECENT_CONVERSATIONS_KEY, JSON.stringify((items || []).slice(0, 12)));
  localStorage.setItem(RECENT_CONVERSATIONS_SEEDED_KEY, "1");
}
function removeRecentConversation(id){ saveRecentConversations(getRecentConversations().filter(item => String(item.id) !== String(id))); renderRecentConversations(); }
function clearAllRecentConversations(){ saveRecentConversations([]); renderRecentConversations(); }
function addRecentConversation(item){
  if(!item || !item.id) return;
  const list = getRecentConversations().filter(entry => String(entry.id) !== String(item.id));
  list.unshift({ id:item.id, conversa_id:item.conversa_id || null, name:item.name || item.nome || "Usuário", setor:item.setor || item.setor_nome || "Sem setor", status:item.status || "online", ts:Date.now() });
  saveRecentConversations(list);
  renderRecentConversations();
}
function formatRecentTime(ts){ try{return new Date(ts).toLocaleTimeString("pt-BR", {hour:"2-digit", minute:"2-digit"});}catch(e){return "agora";} }
function renderRecentConversations(){
  const wrap = document.querySelector("#recentChatsList");
  if(!wrap) return;
  const items0 = getRecentConversations();
  const signature = items0.map(i=>`${i.id}:${i.ts}`).join(',');
  fadeSwapList(wrap, signature, ()=>{
    const items = getRecentConversations();
    wrap.innerHTML = "";
    if(!items.length){ wrap.innerHTML = '<div class="recent-empty">Nenhuma conversa recente por enquanto.</div>'; return; }
    items.forEach(item => {
      const row = document.createElement("article");
      row.className = "recent-chat-item";
      row.innerHTML = `
        <button type="button" class="recent-chat-open" data-open-recent="${item.id}">
          <span class="recent-avatar" style="--avatar-hue:${hueFromId(item.id)}">${escapeHtml(getInitials(item.name))}</span>
          <span class="recent-main"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.setor)} • ${formatRecentTime(item.ts)}</small></span>
        </button>
        <button type="button" class="recent-remove" data-remove-recent="${item.id}" title="Remover da lista">×</button>`;
      wrap.appendChild(row);
    });
    wrap.querySelectorAll('[data-open-recent]').forEach(btn=>{btn.onclick = ()=>{ const item = getRecentConversations().find(entry => String(entry.id) === String(btn.dataset.openRecent)); if(item) openConversation(item.id, item.name, item.conversa_id || null); };});
    wrap.querySelectorAll('[data-remove-recent]').forEach(btn=>{btn.onclick = (ev)=>{ ev.stopPropagation(); removeRecentConversation(btn.dataset.removeRecent); };});
  });
}
function setConnectionStatusTimestamp(){
  const el = document.querySelector('#connectionStatusTime');
  if(!el) return;
  const now = new Date();
  el.textContent = `Atualizado às ${now.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'})}`;
}
function updateBrowserAlertsButton(){
  const btn = document.querySelector('#browserAlertsBtn');
  if(!btn) return;
  if(!("Notification" in window)){ btn.textContent = 'Alertas não suportados neste navegador'; btn.disabled = true; return; }
  if(Notification.permission === 'granted'){
    browserAlertsEnabled = true; btn.textContent = 'Alertas de novas mensagens ativados'; btn.classList.add('active');
  }else if(Notification.permission === 'denied'){
    browserAlertsEnabled = false; btn.textContent = 'Alertas bloqueados no navegador'; btn.classList.remove('active');
  }else{
    browserAlertsEnabled = false; btn.textContent = 'Ativar alertas de novas mensagens'; btn.classList.remove('active');
  }
}
async function requestBrowserAlerts(){
  if(!("Notification" in window)) return;
  const result = await Notification.requestPermission();
  browserAlertsEnabled = result === 'granted';
  updateBrowserAlertsButton();
  toast(browserAlertsEnabled ? 'Alertas ativados.' : 'Permissão de alertas não concedida.');
}

function base64UrlToUint8Array(base64String){
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map(ch => ch.charCodeAt(0)));
}

async function setupWebPush(){
  const btn = document.querySelector("#webPushBtn");
  if(!btn || !("serviceWorker" in navigator) || !("PushManager" in window)) {
    if(btn) btn.textContent = "Web Push não suportado neste navegador";
    return;
  }
  try{
    const keyRes = await fetch("/api/push/public-key", {cache:"no-store"});
    const keyData = await keyRes.json();
    if(!keyData.enabled || !keyData.public_key){
      btn.textContent = "Web Push ainda não configurado pelo TI";
      btn.disabled = true;
      return;
    }
    const registration = await navigator.serviceWorker.register("/service-worker.js", {scope:"/"});
    let subscription = await registration.pushManager.getSubscription();

    // Se já havia uma inscrição antiga, recriamos silenciosamente usando
    // a chave pública atual do servidor. Isso resolve trocas de VAPID sem
    // exigir que cada colaborador descubra como remover a inscrição antiga.
    if(subscription){
      try{
        const currentKey = keyData.public_key;
        const browserKey = subscription.options?.applicationServerKey;
        let browserKeyB64 = "";
        if(browserKey){
          const bytes = browserKey instanceof ArrayBuffer ? new Uint8Array(browserKey) : new Uint8Array(browserKey);
          browserKeyB64 = btoa(String.fromCharCode(...bytes)).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");
        }
        if(!browserKeyB64 || browserKeyB64 !== currentKey){
          await subscription.unsubscribe();
          subscription = null;
        }
      }catch(e){
        // Em navegadores que não expõem applicationServerKey, seguimos com a
        // inscrição existente e o backend a atualiza normalmente.
      }
    }

    if(subscription){
      const json = subscription.toJSON();
      await fetch("/api/push/subscribe", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({endpoint:json.endpoint, keys:json.keys})}).catch(()=>{});
      btn.textContent = "🔔 Notificações com navegador fechado: ativadas";
      btn.classList.add("active");
      return;
    }

    btn.textContent = "🔔 Ativar notificações mesmo com o navegador fechado";
    btn.onclick = async()=>{
      try{
        const permission = await Notification.requestPermission();
        if(permission !== "granted"){
          toast("Permissão de notificação não concedida.");
          return;
        }
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly:true,
          applicationServerKey:base64UrlToUint8Array(keyData.public_key)
        });
        const json = subscription.toJSON();
        const saveRes = await fetch("/api/push/subscribe", {
          method:"POST",
          headers:{"Content-Type":"application/json"},
          body:JSON.stringify({endpoint:json.endpoint, keys:json.keys})
        });
        const saved = await saveRes.json().catch(()=>({ok:false}));
        if(!saveRes.ok || !saved.ok) throw new Error(saved.erro || "Não foi possível salvar a inscrição.");
        btn.textContent = "🔔 Notificações com navegador fechado: ativadas";
        btn.classList.add("active");
        toast("Pronto! Você receberá mensagens mesmo com o navegador fechado.");
      }catch(e){
        console.error("Web Push:",e);
        toast("Não foi possível ativar o Web Push. Confira HTTPS e a permissão do navegador.");
      }
    };
  }catch(e){
    console.error("Web Push setup:",e);
    btn.textContent = "Web Push indisponível neste endereço";
  }
}

function formatLastSeen(value){
  if(!value) return "";
  try{
    const dt = new Date(String(value).replace(" ","T"));
    if(Number.isNaN(dt.getTime())) return "";
    const diff = Math.max(0, Date.now() - dt.getTime());
    if(diff < 60000) return "Visto por último agora";
    if(diff < 3600000) return `Visto por último há ${Math.floor(diff/60000)} min`;
    if(diff < 86400000) return `Visto por último hoje às ${dt.toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}`;
    return `Visto por último em ${dt.toLocaleDateString("pt-BR")} às ${dt.toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}`;
  }catch(e){ return ""; }
}

const CEN_TOUR_STEPS = [
  {selector:".sidebar", title:"👥 Pessoas e setores", text:"Aqui ficam seus setores, favoritos e os colegas. Você pode abrir até quatro conversas para trabalhar em paralelo."},
  {selector:".search", title:"🔎 Busca rápida", text:"Pesquise qualquer colaborador pelo nome para abrir uma conversa sem ficar procurando manualmente."},
  {selector:".dashboard-grid", title:"📊 Painel inicial", text:"Veja quem está online, conversas recentes e o estado do tempo real. Quando aparecer '⚡ Tempo real ativo', as mensagens chegam pelo canal instantâneo."},
  {selector:".gear-btn", title:"⚙️ Configurações", text:"Aqui começam suas personalizações. No próximo passo vamos abrir as configurações para você aprender a trocar a cor do Cen-Chat."},
  {selector:".appearance-card", title:"🎨 Troque as cores", text:"Escolha um dos temas do Cen-Chat. Existem opções escuras e claras; a escolha fica salva para o seu usuário." , settings:true},
  {selector:"#soundToggle", title:"🔊 Som, tremida e visto por último", text:"Aqui você controla o som de novas mensagens, a tremida visual e se o seu visto por último aparece quando estiver offline.", settings:true},
  {selector:"#webPushBtn", title:"🔔 Notificações de verdade", text:"Ative Web Push para receber avisos mesmo quando o navegador estiver fechado, quando o ambiente suportar HTTPS/localhost e a permissão estiver autorizada.", settings:true},
  {selector:"#openBulkMessageChatBtn", title:"📣 Envio em massa", text:"Você pode abrir uma pasta/setor e escolher exatamente quais colaboradores receberão um comunicado, sem precisar selecionar pessoas espalhadas pela tela."},
  {selector:"#erasmoToggleBtn", title:"🤖 Conheça o Erasminho", text:"O Erasminho é uma IA real, online e conversacional. Ele gera respostas em tempo real sobre o Cen-Chat e, quando disponível, sobre a documentação autorizada da clínica. Não é um menu de respostas prontas."},
  {selector:".notification-wrap", title:"🔔 Central de notificações", text:"O sininho abre sua central com as novidades e mensagens recebidas. Assim você não precisa perder tempo procurando o que chegou."}
];
let cenTourIndex = 0;

function finishCenTour(){
  document.querySelector("#settingsModal")?.classList.remove("open");
  document.body.classList.remove("modal-scroll-lock");
  document.querySelector("#cenTour")?.classList.remove("open");
  document.querySelector("#cenTour")?.setAttribute("aria-hidden","true");
  fetch("/api/tour/concluir",{method:"POST"}).catch(()=>{});
  if(window.CEN_USER) window.CEN_USER.tour=1;
}

function positionCenTour(){
  const step = CEN_TOUR_STEPS[cenTourIndex];
  const target = document.querySelector(step.selector);
  const spotlight = document.querySelector("#cenTourSpotlight");
  const card = document.querySelector(".cen-tour-card");
  if(!target || !spotlight || !card) return;
  const r = target.getBoundingClientRect();
  spotlight.style.display="block";
  spotlight.style.left=`${Math.max(8,r.left-6)}px`;
  spotlight.style.top=`${Math.max(8,r.top-6)}px`;
  spotlight.style.width=`${Math.min(window.innerWidth-16,r.width+12)}px`;
  spotlight.style.height=`${Math.min(window.innerHeight-16,r.height+12)}px`;

  // Mantém o cartão fora do elemento destacado quando possível.
  const cardW = Math.min(430, window.innerWidth-32);
  const cardH = card.offsetHeight || 220;
  let top = r.bottom + 18;
  if(top + cardH > window.innerHeight-16) top = r.top - cardH - 18;
  if(top < 16) top = Math.max(16,(window.innerHeight-cardH)/2);
  let left = Math.min(Math.max(16,r.left),window.innerWidth-cardW-16);
  card.style.left=`${left}px`;
  card.style.top=`${top}px`;
  card.style.transform="none";
}

function renderCenTour(){
  const wrap=document.querySelector("#cenTour");
  if(!wrap) return;
  const step=CEN_TOUR_STEPS[cenTourIndex];
  if(step.settings){
    const modal=document.querySelector("#settingsModal");
    if(modal && !modal.classList.contains("open")){
      document.querySelector("[data-open-settings]")?.click();
    }
  } else {
    const modal=document.querySelector("#settingsModal");
    if(modal?.classList.contains("open") && step.selector!==".gear-btn"){
      modal.classList.remove("open");
      document.body.classList.remove("modal-scroll-lock");
    }
  }
  document.querySelector("#cenTourStep").textContent=String(cenTourIndex+1);
  document.querySelector("#cenTourTotal").textContent=String(CEN_TOUR_STEPS.length);
  document.querySelector("#cenTourTitle").textContent=step.title;
  document.querySelector("#cenTourText").textContent=step.text;
  const next=document.querySelector("#cenTourNext");
  if(next) next.textContent=cenTourIndex===CEN_TOUR_STEPS.length-1 ? "Concluir ✓" : "Próximo →";
  requestAnimationFrame(()=>{
    const target=document.querySelector(step.selector);
    if(step.settings && target){
      try{ target.scrollIntoView({block:"center",inline:"nearest"}); }catch(e){}
    }
    positionCenTour();
  });
}

function startCenTourIfNeeded(){
  if(!window.CEN_USER || Number(window.CEN_USER.tour)!==0) return;
  const wrap=document.querySelector("#cenTour");
  if(!wrap) return;
  wrap.classList.add("open");
  wrap.setAttribute("aria-hidden","false");
  cenTourIndex=0;
  renderCenTour();
  document.querySelector("#cenTourNext").onclick=()=>{
    if(cenTourIndex>=CEN_TOUR_STEPS.length-1) finishCenTour();
    else { cenTourIndex++; renderCenTour(); }
  };
  document.querySelector("#cenTourSkip").onclick=finishCenTour;
  window.addEventListener("resize",positionCenTour);
}

document.querySelector("#refazerTourBtn")?.addEventListener("click", async()=>{
  const btn=document.querySelector("#refazerTourBtn");
  if(btn) btn.disabled=true;
  try{
    const res=await fetch("/api/tour/refazer",{method:"POST"});
    const data=await res.json();
    if(data.ok){
      if(window.CEN_USER) window.CEN_USER.tour=0;
      document.querySelector("#settingsModal")?.classList.remove("open");
      document.body.classList.remove("modal-scroll-lock");
      startCenTourIfNeeded();
    }
  }catch(e){}
  if(btn) btn.disabled=false;
});

async function openConversationFromPushUrl(){
  const id = new URLSearchParams(location.search).get("open");
  if(!id) return;
  const person = document.querySelector(`.person[data-id="${CSS.escape(String(id))}"]`);
  if(person){
    setTimeout(()=>openConversation(Number(id), person.dataset.name || "Usuário"), 350);
  }
}
function hasVisibleOpenConversation(otherId){
  const popup = openPopups.get(String(otherId));
  return !!(popup && !popup.classList.contains('minimized'));
}
function maybeShowDesktopAlert(items, total, signature){
  if(!browserAlertsEnabled || !("Notification" in window) || Notification.permission !== 'granted') return;
  if(!items || !items.length || !total) return;
  const first = items.find(item=>!hasVisibleOpenConversation(item.other_id));
  if(!first) return;
  if(signature === lastDesktopNotificationSignature) return;
  lastDesktopNotificationSignature = signature;
  const n = new Notification('Cen-Chat · Nova mensagem', { body:`${first.other_nome}: ${first.texto || 'Nova mensagem'}`, icon:'/static/img/favicon.png', badge:'/static/img/favicon.png' });
  n.onclick = ()=>{ window.focus(); openConversation(first.other_id, first.other_nome); try{ n.close(); }catch(e){} };
}
let lastInAppToastSignature = "";
// Notificação estilo WhatsApp/MSN: um card no canto inferior direito.
// A animação de tremida é opcional e controlada em Configurações.
function shakeWindow(){
  if(window.CEN_USER && Number(window.CEN_USER.tremer) === 0) return;
  const el = document.body;
  el.classList.remove('msg-shake');
  void el.offsetWidth; // reinicia a animação mesmo se já tiver rodado há pouco
  el.classList.add('msg-shake');
  clearTimeout(shakeWindow._t);
  shakeWindow._t = setTimeout(()=>el.classList.remove('msg-shake'), 550);
}
function showMessageToast(item){
  let box = document.querySelector('#msgToastBox');
  if(!box){ box = document.createElement('div'); box.id = 'msgToastBox'; document.body.appendChild(box); }
  const card = document.createElement('div');
  card.className = 'msg-toast';
  card.innerHTML = `
    <span class="recent-avatar" style="--avatar-hue:${hueFromId(item.other_id)}">${escapeHtml(getInitials(item.other_nome))}</span>
    <span class="msg-toast-body">
      <strong>${escapeHtml(item.other_nome)}</strong>
      <small>${escapeHtml((item.texto || 'Nova mensagem').slice(0,80))}</small>
    </span>
    <button type="button" class="msg-toast-close" title="Fechar">×</button>`;
  card.querySelector('.msg-toast-close').onclick = (ev)=>{ ev.stopPropagation(); closeMessageToast(card); };
  card.onclick = ()=>{ openConversation(item.other_id, item.other_nome); closeMessageToast(card); };
  box.appendChild(card);
  requestAnimationFrame(()=>card.classList.add('show'));
  const timer = setTimeout(()=>closeMessageToast(card), 6000);
  card.dataset.timer = timer;
}
function closeMessageToast(card){
  if(!card || !card.isConnected) return;
  clearTimeout(Number(card.dataset.timer));
  card.classList.remove('show');
  card.classList.add('leaving');
  setTimeout(()=>card.remove(), 220);
}
function maybeShowInAppAlert(items, total, signature){
  if(!items || !items.length || !total) return;
  const first = items.find(item=>!hasVisibleOpenConversation(item.other_id));
  if(!first) return;
  if(signature === lastInAppToastSignature) return;
  lastInAppToastSignature = signature;
  showMessageToast(first);
  shakeWindow();
}
function updateSidebarFromUnread(items){
  const byUser = new Map();
  (items || []).forEach(item=>{
    byUser.set(String(item.other_id), Number(item.count || 0));
  });
  document.querySelectorAll('[data-unread-for]').forEach(b=>{
    const count = byUser.get(String(b.dataset.unreadFor)) || 0;
    b.textContent = count > 99 ? '99+' : String(count);
    b.hidden = count <= 0;
    b.closest('.person')?.classList.toggle('has-unread', count > 0);
  });
  // Nunca mostrar contador de não lidas no cabeçalho do setor.
  // Mantemos somente a quantidade ao lado da pessoa.
  document.querySelectorAll('.sector-unread').forEach(el=>el.remove());
  document.querySelectorAll('.sector').forEach(sec=>sec.classList.remove('has-unread'));
  const dashUnread = document.querySelector('#dashUnreadCount');
  if(dashUnread) dashUnread.textContent = String([...byUser.values()].reduce((a,b)=>a+b,0));
}
function updateSidebarPreviews(items){
  previewCache = items || [];
  const byUser = new Map();
  previewCache.forEach(item=>byUser.set(String(item.other_id), item));
  document.querySelectorAll('[data-preview-for]').forEach(el=>{
    const item = byUser.get(String(el.dataset.previewFor));
    if(!item) return;
    const txt = (item.last_texto || '').replace(/\s+/g,' ').trim();
    el.textContent = txt ? txt.slice(0,54) : '';
    el.title = txt || '';
  });
  const recent = previewCache.slice(0,6).map(item=>({id:item.other_id, conversa_id:item.conversa_id, name:item.other_nome, setor:item.setor_nome, status:item.status, ts:Date.parse(String(item.last_time).replace(' ','T')) || Date.now()}));
  const jaFoiInicializado = localStorage.getItem(RECENT_CONVERSATIONS_SEEDED_KEY) === "1";
  if(recent.length && !jaFoiInicializado) saveRecentConversations(recent);
  renderRecentConversations();
}
function renderOnlineNow(users){
  const wrap = document.querySelector('#onlineNowList');
  if(!wrap) return;
  const list = (users||[]).slice(0,8);
  const signature = list.map(u=>u.id).join(',');
  fadeSwapList(wrap, signature, ()=>{
    wrap.innerHTML = '';
    if(!list.length){ wrap.innerHTML = '<div class="recent-empty">Nenhum usuário online disponível agora.</div>'; return; }
    list.forEach(u=>{
      const btn=document.createElement('button');
      btn.type='button'; btn.className='online-now-item';
      btn.innerHTML=`<span class="recent-avatar" style="--avatar-hue:${hueFromId(u.id)}">${escapeHtml(getInitials(u.nome))}</span><span><strong>${escapeHtml(u.nome)}</strong><small>${escapeHtml(u.setor_nome || 'Sem setor')}</small></span><i>online</i>`;
      btn.onclick=()=>openConversation(u.id,u.nome);
      wrap.appendChild(btn);
    });
  });
}
// Troca o conteúdo de uma lista do dashboard com um leve cross-fade em vez de
// substituir o innerHTML de golpe — era isso que causava aquele "pulo" feio
// quando os dados chegavam do servidor. Se nada mudou desde a última vez,
// nem re-renderiza, pra lista não ficar piscando a cada atualização.
function fadeSwapList(wrap, signature, updateFn){
  if(!wrap) return;
  const isSkeleton = wrap.classList.contains('is-loading');
  if(!isSkeleton && wrap.dataset.listSig === signature) return;
  wrap.dataset.listSig = signature;
  if(isSkeleton){
    wrap.classList.remove('is-loading');
    updateFn();
    wrap.classList.add('list-fading');
    (window.requestAnimationFrame || (fn=>setTimeout(fn,16)))(()=>wrap.classList.remove('list-fading'));
    return;
  }
  wrap.classList.add('list-fading');
  setTimeout(()=>{ updateFn(); wrap.classList.remove('list-fading'); }, 130);
}
async function refreshDashboardRealtime(){
  if(dashboardBusy) return;
  dashboardBusy=true;
  try{
    const [dashRes, previewRes] = await Promise.all([fetch('/api/chat_dashboard').catch(()=>null), fetch('/api/conversas_preview').catch(()=>null)]);
    if(dashRes && dashRes.ok){
      const data = await dashRes.json();
      document.querySelector('#dashOnlineCount') && (document.querySelector('#dashOnlineCount').textContent = data.usuarios_online ?? 0);
      document.querySelector('#dashActiveSectors') && (document.querySelector('#dashActiveSectors').textContent = data.setores_ativos ?? 0);
      renderOnlineNow(data.online_users || []);
      setConnectionStatusTimestamp();
    } else if(dashRes){
      console.warn('[Cen-Chat] /api/chat_dashboard retornou HTTP', dashRes.status);
      const online = document.querySelector('#dashOnlineCount');
      const sectors = document.querySelector('#dashActiveSectors');
      if(online?.closest?.('.dash-stat')) online.textContent = '—';
      if(sectors?.closest?.('.dash-stat')) sectors.textContent = '—';
      renderOnlineNow([]);
      cenChatDiagnostic();
    } else {
      console.warn('[Cen-Chat] /api/chat_dashboard indisponível');
      cenChatDiagnostic();
    }

    if(previewRes && previewRes.ok){
      const data = await previewRes.json();
      updateSidebarPreviews(data.items || []);
    } else if(previewRes){
      console.warn('[Cen-Chat] /api/conversas_preview retornou HTTP', previewRes.status);
      updateSidebarPreviews([]);
      cenChatDiagnostic();
    }
  }finally{dashboardBusy=false;}
}
async function markAllRead(){
  await fetch('/api/marcar_todas_lidas', {method:'POST'}).catch(()=>null);
  saveReadMap({});
  await refreshUnread(false);
  await refreshDashboardRealtime();
  toast('Mensagens marcadas como lidas.');
}
function setupDashboardActions(){
  document.querySelector('#clearRecentConversationsBtn')?.addEventListener('click', clearAllRecentConversations);
  document.querySelector('#browserAlertsBtn')?.addEventListener('click', requestBrowserAlerts);
  setupWebPush();
  document.querySelector('#testNotificationBtn')?.addEventListener('click', ()=>{
    // Dispara o aviso completo para teste. A tremida respeita a preferência
    // escolhida nas Configurações.
    showMessageToast({other_id:0, other_nome:"Teste do Cen-Chat", texto:"Se você está vendo este aviso, a notificação está funcionando! 🎉"});
    shakeWindow();
    playDingDong();
  });
  document.querySelector('#focusSearchBtn')?.addEventListener('click', ()=>document.querySelector('.search')?.focus());
  document.querySelector('#openGlobalSearchBtn')?.addEventListener('click', ()=>{
    const modal=document.querySelector('#settingsModal');
    modal?.classList.add('open');
    document.body.classList.add('modal-scroll-lock');
    setTimeout(()=>document.querySelector('#historySearchInput')?.focus(), 80);
  });
  document.querySelector('#expandSectorsBtn')?.addEventListener('click', ()=>document.querySelectorAll('.sector').forEach(sec=>sec.classList.add('open')));
  document.querySelector('#collapseSectorsBtn')?.addEventListener('click', ()=>document.querySelectorAll('.sector').forEach(sec=>sec.classList.remove('open')));
  document.querySelector('#markAllReadBtn')?.addEventListener('click', markAllRead);
  document.querySelector('#toggleUnreadFocusBtn')?.addEventListener('click', (ev)=>{
    unreadFocusEnabled = !unreadFocusEnabled;
    document.body.classList.toggle('focus-unread', unreadFocusEnabled);
    ev.currentTarget.classList.toggle('active', unreadFocusEnabled);
    ev.currentTarget.textContent = unreadFocusEnabled ? 'Mostrar todos' : 'Modo foco: não lidas';
  });
}
function bootCenChatReal(){
  // Cada etapa roda isolada: se uma delas falhar, não trava as demais —
  // foi exatamente esse tipo de falha em cascata que deixava "online agora"
  // e "conversas recentes" presos no esqueleto de carregamento.
  const etapas = [
    ()=>refreshUnread(false),
    renderRecentConversations,
    setConnectionStatusTimestamp,
    updateBrowserAlertsButton,
    setupDashboardActions,
    refreshDashboardRealtime,
    startCenTourIfNeeded,
    openConversationFromPushUrl,
  ];
  etapas.forEach(etapa=>{
    try{ etapa(); }
    catch(e){ console.error("Falha ao iniciar o painel do Cen-Chat:", e); }
  });
  setInterval(setConnectionStatusTimestamp, 60000);
  setInterval(refreshDashboardRealtime, 12000);
}
bootCenChatReal();


function getReadMap(){
  try{return JSON.parse(localStorage.getItem("cen-chat-read-map") || "{}");}
  catch(e){return {};}
}
function saveReadMap(map){
  localStorage.setItem("cen-chat-read-map", JSON.stringify(map || {}));
}
function markConversationSeen(conversaId, lastId){
  if(!conversaId || !lastId) return;
  const map = getReadMap();
  const key = String(conversaId);
  map[key] = Math.max(Number(map[key] || 0), Number(lastId || 0));
  saveReadMap(map);
}
function filterUnreadByLocalRead(items){
  const map = getReadMap();
  return (items || []).filter(item => Number(item.last_id || 0) > Number(map[String(item.conversa_id)] || 0));
}

let userInteractedForSound = false;

document.addEventListener("pointerdown",()=>{userInteractedForSound=true;},{once:true});
document.addEventListener("keydown",()=>{userInteractedForSound=true;},{once:true});

function escapeHtml(s){ const d=document.createElement("div"); d.textContent=s ?? ""; return d.innerHTML; }
function toast(text){
  let box=document.querySelector("#toastBox");
  if(!box){box=document.createElement("div");box.id="toastBox";document.body.appendChild(box);}
  const item=document.createElement("div");
  item.className="toast";
  item.textContent=text;
  box.appendChild(item);
  setTimeout(()=>item.remove(),2300);
}
function isOnlyEmoji(text){
  return /^(\p{Emoji_Presentation}|\p{Emoji}\uFE0F|\s)+$/u.test(text || "") && [...(text||"").trim()].length <= 8;
}
function getRecentEmojis(){
  try{return JSON.parse(localStorage.getItem("cen-chat-recent-emojis") || "[]");}
  catch(e){return [];}
}
function saveRecentEmoji(emoji){
  const arr = getRecentEmojis().filter(e=>e!==emoji);
  arr.unshift(emoji);
  localStorage.setItem("cen-chat-recent-emojis", JSON.stringify(arr.slice(0,42)));
}
function getInitials(name){
  return (name || "?").trim().split(/\s+/).slice(0,2).map(p=>p[0] || "").join("").toUpperCase();
}
function hueFromId(id){
  return (parseInt(id || "1",10) * 47) % 360;
}
function parseDateSafe(value){
  if(!value) return null;
  const d = new Date(value);
  if(!Number.isNaN(d.getTime())) return d;
  const fixed = String(value).replace(" ", "T");
  const d2 = new Date(fixed);
  return Number.isNaN(d2.getTime()) ? null : d2;
}
function formatDay(value){
  const d = parseDateSafe(value);
  if(!d) return "";
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate()-1);
  const same = (a,b)=>a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate();
  if(same(d,today)) return "Hoje";
  if(same(d,yesterday)) return "Ontem";
  return d.toLocaleDateString("pt-BR", {weekday:"long", day:"2-digit", month:"2-digit", year:"numeric"});
}
function formatTime(value){
  const d = parseDateSafe(value);
  if(!d) return "";
  return d.toLocaleTimeString("pt-BR", {hour:"2-digit", minute:"2-digit"});
}
function formatFullDateTime(value){
  const d = parseDateSafe(value);
  if(!d) return "";
  return d.toLocaleString("pt-BR", {weekday:"long", day:"2-digit", month:"2-digit", year:"numeric", hour:"2-digit", minute:"2-digit"});
}

function playDingDong(){
  if(!userInteractedForSound) return;
  if(window.CEN_USER && Number(window.CEN_USER.som) === 0) return;
  try{
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if(!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    function tone(freq, start, duration, gainValue){
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, now + start);
      gain.gain.setValueAtTime(0.0001, now + start);
      gain.gain.exponentialRampToValueAtTime(gainValue, now + start + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + start + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + start);
      osc.stop(now + start + duration + 0.04);
    }

    // Campainha suave: ding + dong
    tone(880, 0.00, 0.33, 0.13);
    tone(1320, 0.015, 0.22, 0.035);
    tone(660, 0.38, 0.42, 0.12);
    tone(990, 0.395, 0.25, 0.03);

    setTimeout(()=>ctx.close?.(), 1200);
  }catch(e){}
}

document.addEventListener("click", (ev)=>{
  document.querySelectorAll(".msg-actions.open").forEach(a=>{ if(!a.contains(ev.target)) a.classList.remove("open"); });
  document.querySelectorAll(".emoji-panel.open").forEach(p=>{ if(!p.closest(".emoji-wrap")?.contains(ev.target)) p.classList.remove("open"); });
  const panel = document.querySelector("#notificationPanel");
  const wrap = document.querySelector(".notification-wrap");
  if(panel && wrap && !wrap.contains(ev.target)) panel.classList.remove("open");
});

document.querySelector("#notificationBell")?.addEventListener("click",(ev)=>{
  ev.stopPropagation();
  document.querySelector("#notificationPanel")?.classList.toggle("open");
});


function renderChatSectors(payload){
  const wrap = document.querySelector('#chatSectorList');
  if(!wrap || !payload?.setores) return;
  const sidebar=document.querySelector('.sidebar');
  const sidebarScrollTop=sidebar ? sidebar.scrollTop : 0;
  const prevOpen = new Set([...document.querySelectorAll('.sector.open')].map(el => el.dataset.sectorId || el.querySelector('.sector-head strong')?.textContent || ''));
  const prevSectorScroll = new Map([...document.querySelectorAll('.sector')].map(el=>[el.dataset.sectorId || el.querySelector('.sector-head strong')?.textContent || '', el.querySelector('.sector-body')?.scrollTop || 0]));
  const oldSig = [...document.querySelectorAll('.sector')].map(el=>{
    const name = el.querySelector('.sector-head strong')?.textContent || '';
    const ids = [...el.querySelectorAll('.person')].map(p=>p.dataset.id).sort().join(',');
    return `${name}:${ids}`;
  }).join('|');
  const newSig = payload.setores.map(s=>`${s.nome}:${(s.usuarios||[]).map(u=>u.id).sort((a,b)=>a-b).join(',')}`).join('|');
  if(oldSig === newSig) return;

  wrap.innerHTML = '';
  // Compatibilidade com versões antigas que ainda criavam a bolinha no setor.
  document.querySelectorAll('.sector-unread').forEach(el=>el.remove());
  for(const setor of payload.setores){
    const article = document.createElement('article');
    article.className = 'sector';
    article.dataset.sectorId = String(setor.id);
    if(prevOpen.has(String(setor.id)) || prevOpen.has(setor.nome)) article.classList.add('open');

    const head = document.createElement('button');
    head.type = 'button';
    head.className = 'sector-head';
    head.innerHTML = `<span class="arrow">▶</span><strong>${escapeHtml(setor.nome)}</strong><small class="sector-online-count" data-sector-online-count="${setor.id}">${Number(setor.online_count || 0)} online</small>`;
    head.addEventListener('click', ()=>article.classList.toggle('open'));

    const body = document.createElement('div');
    body.className = 'sector-body';
    const people = setor.usuarios || [];
    if(!people.length){
      body.innerHTML = '<div class="empty-sector">Nenhum usuário disponível para você neste setor.</div>';
    }else{
      for(const u of people){
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'person';
        btn.dataset.id = u.id;
        btn.dataset.name = u.nome;
        btn.dataset.away = u.mensagem_ausencia || '';
        btn.dataset.setorId = u.setor_id || '';
        btn.dataset.setorName = u.setor_nome || setor.nome;
        btn.innerHTML = `
          <span class="mini-avatar" style="--avatar-hue:${(Number(u.id) * 47) % 360}">${escapeHtml((u.nome||'?').slice(0,1).toUpperCase())}</span>
          <span class="person-main"><strong>${escapeHtml(u.nome)}</strong><small data-preview-for="${u.id}">${escapeHtml((u.ultima_mensagem || '').replace(/\s+/g,' ').trim().slice(0,54))}</small></span>
          <span class="dot status-${escapeHtml(u.status || 'offline')}"></span>
          <b class="person-unread" data-unread-for="${u.id}" hidden>0</b>${u.favorito ? '<em>⭐</em>' : ''}`;
        btn.addEventListener('click', ()=>openConversation(u.id, u.nome));
        body.appendChild(btn);
      }
    }
    article.appendChild(head);
    article.appendChild(body);
    wrap.appendChild(article);
  }
  refreshUnread(false);
  refreshSidebarStatuses();
  requestAnimationFrame(()=>{
    if(sidebar) sidebar.scrollTop=sidebarScrollTop;
    wrap.querySelectorAll('.sector').forEach(sec=>{
      const key=sec.dataset.sectorId || sec.querySelector('.sector-head strong')?.textContent || '';
      const body=sec.querySelector('.sector-body');
      if(body && prevSectorScroll.has(key)) body.scrollTop=prevSectorScroll.get(key)||0;
    });
  });
}

async function refreshChatSectorStructure(){
  try{
    const res = await fetch('/api/chat_setores?ts='+Date.now(), {cache:'no-store', headers:{'Cache-Control':'no-cache'}});
    const data = await res.json();
    if(res.ok && data.ok) renderChatSectors(data);
  }catch(e){
    // O chat continua funcionando com a última estrutura carregada.
  }
}

// Os setores pertencem ao Cen-Chat, não ao AD. Portanto a interface precisa
// refletir imediatamente alterações feitas no Painel ADM ou diretamente no
// MariaDB, sem depender de novo login ou reinício do servidor.
refreshChatSectorStructure();
setInterval(refreshChatSectorStructure, 12000);

document.querySelectorAll(".sector-head").forEach(btn=>btn.addEventListener("click",()=>btn.closest(".sector")?.classList.toggle("open")));

function attachPersonEvents(scope=document){
  scope.querySelectorAll(".person").forEach(btn=>{
    if(btn.dataset.bound) return;
    btn.dataset.bound = "1";
    btn.addEventListener("click",()=>openConversation(btn.dataset.id, btn.dataset.name));
  });
}
attachPersonEvents();

document.querySelector(".search")?.addEventListener("input", e=>{
  const term = e.target.value.trim().toLowerCase();
  document.querySelectorAll(".sector").forEach(sec=>{
    let any=false;
    sec.querySelectorAll(".person").forEach(p=>{
      const show=!term || p.textContent.toLowerCase().includes(term);
      p.style.display=show?"flex":"none";
      if(show) any=true;
    });
    sec.style.display=(!term || any)?"block":"none";
    if(term && any) sec.classList.add("open");
    else if(!term) sec.classList.remove("open");
  });
});

document.querySelector("[data-open-settings]")?.addEventListener("click",()=>{
  document.querySelector("#settingsModal")?.classList.add("open");
  document.body.classList.add("modal-scroll-lock");
});
document.querySelector("[data-close-settings]")?.addEventListener("click",()=>{
  document.querySelector("#settingsModal")?.classList.remove("open");
  document.body.classList.remove("modal-scroll-lock");
});
document.querySelector("#settingsModal")?.addEventListener("click",e=>{
  if(e.target.id==="settingsModal"){
    e.target.classList.remove("open");
    document.body.classList.remove("modal-scroll-lock");
  }
});

function applyTheme(theme){
  document.body.className=document.body.className.replace(/theme-[a-z0-9-]+/g,"").trim()+" theme-"+theme;
  localStorage.setItem("cen-chat-theme", theme);
}
const savedTheme=localStorage.getItem("cen-chat-theme");
if(savedTheme && document.body.classList.contains("app-page")) applyTheme(savedTheme);

document.querySelectorAll("[data-theme]").forEach(btn=>{
  btn.onclick=async()=>{
    const theme=btn.dataset.theme;
    applyTheme(theme);
    await fetch("/api/tema",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tema:theme})});
    toast("Tema aplicado.");
  };
});

document.querySelectorAll("[data-status]").forEach(btn=>{
  btn.onclick=async()=>{
    const status=btn.dataset.status;
    document.querySelectorAll("[data-status]").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    await fetch("/api/status",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({status})});
    const el=document.querySelector("#myStatusLabel");
    if(el) el.textContent=btn.textContent.trim();
    toast("Status atualizado.");
  };
});

document.querySelector("#saveUserSettings")?.addEventListener("click", async()=>{
  const payload={
    mensagem_ausencia:document.querySelector("#awayMessage")?.value || "",
    som_notificacao:document.querySelector("#soundToggle")?.checked || false,
    tremer_tela:document.querySelector("#shakeToggle")?.checked || false,
    mostrar_ultimo_visto:document.querySelector("#lastSeenToggle")?.checked ?? true
  };
  window.CEN_USER.som=payload.som_notificacao?1:0;
  window.CEN_USER.tremer=payload.tremer_tela?1:0;
  window.CEN_USER.mostrarUltimoVisto=payload.mostrar_ultimo_visto?1:0;
  await fetch("/api/config_usuario",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  toast("Configurações salvas.");
});

document.querySelector("#historySearchBtn")?.addEventListener("click", searchHistory);
document.querySelector("#historySearchInput")?.addEventListener("keydown", e=>{if(e.key==="Enter") searchHistory();});
async function searchHistory(){
  const q=document.querySelector("#historySearchInput")?.value.trim();
  const box=document.querySelector("#historyResults");
  if(!box) return;
  if(!q || q.length<2){box.innerHTML="<small>Digite pelo menos 2 letras.</small>"; return;}
  const res=await fetch("/api/buscar_mensagens?q="+encodeURIComponent(q));
  const data=await res.json();
  box.innerHTML="";
  if(!data.resultados.length){box.innerHTML="<small>Nenhuma mensagem encontrada.</small>"; return;}
  data.resultados.forEach(r=>{
    const b=document.createElement("button");
    b.className="history-item"; b.type="button";
    b.innerHTML=`<strong>${escapeHtml(r.other_nome)}</strong><span>${escapeHtml(r.texto)}</span><small>${r.enviado_em}</small>`;
    b.onclick=()=>openConversation(r.other_id, r.other_nome);
    box.appendChild(b);
  });
}

async function refreshSidebarStatuses(){
  try{
    const res = await fetch('/api/status_usuarios', {cache:'no-store'});
    const data = await res.json();
    if(!data || !data.ok) return;
    Object.entries(data.usuarios).forEach(([id, info])=>{
      document.querySelectorAll(`.person[data-id="${id}"]`).forEach(btn=>{
        const dot = btn.querySelector('.dot');
        if(dot) dot.className = 'dot status-' + info.status;
      });
    });
    refreshSectorOnlineCounts();
  }catch(e){/* silencioso: só tenta de novo no próximo ciclo */}
}
function refreshSectorOnlineCounts(){
  document.querySelectorAll('.sector').forEach(sec=>{
    const countEl = sec.querySelector('[data-sector-online-count]');
    if(!countEl) return;
    const count = [...sec.querySelectorAll('.person')].filter(btn=>btn.querySelector('.dot.status-online')).length;
    countEl.textContent = `${count} online`;
  });
}
setInterval(refreshSidebarStatuses, 20000);
document.addEventListener('visibilitychange', ()=>{ if(!document.hidden){ refreshSidebarStatuses(); refreshSectorOnlineCounts(); } });
refreshSidebarStatuses();
refreshSectorOnlineCounts();

function updateDockSpace(){
  const anyVisible = [...openPopups.values()].some(p => !p.classList.contains('minimized'));
  document.querySelector('.main-chat')?.classList.toggle('has-open-chat', anyVisible);
}
async function openConversation(id,name,existingConversaId=null){
  if(openPopups.has(String(id))){
    const existing = openPopups.get(String(id));
    existing.classList.remove("minimized");
    existing.classList.add("focus-pop");
    updateDockSpace();
    setTimeout(()=>existing.classList.remove("focus-pop"), 600);
    return;
  }
  if(openPopups.size>=MAX_POPUPS){toast(`Máximo de ${MAX_POPUPS} conversas abertas.`);return;}

  let data=null;
  try{
    if(existingConversaId){
      const res=await fetch(`/api/conversa_info/${existingConversaId}`, {cache:"no-store"});
      const text=await res.text();
      try{ data=JSON.parse(text); }catch(e){
        toast(`Erro ao abrir conversa: resposta ${res.status}`);
        console.error("Resposta não JSON de /api/conversa_info:", text);
        return;
      }
      if(!res.ok || !data.ok){
        toast(data.erro || `Erro ao abrir conversa: ${res.status}`);
        console.error("Erro /api/conversa_info:", data);
        return;
      }
    }else{
      const res=await fetch(`/api/conversa/${id}`, {cache:"no-store"});
      const text=await res.text();
      try{ data=JSON.parse(text); }catch(e){
        toast(`Erro ao abrir conversa: resposta ${res.status}`);
        console.error("Resposta não JSON de /api/conversa:", text);
        return;
      }
      if(!res.ok || !data.ok){
        toast(data.erro || `Erro ao abrir conversa: ${res.status}`);
        console.error("Erro /api/conversa:", data);
        return;
      }
    }
  }catch(e){
    toast("Falha de comunicação com o servidor.");
    console.error("Falha ao abrir conversa:", e);
    return;
  }

  addRecentConversation({id, conversa_id:data.conversa_id, name, setor: data.other?.setor_nome, status: data.other?.status});
  setConnectionStatusTimestamp();
  const popup=createPopup(id,name,data.conversa_id,data.other);
  escolherDock()?.appendChild(popup);
  openPopups.set(String(id),popup);
  updateDockSpace();
  await loadMessages(popup,data.conversa_id,true);
  const lastMsgId = Number(popup.dataset.lastMsgId || 0);
  markConversationSeen(data.conversa_id, lastMsgId);
  fetch(`/api/marcar_lida/${data.conversa_id}`,{method:"POST"}).catch(()=>{});
  await refreshUnread(false);
  if(data.other?.mensagem_ausencia) showSystemMessage(popup,data.other.mensagem_ausencia);
}


function createPopup(userId,name,conversaId,other){
  const el=document.createElement("section");
  el.className="popup premium-popup";
  el.dataset.userId=userId;
  el.dataset.conversaId=conversaId;
  const exportTools = "";
  const initials = getInitials(name);
  const hue = hueFromId(userId);
  el.innerHTML=`
    <header class="popup-head">
      <div class="popup-identity">
        <span class="popup-avatar" style="--avatar-hue:${hue}">${escapeHtml(initials)}</span>
        <div><strong>${escapeHtml(name)}</strong><small>Conversa privada</small></div>
      </div>
      <div class="popup-tools">
        <button class="conversation-search-toggle" type="button" title="Buscar nesta conversa">🔍</button>
        <button class="fav-btn" type="button" title="Favoritar">☆</button>
        <button class="clear-chat-popup" type="button" title="Sincronizar histórico">↻</button><button class="maximize-popup" type="button" title="Abrir maior">⛶</button>
        <button class="minimize-popup" type="button" title="Minimizar">—</button>
        <button class="close-popup" type="button" title="Fechar">×</button>
      </div>
    </header>
    <div class="conversation-search-bar" hidden>
      <input class="conversation-search-input" type="search" placeholder="Buscar mensagem nesta conversa..." autocomplete="off">
      <button type="button" class="conversation-search-close" title="Fechar busca">×</button>
      <div class="conversation-search-results"></div>
    </div>
    <div class="typing-line"></div>
    <div class="popup-body"></div>
    <div class="quick-replies"><button type="button" data-quick-reply="Ok, vou verificar.">Ok, verifico</button><button type="button" data-quick-reply="Pode deixar, já retorno.">Já retorno</button><button type="button" data-quick-reply="Encaminhado para o setor responsável.">Encaminhado</button></div>
    <div class="reply-preview" hidden>
      <div class="reply-preview-body"><strong></strong><span></span></div>
      <button type="button" class="reply-preview-cancel" title="Cancelar resposta">×</button>
    </div>
    <form class="popup-form">
      <div class="emoji-wrap"><button class="emoji-btn" type="button" title="Emojis">😊</button><div class="emoji-panel"></div></div>
      <button class="attach-btn" type="button" title="Anexar arquivo">📎</button>
      <input type="file" class="attach-input" hidden>
      <input class="msg-text-input" maxlength="2000" placeholder="Digite sua mensagem..." autocomplete="off">
      <button class="btn primary send-btn" type="submit">➤</button>
    </form>
    <span class="resize-grip" title="Arraste para redimensionar"></span>`;

  el.querySelector(".close-popup").onclick=()=>{sendTyping(conversaId,false);openPopups.delete(String(userId));messageCache.delete(String(conversaId));typingCache.delete(String(conversaId));el.remove();updateDockSpace();};
  el.querySelector(".minimize-popup").onclick=()=>{
    const minimizing = !el.classList.contains("minimized");
    el.classList.remove("maximized");
    el.classList.toggle("minimized", minimizing);
    const button = el.querySelector(".minimize-popup");
    if(button){
      button.title = minimizing ? "Restaurar conversa" : "Minimizar";
      button.setAttribute("aria-label", button.title);
    }
    updateDockSpace();
  };
  el.querySelector(".maximize-popup").onclick=()=>{
    const maximizing = !el.classList.contains("maximized");
    el.classList.remove("minimized");
    el.classList.toggle("maximized", maximizing);
    const button = el.querySelector(".maximize-popup");
    if(button){
      button.title = maximizing ? "Restaurar tamanho" : "Abrir maior";
      button.setAttribute("aria-label", button.title);
    }
    updateDockSpace();
  };
  el.querySelector(".clear-chat-popup").onclick=async()=>{
    // "Limpar" nunca apaga nem oculta o histórico. O botão apenas força
    // uma sincronização completa com o banco para recuperar o histórico.
    messageCache.delete(String(conversaId));
    await loadMessages(el, conversaId, true);
    toast("Histórico sincronizado com o servidor.");
  };

  // Busca específica da conversa, sem alterar o histórico.
  const convSearchToggle=el.querySelector('.conversation-search-toggle');
  const convSearchBar=el.querySelector('.conversation-search-bar');
  const convSearchInput=el.querySelector('.conversation-search-input');
  const convSearchResults=el.querySelector('.conversation-search-results');
  const convSearchClose=el.querySelector('.conversation-search-close');
  convSearchToggle?.addEventListener('click',()=>{
    if(!convSearchBar) return;
    convSearchBar.hidden=!convSearchBar.hidden;
    if(!convSearchBar.hidden) setTimeout(()=>convSearchInput?.focus(),40);
  });
  convSearchClose?.addEventListener('click',()=>{
    convSearchBar.hidden=true;
    if(convSearchInput) convSearchInput.value='';
    if(convSearchResults) convSearchResults.innerHTML='';
  });
  let convSearchTimer=null;
  const doConversationSearch=async()=>{
    const q=(convSearchInput?.value||'').trim();
    if(!convSearchResults) return;
    if(q.length<2){ convSearchResults.innerHTML=''; return; }
    convSearchResults.innerHTML='<div class="conversation-search-loading">Buscando…</div>';
    try{
      const res=await fetch(`/api/conversa/${conversaId}/buscar?q=${encodeURIComponent(q)}`,{cache:'no-store'});
      const data=await res.json();
      if(!res.ok||!data.ok){ convSearchResults.innerHTML=`<div class="conversation-search-empty">${escapeHtml(data.erro||'Não foi possível buscar.')}</div>`; return; }
      if(!data.resultados?.length){ convSearchResults.innerHTML='<div class="conversation-search-empty">Nenhuma mensagem encontrada.</div>'; return; }
      convSearchResults.innerHTML='';
      data.resultados.forEach(r=>{
        const b=document.createElement('button');
        b.type='button'; b.className='conversation-search-result';
        b.innerHTML=`<strong>${escapeHtml(r.texto)}</strong><small>${escapeHtml(r.enviado_em||'')}</small>`;
        b.onclick=async()=>{
          // Tenta o histórico recente primeiro. Se a mensagem for antiga, carrega a janela que a contém.
          el.dataset.messageLimit=String(Math.max(80,Math.min(500,Number(el.dataset.messageLimit||80))));
          messageCache.delete(String(conversaId));
          await loadMessages(el,conversaId,true);
          let target=el.querySelector(`.msg[data-msg-id="${r.id}"]`);
          if(!target){
            await loadMessages(el,conversaId,true,r.id+1);
            target=el.querySelector(`.msg[data-msg-id="${r.id}"]`);
          }
          if(target){
            target.scrollIntoView({behavior:'smooth',block:'center'});
            target.classList.add('highlight-pop');
            setTimeout(()=>target.classList.remove('highlight-pop'),1300);
          }
        };
        convSearchResults.appendChild(b);
      });
    }catch(e){
      convSearchResults.innerHTML='<div class="conversation-search-empty">Falha de comunicação com o servidor.</div>';
    }
  };
  convSearchInput?.addEventListener('input',()=>{ clearTimeout(convSearchTimer); convSearchTimer=setTimeout(doConversationSearch,220); });
  convSearchInput?.addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); clearTimeout(convSearchTimer); doConversationSearch(); } });
  el.querySelector(".fav-btn").onclick=async()=>{
    const res=await fetch(`/api/favorito/${userId}`,{method:"POST"});
    const data=await res.json();
    el.querySelector(".fav-btn").textContent=data.marcado?"⭐":"☆";
    toast(data.marcado?"Conversa fixada.":"Favorito removido.");
  };

  const replyPreview=el.querySelector(".reply-preview");
  el.querySelector(".reply-preview-cancel").onclick=()=>setReplyTarget(el,null);
  function setReplyTarget(popup,target){
    popupReplyState.set(popup, target);
    const preview=popup.querySelector(".reply-preview");
    if(!preview) return;
    if(!target){ preview.hidden=true; return; }
    preview.hidden=false;
    preview.querySelector("strong").textContent=target.nome||"Mensagem";
    preview.querySelector("span").textContent=(target.texto||"").slice(0,80);
  }
  el._setReplyTarget=setReplyTarget;

  const input=el.querySelector("input.msg-text-input");
  const form=el.querySelector("form");
  let typingTimer;
  let lastTypingSent=0;
  input.oninput=()=>{
    const nowTs=Date.now();
    if(nowTs-lastTypingSent>1300){ sendTyping(conversaId,true); lastTypingSent=nowTs; }
    clearTimeout(typingTimer);
    typingTimer=setTimeout(()=>sendTyping(conversaId,false),1200);
  };
  el.querySelectorAll("[data-quick-reply]").forEach(btn=>btn.onclick=()=>{input.value=btn.dataset.quickReply; input.focus();});
  input.addEventListener("keydown", e=>{
    if(e.key==="Escape" && form.dataset.editingId){
      delete form.dataset.editingId;
      form.classList.remove("editing-mode");
      input.value="";
    }
  });

  // Anexo de arquivo/imagem
  const attachBtn = el.querySelector(".attach-btn");
  const attachInput = el.querySelector(".attach-input");
  attachBtn?.addEventListener("click", ()=>attachInput?.click());
  attachInput?.addEventListener("change", async()=>{
    const arquivo = attachInput.files?.[0];
    if(!arquivo) return;
    attachInput.value = "";
    if(arquivo.size > 10*1024*1024){ toast("Arquivo maior que 10MB não é permitido."); return; }

    const body = el.querySelector(".popup-body");
    const stickToBottom = !body || body.scrollTop+body.clientHeight>=body.scrollHeight-90;
    const optimistic=document.createElement("div");
    optimistic.className="msg mine optimistic";
    optimistic.innerHTML=`<div class="msg-text">📎 ${escapeHtml(arquivo.name)}</div><span class="msg-time">${escapeHtml(formatTime(new Date()))} <small class="delivery-mark">enviando anexo…</small></span>`;
    if(body){ body.appendChild(optimistic); if(stickToBottom) body.scrollTop=body.scrollHeight; }

    const fd = new FormData();
    fd.append("conversa_id", conversaId);
    fd.append("arquivo", arquivo);
    const replyTarget = popupReplyState.get(el);
    if(replyTarget) fd.append("resposta_a_id", replyTarget.id);

    let ok=false;
    let mensagemErro="Não foi possível enviar o anexo.";
    try{
      const res = await fetch("/api/enviar_anexo", {method:"POST", body:fd});
      ok = res.ok;
      const data=await res.json().catch(()=>null);
      if(ok && data?.ok && data?.message){ replaceOptimisticWithMessage(el, optimistic, data.message); }
      if(!ok || !data || !data.ok){
        ok=false;
        if(data && data.erro) mensagemErro=data.erro;
      }
    }catch(err){ ok=false; }

    if(!ok){
      optimistic.classList.add("failed");
      optimistic.querySelector(".delivery-mark").textContent="falhou · toque para remover";
      optimistic.onclick=()=>optimistic.remove();
      toast(mensagemErro);
      return;
    }
    setReplyTarget(el,null);
    scheduleMessagesSync(el, conversaId);
    scheduleDashboardSync();
  });
  form.onsubmit=async e=>{
    e.preventDefault();
    const texto=input.value.trim();
    if(!texto)return;

    // Modo de edição: se estiver editando uma mensagem já enviada, salva a
    // edição em vez de criar uma mensagem nova.
    if(form.dataset.editingId){
      const editId=form.dataset.editingId;
      delete form.dataset.editingId;
      form.classList.remove("editing-mode");
      input.value="";
      const res=await fetch(`/api/editar_mensagem/${editId}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({texto})}).catch(()=>null);
      const data=await res?.json().catch(()=>null);
      if(!data || !data.ok){ toast(data?.erro || "Não foi possível editar."); }
      messageCache.delete(String(conversaId));
      await loadMessages(el,conversaId,true);
      input.focus();
      return;
    }

    const replyTarget=popupReplyState.get(el);
    input.value="";
    sendTyping(conversaId,false);
    setReplyTarget(el,null);

    // Eco otimista: a mensagem aparece na hora, sem esperar a viagem completa
    // ao servidor (era isso que causava a sensação de atraso ao enviar).
    const body=el.querySelector(".popup-body");
    const stickToBottom = !body || body.scrollTop+body.clientHeight>=body.scrollHeight-90;
    const optimistic=document.createElement("div");
    optimistic.className="msg mine optimistic";
    optimistic.innerHTML=`<div class="msg-text">${escapeHtml(texto)}</div><span class="msg-time">${escapeHtml(formatTime(new Date()))} <small class="delivery-mark">enviando…</small></span>`;
    if(body){ body.appendChild(optimistic); if(stickToBottom) body.scrollTop=body.scrollHeight; }
    input.focus();

    let ok=false;
    try{
      const sendRes=await fetch("/api/enviar",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({conversa_id:conversaId,texto,resposta_a_id:replyTarget?replyTarget.id:null})});
      const sendData=await sendRes.json().catch(()=>null);
      ok=sendRes.ok && !!sendData?.ok;
      if(ok && sendData?.message){ replaceOptimisticWithMessage(el, optimistic, sendData.message); }
    }catch(err){ ok=false; }

    if(!ok){
      optimistic.classList.add("failed");
      optimistic.querySelector(".delivery-mark").textContent="falhou · toque para tentar de novo";
      optimistic.onclick=()=>{ input.value=texto; optimistic.remove(); input.focus(); };
      toast("Não foi possível enviar.");
      return;
    }

    // Sincroniza com o servidor "com calma" — ver scheduleMessagesSync().
    scheduleMessagesSync(el, conversaId);
    scheduleDashboardSync();
  };

  setupEmojiPanel(el, input);
  enablePopupResize(el);
  setTimeout(()=>el.classList.add("show"),20);
  return el;
}

function setupEmojiPanel(popup, input){
  const emojiBtn=popup.querySelector(".emoji-btn");
  const panel=popup.querySelector(".emoji-panel");
  function renderCategory(key){
    const cat = EMOJI_CATEGORIES[key];
    let emojis = cat.emojis;
    if(key === "recentes") emojis = getRecentEmojis();
    const grid = emojis.length ? emojis.map(e=>`<button type="button" data-emoji="${e}">${e}</button>`).join("") : `<small class="emoji-empty">Seus emojis usados aparecem aqui.</small>`;
    panel.querySelector(".emoji-grid").innerHTML = grid;
    panel.querySelectorAll(".emoji-tab").forEach(t=>t.classList.toggle("active", t.dataset.cat===key));
    panel.querySelectorAll("[data-emoji]").forEach(btn=>{
      btn.onclick=(ev)=>{
        ev.stopPropagation();
        input.value += btn.dataset.emoji;
        saveRecentEmoji(btn.dataset.emoji);
        input.focus();
      };
    });
  }
  const tabs = Object.entries(EMOJI_CATEGORIES).map(([key,cat])=>`<button class="emoji-tab" type="button" data-cat="${key}" title="${cat.label}">${cat.icon}<span>${cat.label}</span></button>`).join("");
  panel.innerHTML = `<div class="emoji-panel-title">Emojis</div><div class="emoji-tabs">${tabs}</div><div class="emoji-grid"></div>`;
  panel.querySelectorAll(".emoji-tab").forEach(tab=>tab.onclick=(ev)=>{ev.stopPropagation();renderCategory(tab.dataset.cat);});
  emojiBtn.onclick=(ev)=>{ev.stopPropagation();panel.classList.toggle("open");renderCategory(getRecentEmojis().length ? "recentes" : "rostos");};
}

function showSystemMessage(popup,text){
  const body=popup.querySelector(".popup-body");
  if(!body||body.querySelector(".msg.system"))return;
  const div=document.createElement("div");
  div.className="msg system";
  div.innerHTML=`💬 Ausência: ${escapeHtml(text)}`;
  body.prepend(div);
}

// ==========================================================
// Sincronização com o servidor, "com calma" — sem isso, mandar várias
// mensagens em sequência rápida disparava uma recarga completa da
// conversa a CADA mensagem, todas rodando ao mesmo tempo, brigando
// entre si e travando a tela (era exatamente o "delay gigante" ao
// mandar mensagem em massa). Agora só recarrega de verdade um tempinho
// depois da ÚLTIMA mensagem da rajada — a mensagem em si já aparece na
// hora (bolha otimista), então isso não atrasa o que a pessoa vê.
const messagesSyncTimers = new Map();
function scheduleMessagesSync(popup, conversaId){
  const key = String(conversaId);
  clearTimeout(messagesSyncTimers.get(key));
  messagesSyncTimers.set(key, setTimeout(()=>{
    messagesSyncTimers.delete(key);
    messageCache.delete(key);
    loadMessages(popup, conversaId, true);
  }, 500));
}
let dashboardSyncTimer=null;
function scheduleDashboardSync(){
  clearTimeout(dashboardSyncTimer);
  dashboardSyncTimer=setTimeout(refreshDashboardRealtime, 700);
}
async function loadMessages(popup,conversaId,force=false,beforeId=null){  if(!popup || !conversaId) return;
  if(popup.dataset.loadingMessages === "1" && !force) return;
  popup.dataset.loadingMessages = "1";
  try{
    const limit = Math.max(80, Math.min(500, Number(popup.dataset.messageLimit || 80)));
    const beforeQuery = beforeId ? `&before_id=${encodeURIComponent(beforeId)}` : '';
    const res=await fetch(`/api/mensagens/${conversaId}?limit=${limit}${beforeQuery}`, {cache:"no-store"}).catch(()=>null);
    if(!res || !res.ok){
      console.warn("Falha ao carregar histórico", conversaId, res?.status);
      return;
    }
    const data=await res.json();
    const body=popup.querySelector(".popup-body");
    if(!body)return;
    if(!data || !data.ok || !Array.isArray(data.mensagens)){
      console.warn("Histórico inválido para a conversa", conversaId, data);
      return;
    }
    const signature=`${data.tem_mais}:${data.mensagens.map(m=>`${m.id}:${m.remetente_id}:${m.texto}:${m.enviado_em}`).join("|")}`;
    const key=String(conversaId);
    if(!force&&messageCache.get(key)===signature)return;
    messageCache.set(key,signature);
    const shouldStickToBottom=body.scrollTop+body.clientHeight>=body.scrollHeight-90;
    const sys=[...body.querySelectorAll(".msg.system")].map(x=>x.outerHTML);
    body.innerHTML=sys.join("");
    if(data.tem_mais){
      const older=document.createElement("button");
      older.type="button";
      older.className="load-older-btn";
      older.textContent="Carregar mensagens antigas";
      older.onclick=async()=>{ popup.dataset.messageLimit=String(limit+30); messageCache.delete(key); await loadMessages(popup,conversaId,true); };
      body.appendChild(older);
    }
    let lastDay = "";
    // O histórico exibido vem sempre do banco. Não há mais "clear map"
    // persistente no navegador, evitando que mensagens desapareçam após
    // fechar/reabrir a conversa ou trocar de dispositivo.
    const visibleMessages = data.mensagens;
    const allIds = data.mensagens.map(m => Number(m.id || 0)).filter(Boolean);
    popup.dataset.lastMsgId = allIds.length ? String(Math.max(...allIds)) : "0";
    visibleMessages.forEach(m=>{
      const day = formatDay(m.enviado_em);
      if(day && day !== lastDay){
        lastDay = day;
        const sep = document.createElement("div");
        sep.className = "day-separator";
        sep.textContent = day;
        body.appendChild(sep);
      }
      const mine=m.remetente_id===window.CEN_USER.id;
      const div=document.createElement("div");
      const bigEmoji=isOnlyEmoji(m.texto) && !m.anexo;
      div.className="msg"+(mine?" mine":"")+(bigEmoji?" emoji-only":"")+(m.fixado?" is-pinned":"");
      div.dataset.msgId = m.id;
      div.dataset.fullTime = formatFullDateTime(m.enviado_em);
      const hora = formatTime(m.enviado_em);
      const editedLabel = (m.editado && !m.apagado) ? ' <small class="edited-mark">(editado)</small>' : '';
      const readMark = mine ? `<small class="delivery-mark${m.lido?' read':''}">✓✓</small>` : '';
      const pinLabel = m.fixado ? "Desfixar" : "Fixar";
      const pinBadge = m.fixado ? '<span class="pin-badge" title="Mensagem fixada">📌</span>' : '';
      const forwardBadge = m.encaminhada_de ? `<div class="forwarded-tag">↪ Encaminhada${m.encaminhada_de ? ' de '+escapeHtml(m.encaminhada_de) : ''}</div>` : '';
      const replyBlock = m.resposta_a ? `<button type="button" class="msg-reply-quote" data-scroll-to="${m.resposta_a.id}"><strong>${escapeHtml(m.resposta_a.remetente_id===window.CEN_USER.id?"Você":m.resposta_a.remetente_nome)}</strong><span>${escapeHtml(m.resposta_a.texto)}</span></button>` : '';
      const anexoBlock = renderAnexoBlock(m.anexo);
      const reacoesBlock = renderReacoesBlock(m.reacoes, m.id);
      const podeEditar = mine && !m.apagado && !m.anexo;
      const podeEncaminhar = !m.apagado;
      const menuItems = (mine
        ? `<button type="button" data-reply="${m.id}">Responder</button><button type="button" data-react="${m.id}">Reagir</button>${podeEncaminhar?`<button type="button" data-forward="${m.id}">Encaminhar</button>`:''}<button type="button" data-copy="${m.id}">Copiar</button><button type="button" data-pin="${m.id}">${pinLabel}</button>${podeEditar?`<button type="button" data-edit="${m.id}">Editar</button>`:''}<button type="button" data-del-self="${m.id}">Apagar para mim</button><button type="button" data-del-all="${m.id}">Apagar para todos</button>`
        : `<button type="button" data-reply="${m.id}">Responder</button><button type="button" data-react="${m.id}">Reagir</button>${podeEncaminhar?`<button type="button" data-forward="${m.id}">Encaminhar</button>`:''}<button type="button" data-copy="${m.id}">Copiar</button><button type="button" data-pin="${m.id}">${pinLabel}</button>`);
      const menu=`<div class="msg-actions"><button class="msg-menu-btn" type="button">⋮</button><div class="msg-menu">${menuItems}</div></div>`;
      div.innerHTML=`${forwardBadge}${replyBlock}${anexoBlock}<div class="msg-text">${pinBadge}${escapeHtml(m.texto)}</div><span class="msg-time">${escapeHtml(hora)}${editedLabel} ${readMark}</span>${reacoesBlock}${menu}`;
      body.appendChild(div);
    });
    if(!visibleMessages.length){
      const empty = document.createElement("div");
      empty.className = "chat-cleared-note";
      empty.textContent = "Nenhuma mensagem nesta conversa.";
      body.appendChild(empty);
    }
    bindMessageMenus(body,popup,conversaId);
    markConversationSeen(conversaId, Number(popup.dataset.lastMsgId || 0));
    fetch(`/api/marcar_lida/${conversaId}`,{method:"POST"}).catch(()=>{});
    if(shouldStickToBottom||force){body.scrollTop=body.scrollHeight;}
  }finally{
    popup.dataset.loadingMessages = "0";
  }
}
const QUICK_REACTIONS = ["👍","❤️","😂","😮","😢","🙏"];
function formatFileSize(bytes){
  if(!bytes && bytes !== 0) return "";
  if(bytes < 1024) return bytes + " B";
  if(bytes < 1024*1024) return (bytes/1024).toFixed(1) + " KB";
  return (bytes/(1024*1024)).toFixed(1) + " MB";
}
function renderAnexoBlock(anexo){
  if(!anexo) return "";
  if(anexo.imagem){
    return `<a class="msg-anexo-img" href="${escapeHtml(anexo.url)}" target="_blank" rel="noopener"><img src="${escapeHtml(anexo.url)}" alt="${escapeHtml(anexo.nome||"anexo")}" loading="lazy"></a>`;
  }
  return `<a class="msg-anexo-file" href="${escapeHtml(anexo.url)}" target="_blank" rel="noopener">
    <span class="msg-anexo-icon">📎</span>
    <span class="msg-anexo-info"><strong>${escapeHtml(anexo.nome||"Arquivo")}</strong><small>${escapeHtml(formatFileSize(anexo.tamanho))}</small></span>
  </a>`;
}
function renderReacoesBlock(reacoes, msgId){
  if(!reacoes || !reacoes.length) return "";
  return `<div class="msg-reacoes">${reacoes.map(r=>`<button type="button" class="msg-reacao${r.mine?' mine':''}" data-react-toggle="${msgId}" data-emoji="${escapeHtml(r.emoji)}">${escapeHtml(r.emoji)} <b>${r.total}</b></button>`).join("")}</div>`;
}
function closeAllReactionPickers(){
  document.querySelectorAll(".reaction-picker").forEach(el=>el.remove());
}
function openReactionPicker(anchorBtn, msgId, popup, conversaId){
  closeAllReactionPickers();
  const picker=document.createElement("div");
  picker.className="reaction-picker";
  picker.innerHTML=QUICK_REACTIONS.map(e=>`<button type="button" data-pick-emoji="${e}">${e}</button>`).join("");
  anchorBtn.closest(".msg-actions")?.appendChild(picker);
  picker.querySelectorAll("[data-pick-emoji]").forEach(btn=>{
    btn.onclick=async(ev)=>{
      ev.stopPropagation();
      await enviarReacao(msgId, btn.dataset.pickEmoji, popup, conversaId);
      closeAllReactionPickers();
    };
  });
}
async function enviarReacao(msgId, emoji, popup, conversaId){
  await fetch(`/api/reagir_mensagem/${msgId}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({emoji})}).catch(()=>{});
  messageCache.delete(String(conversaId));
  await loadMessages(popup,conversaId,true);
}
document.addEventListener("click", (e)=>{
  if(!e.target.closest(".reaction-picker") && !e.target.closest("[data-react]")) closeAllReactionPickers();
});

function openForwardModal(msgId){
  const modal=document.querySelector("#forwardModal");
  if(!modal) return;
  modal.dataset.msgId = msgId;
  modal.classList.add("open");
  const input=modal.querySelector("#forwardSearchInput");
  if(input){ input.value=""; setTimeout(()=>input.focus(),50); }
  renderForwardList("");
}
function closeForwardModal(){
  document.querySelector("#forwardModal")?.classList.remove("open");
}
function renderForwardList(filtro){
  const list=document.querySelector("#forwardList");
  if(!list) return;
  const termo=(filtro||"").toLowerCase().trim();
  const pessoas=[...document.querySelectorAll(".person")]
    .map(el=>({id:el.dataset.id, nome:el.dataset.name}))
    .filter((p,idx,arr)=>arr.findIndex(x=>x.id===p.id)===idx)
    .filter(p=>!termo || (p.nome||"").toLowerCase().includes(termo));
  list.innerHTML="";
  if(!pessoas.length){ list.innerHTML='<div class="recent-empty">Ninguém encontrado.</div>'; return; }
  pessoas.slice(0,60).forEach(p=>{
    const btn=document.createElement("button");
    btn.type="button"; btn.className="history-item";
    btn.innerHTML=`<strong>${escapeHtml(p.nome||"")}</strong>`;
    btn.onclick=async()=>{
      const modal=document.querySelector("#forwardModal");
      const msgId=modal?.dataset.msgId;
      if(!msgId) return;
      const res=await fetch(`/api/encaminhar_mensagem/${msgId}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({destino_id:p.id})}).catch(()=>null);
      const data=await res?.json().catch(()=>null);
      closeForwardModal();
      if(data && data.ok){
        toast(`Mensagem encaminhada para ${p.nome}.`);
        openConversation(p.id, p.nome);
      }else{
        toast(data?.erro || "Não foi possível encaminhar.");
      }
    };
    list.appendChild(btn);
  });
}
document.querySelector("#forwardSearchInput")?.addEventListener("input", e=>renderForwardList(e.target.value));
document.querySelector("#forwardModal .close")?.addEventListener("click", closeForwardModal);
document.querySelector("#forwardModal")?.addEventListener("click", e=>{ if(e.target.id==="forwardModal") closeForwardModal(); });

function bindMessageMenus(body,popup,conversaId){
  body.querySelectorAll(".msg-menu-btn").forEach(btn=>btn.onclick=(e)=>{e.stopPropagation();btn.parentElement.classList.toggle("open");});
  body.querySelectorAll("[data-copy]").forEach(btn=>btn.onclick=async()=>{const txt=btn.closest(".msg")?.querySelector(".msg-text")?.innerText||"";try{await navigator.clipboard.writeText(txt);toast("Mensagem copiada.");}catch(e){}});
  body.querySelectorAll("[data-reply]").forEach(btn=>btn.onclick=()=>{
    const msgEl=btn.closest(".msg");
    if(!msgEl || !popup._setReplyTarget) return;
    const nome = msgEl.classList.contains("mine") ? "Você" : (popup.querySelector(".popup-identity strong")?.textContent || "Mensagem");
    const texto = msgEl.querySelector(".msg-text")?.innerText || "";
    popup._setReplyTarget(popup, {id:Number(msgEl.dataset.msgId), nome, texto});
    popup.querySelector(".popup-form input.msg-text-input")?.focus();
  });
  body.querySelectorAll("[data-pin]").forEach(btn=>btn.onclick=async()=>{
    await fetch(`/api/fixar_mensagem/${btn.dataset.pin}`,{method:"POST"});
    messageCache.delete(String(conversaId));
    await loadMessages(popup,conversaId,true);
  });
  body.querySelectorAll("[data-scroll-to]").forEach(btn=>btn.onclick=()=>{
    const target=body.querySelector(`.msg[data-msg-id="${btn.dataset.scrollTo}"]`);
    if(!target) return;
    target.scrollIntoView({behavior:"smooth",block:"center"});
    target.classList.add("highlight-pop");
    setTimeout(()=>target.classList.remove("highlight-pop"),1200);
  });
  body.querySelectorAll("[data-del-self]").forEach(btn=>btn.onclick=async()=>{await fetch(`/api/apagar_mensagem/${btn.dataset.delSelf}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({modo:"para_mim"})});messageCache.delete(String(conversaId));await loadMessages(popup,conversaId,true);await refreshUnread(false);});
  body.querySelectorAll("[data-del-all]").forEach(btn=>btn.onclick=async()=>{await fetch(`/api/apagar_mensagem/${btn.dataset.delAll}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({modo:"para_todos"})});messageCache.delete(String(conversaId));await loadMessages(popup,conversaId,true);await refreshUnread(false);});
  body.querySelectorAll("[data-edit]").forEach(btn=>btn.onclick=()=>{
    const msgEl=btn.closest(".msg");
    const texto=msgEl?.querySelector(".msg-text")?.innerText || "";
    const input=popup.querySelector(".popup-form input.msg-text-input");
    const form=popup.querySelector(".popup-form");
    if(!input || !form) return;
    input.value=texto;
    form.dataset.editingId=btn.dataset.edit;
    form.classList.add("editing-mode");
    input.focus();
    toast("Editando mensagem — envie para salvar ou apague o texto para cancelar.");
  });
  body.querySelectorAll("[data-forward]").forEach(btn=>btn.onclick=()=>openForwardModal(btn.dataset.forward));
  body.querySelectorAll("[data-react]").forEach(btn=>btn.onclick=(e)=>{e.stopPropagation();openReactionPicker(btn, btn.dataset.react, popup, conversaId);});
  body.querySelectorAll("[data-react-toggle]").forEach(btn=>btn.onclick=()=>enviarReacao(btn.dataset.reactToggle, btn.dataset.emoji, popup, conversaId));
}
async function sendTyping(conversaId,ativo){fetch("/api/digitando",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({conversa_id:conversaId,ativo})}).catch(()=>{});}
async function loadTyping(popup,conversaId){
  const res=await fetch(`/api/digitando/${conversaId}`).catch(()=>null);
  if(!res||!res.ok)return;
  const data=await res.json();
  const line=popup.querySelector(".typing-line");
  if(!line)return;
  const html=data.digitando.length?`<div class="typing-bubble"><span></span><span></span><span></span></div>`:"";
  if(typingCache.get(String(conversaId))!==html){typingCache.set(String(conversaId),html);line.innerHTML=html;}
}
function enablePopupResize(popup){
  const grip=popup.querySelector(".resize-grip");
  if(!grip)return;
  let startX=0,startY=0,startW=0,startH=0;
  grip.addEventListener("mousedown",e=>{
    e.preventDefault();
    startX=e.clientX;startY=e.clientY;startW=popup.offsetWidth;startH=popup.offsetHeight;
    const move=ev=>{
      popup.style.width=Math.max(340,Math.min(720,startW+(ev.clientX-startX)))+"px";
      popup.style.height=Math.max(440,Math.min(window.innerHeight-88,startH+(ev.clientY-startY)))+"px";
    };
    const up=()=>{document.removeEventListener("mousemove",move);document.removeEventListener("mouseup",up);};
    document.addEventListener("mousemove",move);document.addEventListener("mouseup",up);
  });
}

function renderNotificationPanel(items){
  const list = document.querySelector("#notificationList");
  if(!list) return;
  list.innerHTML = "";
  if(!items || !items.length){
    list.innerHTML = `<div class="notification-empty">Nenhuma mensagem nova.</div>`;
    return;
  }
  const actions=document.createElement("div");
  actions.className="notification-actions";
  actions.innerHTML='<button type="button" id="markAllReadFromPanel">Marcar todas como lidas</button>';
  list.appendChild(actions);
  actions.querySelector("#markAllReadFromPanel")?.addEventListener("click", markAllRead);
  items.forEach(item=>{
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "notification-item";
    btn.innerHTML = `
      <span class="notification-avatar">${escapeHtml(getInitials(item.other_nome))}</span>
      <span class="notification-content">
        <strong>${escapeHtml(item.other_nome)}</strong>
        <small>${escapeHtml(item.texto || "Nova mensagem")}</small>
      </span>
      <b>${item.count}</b>`;
    btn.onclick = async()=>{
      document.querySelector("#notificationPanel")?.classList.remove("open");
      await openConversation(item.other_id, item.other_nome);
    };
    list.appendChild(btn);
  });
}
async function refreshUnread(allowSound=true){
  const res=await fetch("/api/unread").catch(()=>null);
  if(!res||!res.ok) return;
  const data=await res.json();
  const rawItems = data.items || [];
  const items = filterUnreadByLocalRead(rawItems);
  const total = items.reduce((sum, item)=>sum + Number(item.count || 0), 0);
  const signature = items.map(i=>`${i.conversa_id}:${i.count}:${i.last_id}:${i.texto}:${i.enviado_em}`).join("|");
  const hadNew = allowSound && total > unreadTotal && signature !== lastUnreadSignature;
  unreadTotal = total;
  lastUnreadSignature = signature;
  updateBadge(total);
  updateSidebarFromUnread(items);
  renderNotificationPanel(items);
  maybeShowDesktopAlert(items, total, signature);
  if(hadNew) maybeShowInAppAlert(items, total, signature);
  const unreadVisible = items.some(item=>hasVisibleOpenConversation(item.other_id));
  if(hadNew && (document.hidden || !unreadVisible)) playDingDong();
}
let pollingBusy=false;
async function pollingLoop(){
  if(pollingBusy) return;
  pollingBusy=true;
  try{
    const tarefas=[];
    // Quando o WebSocket está conectado, ele é a fonte de verdade para
    // mensagens/typing/presença. O polling fica apenas como recuperação de
    // estado quando o WebSocket estiver indisponível.
    if(!cenRealtimeConnected){
      for(const popup of openPopups.values()){
        if(!popup.classList.contains("minimized")){
          tarefas.push(loadMessages(popup,popup.dataset.conversaId));
          tarefas.push(loadTyping(popup,popup.dataset.conversaId));
        }
      }
    }
    if(tarefas.length) await Promise.allSettled(tarefas);
    await refreshUnread(true);
  }finally{
    pollingBusy=false;
  }
}
function schedulePolling(){
  const delay = cenRealtimeConnected ? (document.hidden ? 20000 : 15000) : (document.hidden ? 8500 : (openPopups.size ? 3500 : 6000));
  setTimeout(async()=>{ await pollingLoop(); schedulePolling(); }, delay);
}
schedulePolling();

// ==========================================================
// Verificação de mensagens não lidas — ADAPTATIVA
// ==========================================================
// Antes rodava fixo a cada 2s pra QUALQUER pessoa, o tempo todo, mesmo
// com a aba em segundo plano. Isso é ótimo com poucos usuários testando,
// mas em produção com centenas de pessoas logadas ao mesmo tempo isso
// vira uma carga constante e desnecessária no banco — a maior parte das
// abas abertas está parada ou em segundo plano na maior parte do tempo.
// Agora o intervalo se ajusta à situação de cada pessoa:
//   - conversando ativamente (popup aberto)........... 2.5s (continua rápido)
//   - aba visível, uso normal.......................... 4s
//   - aba visível, mas parada há mais de 5 min......... 15s
//   - aba em segundo plano (minimizada/outra aba)....... 20s
// E ao voltar pra aba (focus/visibilitychange), verifica na hora e volta
// pro ritmo rápido — então continua parecendo instantâneo pra quem está
// usando, só para de gastar recursos com quem não está.
function unreadPollDelay(){
  if(cenRealtimeConnected) return document.hidden ? 30000 : 15000;
  if(document.hidden) return 20000;
  const idleMs = Date.now() - lastActivityTs;
  if(idleMs > 5*60*1000) return 15000;
  if(openPopups.size > 0) return 2500;
  return 4000;
}
let unreadPollBusy=false;
let unreadPollTimer=null;
function scheduleUnreadPoll(){
  clearTimeout(unreadPollTimer);
  unreadPollTimer=setTimeout(async()=>{
    if(!unreadPollBusy){
      unreadPollBusy=true;
      try{ await refreshUnread(true); }
      finally{ unreadPollBusy=false; }
    }
    scheduleUnreadPoll();
  }, unreadPollDelay());
}
scheduleUnreadPoll();
document.addEventListener('visibilitychange', ()=>{ if(!document.hidden){ refreshUnread(true); scheduleUnreadPoll(); } });
window.addEventListener('focus', ()=>{ refreshUnread(true); scheduleUnreadPoll(); });
setInterval(()=>fetch("/api/ping",{method:"POST"}).catch(()=>{}),60000);
async function cenChatDiagnostic(){
  try{
    const r=await fetch('/api/diagnostico?ts='+Date.now(),{cache:'no-store'});
    const d=await r.json();
    document.documentElement.dataset.dbStatus=d.banco?'ok':'error';
    document.documentElement.dataset.wsStatus=d.websocket?'ok':'error';
    console.info('[Cen-Chat diagnóstico]', d);
    if(!d.websocket) document.querySelector('#realtimeStatus')?.setAttribute('title','Tempo real indisponível. Confira a porta 5051 e o Firewall.');
  }catch(e){ console.warn('[Cen-Chat diagnóstico] indisponível',e); }
}
setTimeout(cenChatDiagnostic,1800);
function updateBadge(n){
  document.title=n>0?`(${n}) Cen-Chat`:"Cen-Chat";
  const b=document.querySelector("#topUnreadBadge");
  const p=document.querySelector(".notification-pill");
  if(b){b.textContent=n>99?"99+":String(n);}
  p?.classList.toggle("zero",n===0);
  p?.classList.toggle("has-news",n>0);
}
refreshUnread(false);


document.addEventListener('keydown', (ev)=>{
  if((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'k'){
    ev.preventDefault();
    document.querySelector('.search')?.focus();
  }
});
