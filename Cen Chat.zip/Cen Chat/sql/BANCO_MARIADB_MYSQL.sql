-- ==========================================================
-- CEN-CHAT - BANCO DEFINITIVO MARIADB / MYSQL
-- ==========================================================
-- Execute no HeidiSQL, DBeaver, MySQL Workbench ou terminal mysql.
-- Usuário administrador: root

CREATE DATABASE IF NOT EXISTS cenchat
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'cenchat_user'@'localhost'
  IDENTIFIED BY 'SenhaForteCenChat2026';

GRANT ALL PRIVILEGES ON cenchat.* TO 'cenchat_user'@'localhost';

FLUSH PRIVILEGES;
