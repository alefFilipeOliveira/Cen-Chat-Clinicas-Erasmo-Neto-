@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Cen-Chat - Servidor

cls
echo.
echo ==========================================================
echo                   CEN-CHAT - SERVIDOR
echo ==========================================================
echo.

if not exist "venv\Scripts\python.exe" (
  echo ERRO: ambiente Python nao encontrado.
  echo Execute instalar.bat primeiro.
  echo.
  pause
  exit /b 1
)
if not exist "app.py" (
  echo ERRO: app.py nao encontrado.
  echo.
  pause
  exit /b 1
)

"venv\Scripts\python.exe" -c "import flask,sqlalchemy,pymysql,waitress,websockets; print('Python/Flask/SQLAlchemy/PyMySQL/Waitress/WebSocket OK')"
if errorlevel 1 (
  echo.
  echo ERRO: alguma dependencia esta ausente ou incompatível.
  echo Execute instalar.bat para reinstalar as dependencias.
  echo.
  pause
  exit /b 2
)

if not exist "logs" mkdir "logs"

echo.
echo Portas do servidor:
echo   HTTP       5050
echo   WebSocket 5051 (/ws)
echo.
echo O WebSocket e iniciado pelo proprio app.py e precisa da porta 5051 liberada.
echo.
echo Abrir no navegador: http://10.10.10.192:5050/login
echo.
echo Mantenha esta janela aberta enquanto o Cen-Chat estiver em uso.
echo.

"venv\Scripts\python.exe" "app.py"
set "RC=%errorlevel%"

echo.
echo ==========================================================
echo Cen-Chat encerrou. Codigo: %RC%
echo ==========================================================
echo.
pause
exit /b %RC%
