from app import app, init_db, sync_ldap_users

with app.app_context():
    init_db()
    r = sync_ldap_users()
    print("Sincronização LDAP concluída")
    print("Criados:", r["criados"])
    print("Atualizados:", r["atualizados"])
    print("Ignorados:", r["ignorados"])
    print("Grupos não encontrados:", len(r["grupos_nao_encontrados"]))
    for g in r["grupos_nao_encontrados"]:
        print("-", g)
    print("Erros:", len(r["erros"]))
    for e in r["erros"]:
        print("-", e)
